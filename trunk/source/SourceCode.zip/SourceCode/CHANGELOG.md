## [Unreleased]
**Implemented enhancements**
* Remove Non-used file
* Add AddTestItemByValue func in BaseStation.cs
* Add VoltageCheck func in GSI_Console.cs

## [V1.0.5] 2020-05-21
**Implemented enhancements**
* Modify "SoftwareCheck" func to add "version_image" check
* Adding "SetFirstSFCSLine" in FQC
* Modify LoginTelnet TimeOut to 30 sec

## [V1.0.4] 2020-04-24
**Implemented enhancements**
* Modify RTC spec from +/-5sec to +/-15sec. 
* Modify "ExcuteDialog" func, adding a parameter to determine wheather to enter sudo pwd or not.

## [V1.0.3] 2020-04-18
**Implemented enhancements**
* Modify "RebootLinux" func, adding a parameter to determine wheather to enter sudo pwd or not.

## [V1.0.2] 2020-03-24
**Implemented enhancements**
* Adding SoftwareCheck Func

## [V1.0.1] 2020-03-19
**Implemented enhancements**
* New Project EPR