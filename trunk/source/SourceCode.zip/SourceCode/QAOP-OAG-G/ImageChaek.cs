﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ATS_Template;

namespace Image_load
{
    public partial class ImageChaek : Form
    {
        public enum EMode
        {
            Check = 0,
            Prompt = 1
        }

        private string imageCount = string.Empty;

        public bool ClickValue = false;

        public ImageChaek()
        {
            InitializeComponent();
        }

        private void picOK_Click(object sender, EventArgs e)
        {
            ClickValue = true;
            this.Hide();
        }

        private void picNO_Click(object sender, EventArgs e)
        {
            ClickValue = false;
            this.Hide();
        }

        public void ShowImage(string section, string imageNum, string labelShow, EMode mode)
        {
            switch (mode)
            {
                case EMode.Check:
                    this.picNO.Visible = true;
                    break;
                case EMode.Prompt:
                    this.picNO.Visible = false;
                    break;
            }

            string path = WNC.API.Func.ReadINI(Application.StartupPath, "Setting", section, imageNum, "NONE");

            if (path == "NONE")
            {
                path = WNC.API.Func.ReadINI(Application.StartupPath, "Setting", section, "default", "default");
            }

            //string imagePath = @Application.StartupPath + @"\image\" + imageNum + ".jpg";
            //Bitmap bmp = new Bitmap(@path);
            pictureBox1.Image = Image.FromFile(path);
            label1.Text = labelShow;
        }
    }
}
