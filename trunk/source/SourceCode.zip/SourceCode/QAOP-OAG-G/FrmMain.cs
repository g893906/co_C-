﻿using System;
using System.Windows.Forms;
using System.Threading;
using System.Reflection;
using System.Collections;
using System.Text.RegularExpressions;

using TestPattern;
using WNC.API;

//此warning用複制變數這招目前無效
#pragma warning disable CS1690 // 存取 'StatusUI.Setting' 上的成員可能會造成執行階段例外狀況，因為其為 marshal-by-reference 類別的欄位。

namespace ATS
{
    public partial class FrmMain : StatusUI2.FrmATS
    {
        public IBaseInstances BaseInstances;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            //string res = string.Empty;
            //string[] msg;
            //System.IO.StreamReader Str = new System.IO.StreamReader(@"C:\Users\10312019\Desktop\1.txt");
            //res = Str.ReadToEnd();
            //Str.Close();
            //Str.Dispose();

            //msg = res.Replace("\r\n", "$").Split('$');

            //int number = 0;
            //double value = 0;

            //for (int i = 0; i < msg.Length; i++)
            //{
            //    if (msg[i].Contains("The power rail is " + number.ToString()))
            //    {
            //        value = Convert.ToInt16(msg[i + 6].Trim(), 16);
            //        value = Convert.ToInt16(msg[i + 7].Trim(), 16);
            //        number++;
            //        i = i + 7;
            //    }
            //}

            //double a = Convert.ToInt16("0x2f40", 16);

            status_ATS.Setting.Encryption = Convert.ToBoolean(Func.ReadINI("Setting", "Setting", "ATSEncryption", "false"));
            string instancesName = Func.ReadINI("Setting", "Setting", "Instances", "NONE");

            try
            {
                BaseInstances = TestFactory.Create(instancesName, this.status_ATS);

                if (BaseInstances != null)
                {
                    InitialStatusUI();
                    BaseInstances.Information.ChangeGoldeModeCallback += new CInformation.ChangeGoldeModeHandler(ChangeGoldenMode);
                    BaseInstances.ControlUIEvent.SetTexBoxTextCallback += new CControlUIEvent.dSetTexBoxTextCallback(SetTexBoxTextCallback);
                    BaseInstances.ControlUIEvent.SetBtnEnableCallback += new CControlUIEvent.dSetBtnEnableCallback(SetBtnEnableCallback);
                    BaseInstances.ControlUIEvent.StartBtnPerformClickCallback += new CControlUIEvent.dStartBtnPerformClick(StartBtnPerformClick);
                    BaseInstances.ControlUIEvent.StatsUICheckInputCallback += new CControlUIEvent.dStatsUICheckInput(StatsUICheckInput);
                    BaseInstances.ControlUIEvent.StartBtnMaskVisibleCallback += new CControlUIEvent.dStartBtnMaskVisible(StartBtnMaskVisable);
                    BaseInstances.ControlUIEvent.RCSConnectCheckedCallback += new CControlUIEvent.dRCSConnectChecked(RCSConnectChecked);
                    BaseInstances.ControlUIEvent.RCSConnectEnableCallback += new CControlUIEvent.dRCSConnectEnable(SetRCSConnectEnable);
                    BaseInstances.ControlUIEvent.ChangeStatusCallback += new CControlUIEvent.dChangeStatus(ChangeStatus);
                    BaseInstances.ControlUIEvent.ControlEnableCallback += new CControlUIEvent.dControlEnable(ControlEnable);
                    Checked_RCS_Connect.CheckedChanged += new EventHandler(BaseInstances.RCSConnectChanged);
                    status_ATS.AddLog("[Log]".PadRight(8) + "Read test instances: " + instancesName);
                    BaseInstances.OnCreate();
                }
                else
                {
                    MessageBox.Show("Station or Project name setting failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Create test instances exception: " + ex.Message);
            }
        }

        private void InitialStatusUI()
        {
            string[] tempProductVersion = ProductVersion.Split('.');
            string versionRelease = tempProductVersion[0] + "." + tempProductVersion[1] + "." + tempProductVersion[2];
            status_ATS.SetVersion(BaseInstances.Information.Station, BaseInstances.Information.BU, BaseInstances.Information.Product, BaseInstances.Information.ProjectName, BaseInstances.Information.ProgramVersion, BaseInstances.Information.ReleaseDate);
            int outPathMode = Convert.ToInt16(Func.ReadINI("Setting", "Setting", "OutPathMode", "0"));

            switch (outPathMode)
            {
                case 0:
                    status_ATS.SetSFCS_Data_Format(StatusUI2.StatusUI.SFCSDataFormat.NetWork_PSN);
                    break;
                case 1:
                    status_ATS.SetSFCS_Data_Format(StatusUI2.StatusUI.SFCSDataFormat.NetWork);
                    break;
                case 2:
                    status_ATS.SetSFCS_Data_Format(StatusUI2.StatusUI.SFCSDataFormat.Generally);
                    break;
            }

            if (WNC.API.Func.ReadINI("Setting", "UI", "SFCS", "Disable") == "Enable")
            {
                status_ATS.SetUIMode(StatusUI2.StatusUI.UIMode.Manufacture_ModeWaitingSFCS);
            }
            else
            {
                status_ATS.SetUIMode(StatusUI2.StatusUI.UIMode.OnlyResult_Mode);
            }

            if (WNC.API.Func.ReadINI("Setting", "UI", "Strip1", "Disable") == "Disable") //display P/N/R count or not
            {
                status_ATS.statusStrip1.Visible = false;
            }

            status_ATS.txtPSN.Select();
            status_ATS.cBoxFix.Enabled = false;
        }

        private void status_ATS_Click(object sender, EventArgs e)
        {
            BaseInstances.StartTestThread();
        }

        public void FormTest()
        {
            status_ATS.CheckInput();
        }

        private void status_ATS_Load(object sender, EventArgs e) { }

        private void status_ATS_Start_Before()
        {
            status_ATS.Setting.CheckInput = BaseInstances.OnStartBefore();
        }

        private void frmMain_Activated(object sender, EventArgs e) { }

        private void frmMain_Shown(object sender, EventArgs e)
        {
            BaseInstances.FormShown();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            BaseInstances.FormClosing();
        }

        private void ChangeGoldenMode(bool isgolden)
        {
            if (!isgolden)
            {
                return;
            }

            changeColor(status_ATS.lbStatus, System.Drawing.Color.Yellow);
            changeText(status_ATS.lbStatus, "Golden");
        }

        #region Delegate
        private delegate void myUICallBackSetStatus(Control ctl, System.Drawing.Color color_status);
        private void changeColor(Control ctl, System.Drawing.Color color_status)
        {
            if (this.InvokeRequired)
            {
                myUICallBackSetStatus myUpdate = new myUICallBackSetStatus(changeColor);
                this.Invoke(myUpdate, ctl, color_status);
            }
            else
            {
                (ctl).BackColor = color_status;
            }
        }

        private delegate void myUICallBackSetString(Control ctl, string myStr);
        private void changeText(Control ctl, string myStr)
        {
            if (this.InvokeRequired)
            {
                myUICallBackSetString myUpdate = new myUICallBackSetString(changeText);
                this.Invoke(myUpdate, ctl, myStr);
            }
            else
            {
                (ctl).Text = myStr;
            }
        }

        private delegate void dChangeStatus(Control ctl, string message, System.Drawing.Color color);
        private void ChangeStatus(Control ctl, string message, System.Drawing.Color color)
        {
            if (this.InvokeRequired)
            {
                dChangeStatus changeStatus = new dChangeStatus(ChangeStatus);
                this.Invoke(changeStatus, ctl, message, color);
            }
            else
            {
                (ctl).Text = message;
                (ctl).BackColor = color;
            }
        }

        delegate void dSetTexBoxTextCallback(TextBox tb, string text);
        private void SetTexBoxTextCallback(TextBox tb, string text)
        {
            if (tb.InvokeRequired)
            {
                dSetTexBoxTextCallback d = new dSetTexBoxTextCallback(SetTexBoxTextCallback);
                tb.Invoke(d, new object[] { tb, text });
            }
            else
            {
                tb.Text = text;
            }
        }

        delegate void dSetBtnEnableCallback(Button btn, bool enable);
        private void SetBtnEnableCallback(Button btn, bool enable)
        {
            if (btn.InvokeRequired)
            {
                dSetBtnEnableCallback d = new dSetBtnEnableCallback(SetBtnEnableCallback);
                btn.Invoke(d, new object[] { btn, enable });
            }
            else
            {
                btn.Enabled = enable;
            }
        }

        delegate void dStartBtnPerformClick(Button btn);
        private void StartBtnPerformClick(Button btn)
        {
            if (btn.InvokeRequired)
            {
                dStartBtnPerformClick d = new dStartBtnPerformClick(StartBtnPerformClick);
                btn.Invoke(d, new object[] { btn });
            }
            else
            {
                btn.PerformClick();
            }
        }

        delegate bool dStatsUICheckInput();
        private bool StatsUICheckInput()
        {
            dStatsUICheckInput d = new dStatsUICheckInput(status_ATS.CheckInput);
            return d();
        }

        delegate void dStartBtnMaskVisable(bool visible);
        private void StartBtnMaskVisable(bool visible)
        {
            if (StartBtnMask.InvokeRequired)
            {
                dStartBtnMaskVisable d = new dStartBtnMaskVisable(StartBtnMaskVisable);
                d.Invoke(visible);
            }
            else
            {
                StartBtnMask.Visible = visible;
                int localY = (status_ATS.lbFix.Location.Y + status_ATS.lbFix.Size.Height) + 6;
                StartBtnMask.Location = new System.Drawing.Point(StartBtnMask.Location.X, localY);
                StartBtnMask.Size = status_ATS.buStart.Size;
            }
        }

        delegate void dRCSConnectChecked(bool isChecked);
        private void RCSConnectChecked(bool isChecked)
        {
            if (Checked_RCS_Connect.InvokeRequired)
            {
                dRCSConnectChecked d = new dRCSConnectChecked(RCSConnectChecked);
                Checked_RCS_Connect.Invoke(d, isChecked);
            }
            else
            {
                Checked_RCS_Connect.Checked = isChecked;
            }
        }

        delegate void dRCSConnectEnable(bool enable);
        private void SetRCSConnectEnable(bool enable)
        {
            if (Checked_RCS_Connect.InvokeRequired)
            {
                dRCSConnectEnable d = new dRCSConnectEnable(SetRCSConnectEnable);
                Checked_RCS_Connect.Invoke(d, enable);
            }
            else
            {
                Checked_RCS_Connect.Enabled = enable;
            }
        }

        delegate void dControlEnable(Object obj, bool enable);
        private void ControlEnable(Object obj, bool enable)
        {
            if ((obj as Control).InvokeRequired)
            {
                dControlEnable d = new dControlEnable(ControlEnable);
                (obj as Control).Invoke(d, new object[] { obj, enable });
            }
            else
            {
                (obj as Control).Enabled = enable;
            }
        }
        #endregion
    }
}