﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;


using CL.Communicate;


namespace TestPattern
{
    public class TestItem
    {
        public struct SPrompt
        {
            public string UBoot { get; set; }
            public string WNC { get; set; }
            public string Clix { get; set; }
            public string Meraki { get; set; }
        }

        public class CDoTestParameter
        {
            public int Retry { get; set; }
            public int TimeOutSec { get; set; }
            public string ItemName { get; set; }
            public string Command { get; set; }
            public string[] CheckMessage { get; set; }
        }

        private readonly ICommunication communication;
        private readonly ICommonAPI commonAPI;
        private SPrompt _prompt = new SPrompt();

        public SPrompt Prompt { get { return _prompt; } }

        public TestItem(ICommunication pCommunication, ICommonAPI pCommonAPI)
        {
            communication = pCommunication;
            commonAPI = pCommonAPI;

            _prompt.UBoot = commonAPI.ReadINI("Setting", "Prompt", "UBoot", "ZynqMP>");
            _prompt.WNC = commonAPI.ReadINI("Setting", "Prompt", "WNC", "#");
            _prompt.Clix = commonAPI.ReadINI("Setting", "Prompt", "Clix", "Command>");
            _prompt.Meraki = commonAPI.ReadINI("Setting", "Prompt", "Meraki", "<Meraki>");
        }

        public bool DoTest(CDoTestParameter parameter)
        {
            Ctrl itemEnable = commonAPI.GetCtrl(commonAPI.ReadINI("Setting", commonAPI.Information.Station, parameter.ItemName, "Enable"));

            for (int i = 0; i < parameter.Retry; ++i)
            {
                if (communication.SendAndCheckMultiple(parameter.Command, parameter.CheckMessage, parameter.TimeOutSec))
                {
                    return true;
                }

                commonAPI.AddMessage(MessageTag.RETRY, parameter.ItemName + " retry count: " + (i + 1));
            }

            return false;
        }

        private string GetMerakiResponse(string cmd)
        {
            string recvMsg = "";
            string pattern = @cmd + @"(?<Val>(.|\r|\n)*)" + Prompt.Meraki;
            bool testResult = communication.SendAndReceiveCheck(cmd, Prompt.Meraki, 10, ref recvMsg);

            try
            {
                string[] getResult = Regex.Match(recvMsg.Trim(), pattern).Groups["Val"].Value.Trim().Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                commonAPI.AddMessage(MessageTag.INFO, ("Get length: " + getResult.Length + "; Get : " + getResult[0]));
                return getResult[0];
            }
            catch (Exception ex)
            {
                commonAPI.AddMessage(MessageTag.ERROR, ("{SendCommandGetResult} " + ex.Message));
                return "";
            }
        }

        public bool ReadMFGDone()
        {
            string getRes = GetMerakiResponse("odm mfg_done read");

            if (string.IsNullOrEmpty(getRes))
            {
                return false;
            }
            else
            {
                return (getRes == "true");
            }
        }

        public bool CheckMerakiFirmware(string testitem)
        {
            bool testResult = true;
            bool mfgDone = ReadMFGDone();

            string fw = commonAPI.ReadINI("Setting", "Meraki", "FW", "NONE");
            string getFW = GetMerakiResponse("odm fw_version");

            commonAPI.AddMessage(MessageTag.LOG, ("SPEC-Firmware: " + fw + "; Get-Firmware: " + getFW));

            //  The DUT from RI room, customer maybe upgrade F/W, so not need to check F/W,
            //  just record to SFCS fifteen line.
            if (mfgDone)
            {
                commonAPI.AddMessage(MessageTag.LOG, ("Not check F/W."));
                testResult = true;
            }
            else
            {
                testResult = (getFW == fw);
            }

            commonAPI.WriteSFCSLine("15", "FW", getFW);
            commonAPI.WriteSFCSLine("15", "RI", mfgDone.ToString());

            return commonAPI.AddTestItemResult(testitem, testResult);
        }
    }
}
