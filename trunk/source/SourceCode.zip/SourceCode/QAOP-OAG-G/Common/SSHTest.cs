﻿using CL.API;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Reflection;

using CL.Communicate;
using TestPattern;
using System.Text;


namespace Common
{
    class SSHTest  : SSHClientManagement
    {

        //private IFixture _fixture = null;
        public ICommonAPI CommonAPI = null;
        public string Prompt = "";
        public string Pattern = "";
        //public string DUTIP { get { return "192.168.1.1"; } }
        //public string LoginString { get { return "192.168.1.1"; } }
        //public string Password { get { return "192.168.1.1"; } }

        public SSHTest(ICommonAPI commonAPI)
        {
            CommonAPI = commonAPI;
            //_fixture = fixture;
            AddMessageEvent += new AddMessageHandler(CommonAPI.AddLog);
            Prompt = CommonAPI.ReadINI("Setting", "Prompt", "LinuxPC", "$");
            Pattern = CommonAPI.ReadINI("Setting", "Pattern", "Pattern", "[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]");
        }


        public bool LoginSSH(string testItem)
        {
            string cliantIP = CommonAPI.ReadINI("Setting", "LinuxPC", "IP", "192.168.33.124");
            string loginString = CommonAPI.ReadINI("Setting", "LinuxPC", "User", "test");
            string password = CommonAPI.ReadINI("Setting", "LinuxPC", "Password", "test!@#$");

            //bool testResult = Connection(new ConnectionData() { ClientIP = cliantIP, LoginString = loginString, Password = password, Prompt = Prompt, TimeOutSec = 20, });
            bool testResult = Connection(new SSHClientManagement.ConnectionData() { IP = cliantIP, Port = 22, UserName = loginString, Password = password, Prompt = Prompt, Timeout = 100 });
            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool SendAndCheck(string testItem, string data, string[] checkMsg, int timeoutSec)
        {
            return CommonAPI.AddTestItemResult(testItem, SendAndCheckMultiple(data, checkMsg, timeoutSec));
        }

        public bool ExcuteDialog(string testItem)
        {
            bool testResult = true;
            string password = CommonAPI.ReadINI("Setting", "LinuxPC", "Password", "test!@#$");
            string recvMsg = "";

            testResult = testResult && SendAndCheckMultiple("cd /usr/local/bin/", new string[] { Prompt }, 10);
            testResult = testResult && SendAndCheckMultiple("sudo ./dialog-menu", new string[] { "[sudo] password for test:" }, 10);
            //testResult = testResult && SendAndCheckMultiple(password, new string[] { "OK" }, 20);
            testResult = testResult && SendAndReceiveCheck(password, "OK", 20, ref recvMsg);

            //string x = recvMsg.Replace(@"\033\[[0-9;]*m","");
            //string x = Regex.Replace(@"\033\[[0-9;]*m", "");
            //string x = Regex.Replace(recvMsg, @"\033\[[0-9;]*m", " " );
            //\(0|\(B\033\[[0-9;]*m|\033\[[0-9;]*m|\033\[[0-9;]*G|\033\[[0-9;]*X
            //\u001b[31m
            //\u001b\[[0-9;]*m
            //[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]
            //\u001b(\[[0-9;]*m|\(B|\(0|\[[0-9;]*H|\[K)

            string x = Regex.Replace(recvMsg, @Pattern, "");
            AddMessage(MessageTag.LOG, x);


            //string pattern = Regex.Unescape(recvMsg);

            //AddMessage(MessageTag.LOG, pattern);//"\\033\\[" + k + "m"
            //testResult = SendAndReceiveCheck("cat /proc/mtd | grep ART", Prompt, 10, ref recvMsg);

            return CommonAPI.AddTestItemResult(testItem, testResult);

        }

        public bool SandKey(string testItem)
        {
            bool testResult = true;
            string password = CommonAPI.ReadINI("Setting", "LinuxPC", "Password", "test!@#$");
            string recvMsg = "";

            testResult = testResult && SendByte(new byte[] { 0x1b, 0x4f, 0x42 });
            testResult = testResult && ReceiveMessageDuringPeriod(3, 1, ref recvMsg);

            //AddMessage(MessageTag.LOG, recvMsg);

            string x = Regex.Replace(recvMsg, @Pattern, "");
            AddMessage(MessageTag.LOG, x);

            //string pattern = Regex.Escape(recvMsg);

            //AddMessage(MessageTag.LOG, pattern);//"\\033\\[" + k + "m"
            //testResult = SendAndReceiveCheck("cat /proc/mtd | grep ART", Prompt, 10, ref recvMsg);

            return CommonAPI.AddTestItemResult(testItem, testResult);

        }

        public bool SandEnter(string testItem)
        {
            bool testResult = true;
            string password = CommonAPI.ReadINI("Setting", "LinuxPC", "Password", "test!@#$");
            string recvMsg = "";

            testResult = testResult && SendByte(new byte[] { 0xa });
            testResult = testResult && ReceiveMessageDuringPeriod(3, 1, ref recvMsg);
            //string x = recvMsg.Replace(@"\033\[[0-9;]*m","");
            //string x = Regex.Replace(@"\033\[[0-9;]*m", "");
            //string x = Regex.Replace(recvMsg, @"\033\[[0-9;]*m", " " );
            //\(0|\(B\033\[[0-9;]*m|\033\[[0-9;]*m|\033\[[0-9;]*G|\033\[[0-9;]*X

            //AddMessage(MessageTag.LOG, recvMsg);

            string x = Regex.Replace(recvMsg, @Pattern, "");
            AddMessage(MessageTag.LOG, x);


            //string pattern = Regex.Escape(recvMsg);

            //AddMessage(MessageTag.LOG, pattern);//"\\033\\[" + k + "m"
            //testResult = SendAndReceiveCheck("cat /proc/mtd | grep ART", Prompt, 10, ref recvMsg);



            return CommonAPI.AddTestItemResult(testItem, testResult);

        }


    }
}
