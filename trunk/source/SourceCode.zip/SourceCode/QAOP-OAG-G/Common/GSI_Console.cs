﻿using CL.API;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.Linq;
using System.Reflection;

using CL.Communicate;
using TestPattern;
using System.Globalization;




namespace Common
{
    public class GSI_Console 
    {
        public enum ETargetTestMenu
        {
            None = -1,
            Board = 0,
            ENV = 1,
            Manual = 2,
        }

        public SerialPortManager _serial = null;
        public SerialPortManager _serialUART = null;
        public ICommonAPI CommonAPI = null;
        private TestItem testItems = null;
        private ETargetTestMenu _targetTestMode = ETargetTestMenu.None;
        private Dictionary<string, string> InputData = new Dictionary<string, string>();
        TextInfo myTI = new CultureInfo("en-US", false).TextInfo;

        public GSI_Console(ICommonAPI commonAPI)
        {
            CommonAPI = commonAPI;
            string characterReturn = CommonAPI.ReadINI("Setting", "DUT", "CharacterReturn", "\r");
            _serial = new SerialPortManager(characterReturn);
            _serialUART = new SerialPortManager();

            _serial.AddMessageEvent += new BaseManagement.AddMessageHandler(CommonAPI.AddLog);
            _serialUART.AddMessageEvent += new BaseManagement.AddMessageHandler(CommonAPI.AddLog);
            testItems = new TestItem(_serial, CommonAPI);
        }

        public void AddInputData(string name, string value)
        {
            try
            {
                string correctName = name.ToUpper();
                CommonAPI.AddMessage(MessageTag.LOG, (correctName + ": " + value));

                if (InputData.ContainsKey(correctName))
                {
                    InputData[correctName] = value;
                }
                else
                {
                    InputData.Add(correctName, value);
                }
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ("{AddInputData} " + ex.Message));
            }
        }

        public bool InitCOMPort(string portName = "")
        {
            string comPort = "";

            if (string.IsNullOrEmpty(portName))
            {
                comPort = CommonAPI.ReadINI("Setting", "DUT", "COMPort", "COM23");
            }

            bool initCOM = _serial.Connection(comPort, 115200);

            if (!initCOM)
            {
                CommonAPI.WriteWarning("Cannot open " + comPort);
            }

            return initCOM;
        }

        public bool FreeComPort()
        {
            try
            {
                string comPort = CommonAPI.ReadINI("Setting", "DUT", "COMPort", "COM23");
                return _serial.DisConnection();
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ex.Message);
                return false;
            }
        }

        public bool InitUARTPort(string portName = "")
        {
            string comPort = "";

            if (string.IsNullOrEmpty(portName))
            {
                comPort = CommonAPI.ReadINI("Setting", "DUT", "UARTPort", "COM22");
            }

            bool initCOM = _serialUART.Connection(comPort, 9600);

            if (!initCOM)
            {
                CommonAPI.WriteWarning("Cannot open " + comPort);
            }

            return initCOM;
        }

        public bool FreeUARTPort()
        {
            try
            {
                string comPort = CommonAPI.ReadINI("Setting", "DUT", "UARTPort", "COM22");
                return _serialUART.DisConnection();
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ex.Message);
                return false;
            }
        }

        public bool SendAndCheck(string testItem, string data, string[] checkMsg, int timeOutSec)
        {
            return CommonAPI.AddTestItemResult(testItem, _serial.SendAndCheckMultiple(data, checkMsg, timeOutSec));
        }

        public bool StopAtUboot(string testItem)
        {//Hit any key to stop autoboot:
            bool testResult = false;
            string recvMsg = "";
            try
            {
                _serial.WaiteKeyword("Hit any key to stop autoboot:", 60, ref recvMsg);

                for (int i = 0; i < 60; ++i)
                {
                    testResult = _serial.SendAndCheckMultiple("", new string[] { testItems.Prompt.UBoot }, 1);

                    if (testResult)
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ex.ToString());
                InitCOMPort();
                testResult = false;
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool UbootToKernel(string testItem)
        {
            bool testResult = true;

            testResult = testResult && _serial.SendAndCheckMultiple("bootm", new string[] { "Press <Ctrl-C> to stop", "GSI system" }, 30);
            testResult = testResult && _serial.SendByteAndCheckMultiple(new byte[] { 0x3 }, new string[] { testItems.Prompt.WNC }, 30);

            _targetTestMode = ETargetTestMenu.None;

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool BootUp(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";

            try
            {
                //testResult = testResult && _serial.WaiteKeyword("GSI system", 300, ref recvMsg);
                //testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { testItems.Prompt.WNC }, 20);
                testResult = testResult && _serial.WaiteKeyword("Press <Ctrl-C> to stop", 300, ref recvMsg);
                testResult = testResult && _serial.SendByteAndCheckMultiple(new byte[] { 0x3 }, new string[] { testItems.Prompt.WNC }, 30);
                _targetTestMode = ETargetTestMenu.None;
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ex.ToString());
                InitCOMPort();
                testResult = false;
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool BootUpAfterUpgrade(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";

            try
            {
                testResult = testResult && _serial.WaiteKeyword("GSI system", 300, ref recvMsg);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { testItems.Prompt.WNC }, 20);
                //testResult = testResult && _serial.WaiteKeyword("Press <Ctrl-C> to stop", 300, ref recvMsg);
                //testResult = testResult && _serial.SendByteAndCheckMultiple(new byte[] { 0x3 }, new string[] { testItems.Prompt.WNC }, 30);
                _targetTestMode = ETargetTestMenu.None;
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ex.ToString());
                InitCOMPort();
                testResult = false;
            }
            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool SoftwareCheck(string testItem)
        {//\-?(?<ItemName>(.)+)(:\s|=)(?<ItemValue>.+)
            bool testResult = true;
            string recvMsg = "";

            testResult = testResult && _serial.SendAndReceiveCheck("cat /run/media/mmcblk0p1/version-image-gsi-tests-leda-e", testItems.Prompt.WNC, 10, ref recvMsg);  // cat /run/media/mmcblk0p1/version-image-gsi-tests

            MatchCollection matchCollection = Regex.Matches(recvMsg, @"\-?(?<Item>(.)+)(:\s|=)(?<Value>.+)");
            testResult = testResult && (matchCollection.Count >= 12);

            string item = "", itemResult = "";

            if (testResult)
            {
                foreach (Match match in matchCollection)
                {
                    item = match.Groups["Item"].Value.Trim();
                    item = Regex.Replace(item, @"[^\w_]", "_").Trim();
                    item = Regex.Replace(item, @"_+", "_").Trim();

                    string[] word = item.Split('_');
                    string[] wordSelect = null;

                    if (item.Length > 20)
                    {
                        if (item.Length <= 24 && (item.IndexOf("version", StringComparison.OrdinalIgnoreCase) >= 0))
                        {                          
                            int verIndex = Array.IndexOf(word, "version");
                            word[verIndex] = "ver";
                            wordSelect = word.Select(v => v.Substring(0, 1).ToUpper() + v.Substring(1, v.Length - 1)).ToArray();
                        }
                        else
                        {
                            wordSelect = word.Select((v, i) => new { Index = i, Value = v })
                                                .Where(x => x.Index == 0 | x.Index == 2 | x.Index == 3 | x.Index == 4)
                                                    .Select(x => x.Value.Substring(0, 1).ToUpper() + x.Value.Substring(1, x.Value.Length - 1)).ToArray();
                        }
                    }
                    else
                    {
                        wordSelect = word.Select(v => v.Substring(0, 1).ToUpper() + v.Substring(1, v.Length - 1)).ToArray();
                    }

                    CommonAPI.AddMessage(MessageTag.LOG, "Rename \"" + item + "\" to \"" + String.Join("_", wordSelect)+"\"");

                    item = String.Join("_", wordSelect);                   
                    itemResult = match.Groups["Value"].Value.Trim();

                    string ver = CommonAPI.ReadINI("Setting", "FW", item, "None");

                    if (ver != itemResult)
                    {
                        CommonAPI.AddMessage(MessageTag.ERROR, "item :" + itemResult);
                        testResult = false;
                        break;
                    }

                    CommonAPI.WriteSFCSLine("15", item, itemResult);              
                }
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool TargetTest(string testItem)
        {
            bool testResult = true;
            testResult = _serial.SendAndCheckMultiple("sh /run/media/mmcblk0p1/scripts/stop_gsi_cli_test_app.sh", new string[] { testItems.Prompt.WNC }, 10);
            testResult = _serial.SendAndCheckMultiple("cd /run/media/mmcblk0p1/gsi-cli/", new string[] { testItems.Prompt.WNC }, 10);
            testResult = testResult && _serial.SendAndCheckMultiple("./target-test", new string[] { "Enter option number", "APU board test menu" }, 10);
            if (testResult)
            {
                _targetTestMode = ETargetTestMenu.Board;
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool GetTargetTestMenu(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";

            if (_targetTestMode != ETargetTestMenu.None)
            {
                testResult = _serial.SendAndReceiveCheck("", "Enter option number :", 10, ref recvMsg);
                if (testResult)
                {
                    if (recvMsg.Contains("APU board test menu"))
                        _targetTestMode = ETargetTestMenu.Board;
                    else if (recvMsg.Contains("APU Sanity ENV settings board tests menu"))
                        _targetTestMode = ETargetTestMenu.ENV;
                    else if (recvMsg.Contains("APU Sanity manual board tests menu"))
                        _targetTestMode = ETargetTestMenu.Manual;
                    else
                        _targetTestMode = ETargetTestMenu.None;
                }
            }
            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool CheckTargetTestMenu(string testItem, ETargetTestMenu MenuMode)
        {
            bool testResult = true;
            ETargetTestMenu Menu = MenuMode;// (ETargetGetMenu)Enum.Parse(typeof(ETargetGetMenu), MenuMode, false);

            if (_targetTestMode == Menu)
            {
                testResult= true;
            }
            else
            {
                if (_targetTestMode == ETargetTestMenu.None)
                {
                    CommonAPI.AddMessage(MessageTag.ERROR, ("Not in Target Test, cannot been checked" ));
                    testResult= false;
                }

                Type type = this.GetType();
                MethodInfo method = type.GetMethod(_targetTestMode.ToString() + "ToFunc", (BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public));
                testResult = (bool)method.Invoke(this, new object[] { Menu });

                if (testResult)
                {
                    _targetTestMode = Menu;
                }               
            }
            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        private bool BoardToFunc(ETargetTestMenu Menu)
        {
            if (Menu == ETargetTestMenu.ENV)
            {
                return _serial.SendAndCheckMultiple("8", new string[] { "Enter option number", "ENV settings board tests menu" }, 20);
            }
            else if (Menu == ETargetTestMenu.Manual)
            {
                return _serial.SendAndCheckMultiple("2", new string[] { "Enter option number", "manual board tests menu" }, 20);
            }
            else
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ("TargetTest Mode error"));
                return false;
            }
        }

        private bool ENVToFunc(ETargetTestMenu Menu)
        {
            bool testResult = false;

            if (Menu == ETargetTestMenu.Board)
            {
                testResult = _serial.SendAndCheckMultiple("3", new string[] { "press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Enter option number", "APU board test menu" }, 20);
            }
            else if (Menu == ETargetTestMenu.Manual)
            {
                testResult = _serial.SendAndCheckMultiple("3", new string[] { "press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Enter option number", "APU board test menu" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("2", new string[] { "Enter option number", "manual board tests menu" }, 20);
            }
            else
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ("TargetTest Mode error"));
                return false;
            }

            return testResult;
        }

        private bool ManualToFunc(ETargetTestMenu Menu)
        {
            bool testResult = false;

            if (Menu == ETargetTestMenu.Board)
            {
                testResult = _serial.SendAndCheckMultiple("10", new string[] { "press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Enter option number", "APU board test menu" }, 20);
            }
            else if (Menu == ETargetTestMenu.ENV)
            {
                testResult = _serial.SendAndCheckMultiple("10", new string[] { "press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Press key to continue" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Enter option number", "APU board test menu" }, 20);
                testResult = testResult && _serial.SendAndCheckMultiple("8", new string[] { "Enter option number", "ENV settings board tests menu" }, 20);
            }
            else
            {
                CommonAPI.AddMessage(MessageTag.ERROR, ("TargetTest Mode error"));
                return false;
            }

            return testResult;
        }

        public bool WriteMAC(string testItem)
        {
            bool testResult = true;

            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.ENV);
            testResult = testResult && _serial.SendAndCheckMultiple("1", new string[] { "new MAC address:" }, 20);
            testResult = testResult && _serial.SendAndCheckMultiple("1", new string[] { "press enter" }, 20);

            CommonAPI.AddMessage(MessageTag.LOG, ("Input MAC: " + InputData["MAC"]));

            testResult = testResult && _serial.SendAndCheckMultiple(InputData["MAC"], new string[] { "press key to continue...", "OK" }, 20);
            testResult = testResult && GetTargetTestMenu(testItem);
           
            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool WriteSN(string testItem)
        {
            bool testResult = true;
            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.ENV);
            testResult = testResult && _serial.SendAndCheckMultiple("2", new string[] { "256 characters:" }, 20);
            testResult = testResult && _serial.SendAndCheckMultiple("1", new string[] { "press enter" }, 20);

            CommonAPI.AddMessage(MessageTag.LOG, ("Input SN: " + InputData["DUTSN"]));

            testResult = testResult && _serial.SendAndCheckMultiple(InputData["DUTSN"], new string[] { "press key to continue...", "OK" }, 20);
            testResult = testResult && GetTargetTestMenu(testItem);

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool WriteBoardType(string testItem)
        {
            bool testResult = true;
            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.ENV);
            testResult = testResult && _serial.SendAndCheckMultiple("5", new string[] { "256 characters:" }, 20);
            testResult = testResult && _serial.SendAndCheckMultiple("1", new string[] { "press enter" }, 20);

            CommonAPI.AddMessage(MessageTag.LOG, ("Input BoardType : " + InputData["BOARDTYPE"]));

            testResult = testResult && _serial.SendAndCheckMultiple(InputData["BOARDTYPE"], new string[] { "press key to continue...", "OK" }, 20);
            testResult = testResult && GetTargetTestMenu(testItem);

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool SaveEnv(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";

            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.ENV);
            testResult = testResult && _serial.SendAndReceiveCheck("3", "status", 30, ref recvMsg);

            if (recvMsg.Contains("new vlaues"))
            {//Restarting system

                testResult = testResult && _serial.WaiteKeyword("link down", 30, ref recvMsg);
                Thread.Sleep(10000);
                testResult = testResult && InitCOMPort();
                testResult = testResult && BootUp(testItem);
                testResult = testResult && TargetTest(testItem);
            }
            else
            {
                testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Press key to continue..." }, 10);
                testResult = testResult && GetTargetTestMenu(testItem);
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool CheckBoardENV(string testItem)//GSI board\s(?<item>.+)\s=\s(?<value>.+)
        {
            bool testResult = true;
            string recvMsg = "";

            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.ENV);
            testResult = testResult && _serial.SendAndReceiveCheck("4", "press key to continue...", 10, ref recvMsg);

            MatchCollection matchCollection = Regex.Matches(recvMsg, @"GSI board\s(?<item>.+)\s=\s(?<value>.+)");
            testResult = testResult && (matchCollection.Count >= 3);

            string item = "", itemResult = "";

            if (testResult)
            {
                foreach (Match match in matchCollection)
                {
                    item = match.Groups["item"].Value.Trim();
                    itemResult = match.Groups["value"].Value.Trim();

                    if (item.Contains("serial"))
                    {
                        testResult = testResult && (InputData["DUTSN"] == itemResult);
                        CommonAPI.AddTestItemResult("CheckSN", testResult);
                    }

                    if (item.Contains("MAC"))
                    {
                        testResult = testResult && (InputData["MAC"] == itemResult);
                        CommonAPI.AddTestItemResult("CheckMAC", testResult);
                    }

                    if (item.Contains("type"))
                    {
                        testResult = testResult && (InputData["BOARDTYPE"] == itemResult);
                        CommonAPI.AddTestItemResult("CheckBoardType", testResult);
                        CommonAPI.WriteSFCSLine("15", "BoardType", itemResult);  
                    }

                    if (!testResult)
                    {
                        break;
                    }
                }
            }
            else
            {
                CommonAPI.AddMessage(MessageTag.LOG, "GSI board ENV count not match (" + matchCollection.Count + ")");               
            }

            testResult = testResult && GetTargetTestMenu(testItem);

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool VoltageCheck(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";

            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.Board);
            testResult = testResult && _serial.SendAndReceiveCheck("9", "display", 30, ref recvMsg);
            testResult = testResult && _serial.SendAndReceiveCheck("1", "main menu", 30, ref recvMsg);

            MatchCollection matchCollection = Regex.Matches(recvMsg, @"VOUT\s-\s(?<Item>\w+)\s=\s+(?<Value>\d+.?\d+)\s\(V\)\s+-\s+Volt");
            testResult = testResult && (matchCollection.Count >= 9);

            if (testResult)
            {
                foreach (Match match in matchCollection)
                {
                    string item = match.Groups["Item"].Value.Trim();
                    double value = Convert.ToDouble(match.Groups["Value"].Value.Trim());

                    testResult = testResult && CommonAPI.AddTestItemByValue(item, value);
                }
            }

            testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Press key to continue" }, 20);
            testResult = testResult && GetTargetTestMenu(testItem);

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool I2CCheck(string testItem)
        {
            // 00:          -- -- -- -- -- -- -- -- -- 0c -- -- --
            // 10: 10 -- -- -- 14 -- -- -- -- -- -- -- 1c -- -- --
            // 20: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
            // 30: 30 -- -- -- 34 -- -- -- -- -- -- -- -- -- -- --
            // 40: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
            // 50: -- -- -- -- 54 -- -- -- -- -- -- -- -- -- -- --
            // 60: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
            // 70: -- -- -- -- -- -- -- --

            bool testResult = true;
            string recvMsg = "";
            string[] keywords = new string[] 
            { 
              //"00:          -- -- -- -- -- -- -- -- -- 0c -- -- --",
              "10: 10 -- -- -- 14 -- -- -- -- -- -- -- 1c -- -- --",
              "20: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --",
              //"30: 30 -- -- -- 34 -- 36 -- -- -- -- -- -- -- -- --",    // 36
              "40: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --",
              "50: -- -- -- -- 54 -- -- -- -- -- -- -- -- -- -- --",
              "60: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --",
              "70: -- -- -- -- -- -- -- --",
              "press key to continue"};

            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.Board);
            testResult = testResult && _serial.SendAndReceiveCheck("2", "Enter option number", 10, ref recvMsg);
            testResult = testResult && _serial.SendAndReceiveCheck("24", "I2C buses", 10, ref recvMsg);  // I2C buses(0 &amp; 1)
            testResult = testResult && _serial.SendAndCheckMultiple("2", keywords, 10);

            //testResult = testResult && _serial.SendAndCheckMultiple("", new string[] { "Press key to continue" }, 20);
            testResult = testResult && GetTargetTestMenu(testItem);

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool PowerRailsCheck(string testItem)
        {
            try
            {
                bool testResult = true;
                string recvMsg = "";
                string[] msg;

                int number = 0;
                double value = 0;

                testResult = testResult && _serial.SendAndReceiveCheck("sh /run/media/mmcblk0p1/scripts/mon_board_params_i2c_test.sh -p 10 -n 2", testItems.Prompt.WNC, 40, ref recvMsg);

                msg = recvMsg.Replace("\r\n", "$").Split('$');

                if (!testResult)
                {
                    return CommonAPI.AddTestItemResult(testItem, false);
                }

                for (int i = 0; i < msg.Length; i++)
                {
                    if (msg[i].Contains("The power rail is " + number.ToString()))
                    {
                        value = Convert.ToInt16(msg[i + 6].Trim(), 16);

                        CommonAPI.AddTestItemByValue(testItem + "_" + number.ToString(), value);

                        if (!CommonAPI.CheckFailTest())
                        {
                            return CommonAPI.AddTestItemResult(testItem, false);
                        }

                        value = Convert.ToInt16(msg[i + 7].Trim(), 16);

                        CommonAPI.AddTestItemByValue(testItem + "_" + number.ToString(), value);

                        if (!CommonAPI.CheckFailTest())
                        {
                            return CommonAPI.AddTestItemResult(testItem, false);
                        }

                        number++;
                        i = i + 7;
                    }

                    if (number == 9)
                    {
                        break;
                    }
                }

                return CommonAPI.AddTestItemResult(testItem, testResult);
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, "{PowerRailsCheck} " + ex.Message);
                return CommonAPI.AddTestItemResult(testItem, false);
            }
        }

        public bool RTCTest(string testItem, DateTime utcTime)
        {
            bool testResult = true;
            DateTime SFCSTime = utcTime;

            //testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.Manual);
            //testResult = testResult && _serial.SendAndCheckMultiple("20", new string[] { "display new CLK" }, 20);
            //testResult = testResult && _serial.SendAndCheckMultiple("1", new string[] { "year between 2000 - 3000" }, 20);

            testResult = testResult && _serial.SendAndCheckMultiple(SFCSTime.ToString("yyyy"), new string[] { "month between 1 - 12" }, 10);
            testResult = testResult && _serial.SendAndCheckMultiple(SFCSTime.ToString("MM"), new string[] { "day between 1 - 31" }, 10);
            testResult = testResult && _serial.SendAndCheckMultiple(SFCSTime.ToString("dd"), new string[] { "hour between 0 - 23" }, 10);
            testResult = testResult && _serial.SendAndCheckMultiple(SFCSTime.ToString("HH"), new string[] { "minutes between 0 - 59" }, 10);
            testResult = testResult && _serial.SendAndCheckMultiple(SFCSTime.ToString("mm"), new string[] { "seconds between 0 - 59" }, 10);
            testResult = testResult && _serial.SendAndCheckMultiple(SFCSTime.ToString("ss"), new string[] { "press key to continue...", SFCSTime.ToString("yyyy-MM-dd HH:mm:ss") }, 10);
            
            testResult = testResult && GetTargetTestMenu(testItem);
            
            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool UARTTest(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";

            testResult = testResult && InitUARTPort();
            testResult = testResult && CheckTargetTestMenu(testItem, ETargetTestMenu.Manual);
            testResult = testResult && _serial.SendAndCheckMultiple("23", new string[] { "test:" }, 20);
            testResult = testResult && _serial.SendAndCheckMultiple("1", new string[] { "?:" }, 20);

            recvMsg = _serialUART.Receive();
            CommonAPI.AddMessage(MessageTag.LOG, recvMsg);          
     
            testResult = testResult && _serial.SendAndCheckMultiple(recvMsg.Contains("GSI WNC Test Tx") ? "1" : "0", new string[] { "press key to continue...", "passed" }, 20);
            testResult = testResult && GetTargetTestMenu(testItem);

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool CheckENV(string testItem)//GSI board\s(?<item>.+)\s=\s(?<value>.+)
        {
            bool testResult = true;
            string recvMsg = "";

            testResult = testResult && _serial.SendAndReceiveCheck("cat /run/media/mmcblk0p1/uEnv.txt", testItems.Prompt.WNC, 10, ref recvMsg);

            MatchCollection matchCollection = Regex.Matches(recvMsg, @"(?<item>.+)=(?<value>.+)");
            testResult = testResult && (matchCollection.Count >= 3);

            string item = "", itemResult = "";

            if (testResult)
            {
                foreach (Match match in matchCollection)
                {
                    item = match.Groups["item"].Value.Trim();
                    itemResult = match.Groups["value"].Value.Trim();

                    if (item.Contains("gsi_sn"))
                    {
                        testResult = testResult && (InputData["DUTSN"] == itemResult);
                        CommonAPI.AddTestItemResult("CheckSN", testResult);
                    }

                    if (item.Contains("ethaddr"))
                    {
                        testResult = testResult && (InputData["MAC"] == itemResult);
                        CommonAPI.AddTestItemResult("CheckMAC", testResult);
                    }

                    if (!testResult)
                    {
                        break;
                    }
                }
            }
            else
            {
                CommonAPI.AddMessage(MessageTag.LOG, "GSI ENV count not match (" + matchCollection.Count + ")");
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool CheckRTC(string testItem, DateTime sfcsTime)
        {
            bool testResult = true;
            string recvMsg = "";
            string pattern = @"(?<Val>\w{3}\s\w{3}\s+\d+\s\d{2}:\d{2}:\d{2}\sUTC\s\d{4})";

            testResult = testResult && _serial.SendAndReceiveCheck("date", testItems.Prompt.WNC, 10, ref recvMsg);

            Match getDate = Regex.Match(recvMsg, @pattern);

            testResult = testResult && getDate.Success;
            testResult = testResult && VerifyDate(getDate.ToString(), sfcsTime);
            
            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        private bool VerifyDate(string checkDate, DateTime sfcsTime)//date -u\r\nFri Sep  6 09:52:10 UTC 2019\r\nDIAG:~ #
        {   //Thu Mar 19 09:51:14 UTC 2020
            bool checkResult = true;

            CommonAPI.AddMessage(MessageTag.LOG, "DUT Time: " + checkDate);

            try
            {
                string[] tempDate = checkDate.Split(new string[] { "UTC" }, System.StringSplitOptions.RemoveEmptyEntries);
                double spec = Convert.ToInt16(CommonAPI.ReadINI("Setting", "RTC", "Tolerance", "15"));  // 20 , 40

                if (tempDate.Length == 2)
                {
                    Array.Reverse(tempDate);
                    string testDate = String.Join(" ", tempDate);
                    DateTime dutDate = Convert.ToDateTime(testDate);
                    TimeSpan ts = dutDate - sfcsTime;
                    double diff = Math.Abs(ts.TotalSeconds);

                    if (diff <= spec)     // 15
                    {
                        CommonAPI.AddMessage(MessageTag.LOG, "Time diff . ( " + diff.ToString() + ")");
                        checkResult = true;
                    }
                    else
                    {
                        CommonAPI.AddMessage(MessageTag.LOG, "Time diff not in spec. ( " + diff.ToString() + ")");
                        checkResult = false;
                    }
                }
                else
                {
                    CommonAPI.AddMessage(MessageTag.LOG, "DUT Date format error :" + checkDate);
                    checkResult = false;
                }
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, "{VerifyDate} " + ex.ToString());
                checkResult = false;
            }

            return checkResult;
        }

        public bool UpgradeReleaseVer(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";


            _serial.Send("./upgrade_to_release_ver.sh");

            testResult = _serial.WaiteKeyword("Filesystem has been set read-only", 10, ref recvMsg);

            if (testResult)
            {
                testResult = testResult && _serial.SendByteAndCheckMultiple(new byte[] { 0x3 }, new string[] { "#" }, 30);
                testResult = testResult && _serial.SendAndReceiveCheck("mount -o remount, rw /run/media/mmcblk0p1", "#", 30, ref recvMsg);
                testResult = testResult && _serial.SendAndReceiveCheck("mount -o remount", "#", 30, ref recvMsg);
                testResult = testResult && _serial.SendAndReceiveCheck("cd /run/media", "#", 30, ref recvMsg);
                testResult = testResult && _serial.SendAndCheckMultiple("./upgrade_to_release_ver.sh ", new string[] { "Shutdown GSI board" }, 300);
                System.Threading.Thread.Sleep(5 * 1000);
            }
            else
            {
                testResult = true;
                testResult = testResult && _serial.WaiteKeyword("Power down", 300, ref recvMsg);

                if (!recvMsg.Contains("Shutdown GSI board"))
                {
                    testResult = false;
                }
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }
    }
}
