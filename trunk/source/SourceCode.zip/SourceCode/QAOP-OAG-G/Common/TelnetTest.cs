﻿using CL.API;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using System.Reflection;
using System.Linq;
using System.Text.RegularExpressions;

using CL.Communicate;
using TestPattern;
using System.Text;


namespace Common
{
    class TelnetTest : TelnetClientManagement
    {

        public enum EDialogMenu
        {
            None = -1,
            Mainn = 0,
            DRAM = 1,
            Manual = 2,
        }


        //private IFixture _fixture = null;
        public ICommonAPI CommonAPI = null;
        public string Prompt = "";
        public string Pattern = "";
        public string DaigSelection = "";
        //public string DUTIP { get { return "192.168.1.1"; } }
        //public string LoginString { get { return "192.168.1.1"; } }
        //public string Password { get { return "192.168.1.1"; } }

        public TelnetTest(ICommonAPI commonAPI)
        {
            CommonAPI = commonAPI;
            //_fixture = fixture;
            AddMessageEvent += new AddMessageHandler(CommonAPI.AddLog);
            Prompt = CommonAPI.ReadINI("Setting", "Prompt", "LinuxPC", "$");
            Pattern = CommonAPI.ReadINI("Setting", "Pattern", "Pattern", @"\u0000?[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqrty=><]");
        }

        public bool LoginTelnet(string testItem)
        {
            string clientIP = CommonAPI.ReadINI("Setting", "LinuxPC", "IP", "192.168.33.124");
            string loginString = CommonAPI.ReadINI("Setting", "LinuxPC", "User", "test");
            string password = CommonAPI.ReadINI("Setting", "LinuxPC", "Password", "test!@#$");

            bool testResult = Connection(new ConnectionData() { ClientIP = clientIP, LoginString = loginString, Password = password, Prompt = Prompt, TimeOutSec = 30, });

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool LogoutTelnet(string testItem)
        {
            return CommonAPI.AddTestItemResult(testItem, DisConnection()); 
        }

        public bool SendAndCheck(string testItem, string data, string[] checkMsg, int timeoutSec)
        {
            return CommonAPI.AddTestItemResult(testItem, SendAndCheckMultiple(data, checkMsg, timeoutSec));
        }

        public bool RebootLinux(string testItem,bool sudoPwd)
        {
            bool testResult = true;
            string password = CommonAPI.ReadINI("Setting", "LinuxPC", "Password", "test!@#$");
           
            if (sudoPwd)
            {
                testResult = testResult && SendAndCheckMultiple("sudo reboot", new string[] { "[sudo] password for test:" }, 10);
                testResult = testResult && Send(password);
            }
            else
            {
                testResult = testResult && Send("sudo reboot");
            }

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool ExcuteDialog(string testItem, bool sudoPwd)
        {
            bool testResult = true;
            string password = CommonAPI.ReadINI("Setting", "LinuxPC", "Password", "test!@#$");
            string recvMsg = "";

            testResult = testResult && SendAndCheckMultiple("cd /usr/local/bin/", new string[] { Prompt }, 10);
            if (sudoPwd)
            {
                testResult = testResult && SendAndCheckMultiple("sudo ./dialog-menu", new string[] { "[sudo] password for test:" }, 10);
                testResult = testResult && SendAndReceiveCheck(password, "OK", 20, ref recvMsg);
            }
            else
            {
                testResult = testResult && SendAndReceiveCheck("sudo ./dialog-menu", "OK", 20, ref recvMsg);
            }

            testResult = testResult && printDialogSelect(recvMsg);

            //pringSelection(recvMsg, @"(?<=\[0;1m\[31m\[44m)((.)*)(?=\(B\[0m\[30m\[47m\[)");

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        private void pringSelection(string recvMsg, string SelectPattern)
        {
            string removeESC = Regex.Replace(recvMsg, @"[\u001b\u009b]", "");
            string removeBlue = Regex.Replace(removeESC, @"\[33m\[44m", "");
            Match select = Regex.Match(removeBlue, @SelectPattern);

            DaigSelection = (select.Success) ? select.ToString().Trim() : "None";

            AddMessage(MessageTag.LOG, "[DaigSelection] " + DaigSelection);//(?<=\[33m[\u001b\u009b]\[44m)(.*)(?=[\u001b\u009b])
        }

        private void printDialogLog(string recvMsg)
        {
            string recvLog = Regex.Replace(recvMsg, @Pattern, "");
            string[] recvLine = recvLog.Split(new[] { Environment.NewLine }, StringSplitOptions.None);

            int index = Array.FindIndex(recvLine, matchGSI);
            string[] dialogLog = null;
            int maxLen = 0;

            if (index != -1)
            {
                dialogLog = recvLine.Select((v, i) => new { Index = i, Value = v }).Where(x => x.Index >= index).Select(x => x.Value.Trim()).ToArray();

                int[] itemLenList = dialogLog.Select(i => i.Trim().Length).ToArray();
                maxLen = itemLenList.Max() + 1;

                for (int i = index; i < recvLine.Length; i++)
                {
                    int spaceLen = (maxLen - recvLine[i].Length);
                    recvLine[i] = Regex.Replace(recvLine[i], @"Xx", new string(' ', spaceLen) + "x").Trim();
                }
            }

            AddMessage(MessageTag.LOG, String.Join(Environment.NewLine, recvLine));
        }

        private bool printDialogSelect(string recvMsg)
        {
            string[] recvLog = recvMsg.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            int selectIndex = Array.FindIndex(recvLog, matchBgBlue);
            int GSIIndex = Array.FindIndex(recvLog, matchGSI);

            try
            {
                string rmBgBlue = Regex.Replace(recvLog[selectIndex], @"[\u001b\u009b]\[33m[\u001b\u009b]\[44m", "");
                Match select = Regex.Match(rmBgBlue, @"(?<=\[31m[\u001b\u009b]\[44m)[^\u001b\u009b]+(?=[\u001b\u009b])");

                DaigSelection = (select.Success) ? select.ToString().Trim() : "None";

                string[] recvLine = recvLog.Select(i => Regex.Replace(i, @Pattern, "")).ToArray();

                string[] dialogLog = null;
                int maxLen = 0;

                if (GSIIndex != -1)
                {
                    dialogLog = recvLine.Select((v, i) => new { Index = i, Value = v }).Where(x => x.Index >= GSIIndex).Select(x => x.Value.Trim()).ToArray();

                    int[] itemLenList = dialogLog.Select(i => i.Trim().Length).ToArray();
                    maxLen = itemLenList.Max() + 1;

                    for (int i = GSIIndex; i < recvLine.Length; i++)
                    {
                        int spaceLen = (maxLen - recvLine[i].Length);
                        recvLine[i] = Regex.Replace(recvLine[i], @"Xx", new string(' ', spaceLen) + "x").Trim();
                    }
                }

                AddMessage(MessageTag.LOG, String.Join(Environment.NewLine, recvLine));
                AddMessage(MessageTag.LOG, "[DaigSelection] " + DaigSelection);
                return true;
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, ex.ToString());
                return false;
            }
        }

        private bool matchGSI(string s)
        {
            return Regex.IsMatch(s, @"GSI -(.+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        private bool matchBgBlue(string s)
        {
            return Regex.IsMatch(s, @"[\u001b\u009b]\[33m[\u001b\u009b]\[44m", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        public bool DialogSelect(string testItem, string selection)
        {
            bool testResult = true;

            if (DaigSelection == selection)
            {
                return CommonAPI.AddTestItemResult(testItem, true);
            }

            do
            {
                string recvMsg = "";
                string recvLog = "";

                testResult = testResult && SendByte(new byte[] { 0x1b, 0x4f, 0x42 });
                Thread.Sleep(1000);

                //for (int i = 0; i <= 3; i++)
                //{
                    recvMsg += Receive();

                    AddMessage(MessageTag.RECV, recvMsg);
                    testResult = testResult && printDialogSelect(recvMsg);
                    //pringSelection(recvMsg, @"(?<=\[31m\[44m)(.*)(?=(\[20;71H|\[22;38H))");

                    if (DaigSelection.Contains(selection))
                    {
                        return CommonAPI.AddTestItemResult(testItem, true);
                    }
                //}

            } while (!DaigSelection.ToUpper().Contains("EXIT"));//while (DaigSelection.ToUpper() != "Exit".ToUpper());

            return CommonAPI.AddTestItemResult(testItem, false);
        }

        public bool DialogEnter(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";

            testResult = testResult && SendByte(new byte[] { 0xa });
            testResult = testResult && WaiteKeyword("OK", 10, ref recvMsg);

            testResult = testResult && printDialogSelect(recvMsg);
            //pringSelection(recvMsg, @"(?<=\[0;1m\[31m\[44m)((.)*)(?=\(B\[0m\[30m\[47m\[)");

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

        public bool EnterTest(string testItem, string[] checkMsg, int timeoutSec)
        {
            bool testResult = true;

            if (checkMsg.Length <= 0)
            {
                return CommonAPI.AddTestItemResult(testItem, false);
            }
            else
            {
                string recvMsg = "";
                string recvLog = "";

                testResult = testResult && SendByte(new byte[] { 0x0a });
                testResult = testResult && WaiteKeyword(checkMsg[0], timeoutSec, ref recvMsg);

                recvLog = Regex.Replace(recvMsg, @Pattern, "");
                AddMessage(MessageTag.LOG, recvLog);

                for (int item = 0; item < checkMsg.Length; ++item)
                {
                    if (!recvLog.Contains(checkMsg[item]))
                    {
                        return CommonAPI.AddTestItemResult(testItem, false);
                    }
                }

                return CommonAPI.AddTestItemResult(testItem, testResult);
            }
        }

        public bool EnterToClear(string testItem)
        {
            bool testResult = true;
            string recvMsg = "";
            string recvLog = "";

            testResult = testResult && SendByte(new byte[] { 0x0a });
            Thread.Sleep(1000);
            recvMsg = Receive();

            testResult = testResult && printDialogSelect(recvMsg);

            string rmBgBlue = Regex.Replace(recvMsg, @"[\u001b\u009b]\[33m[\u001b\u009b]\[44m", "");
            Match select = Regex.Match(rmBgBlue, @"(?<=\[37m[\u001b\u009b]\[44m)[^\u001b\u009b<>]+(?=[\u001b\u009b])");

            testResult = testResult && (select.ToString().Trim().Contains("Yes"));
            testResult = testResult && SendByte(new byte[] { 0x0a });
            testResult = testResult && WaiteKeyword(">", 30, ref recvMsg);
            testResult = testResult && printDialogSelect(recvMsg);

            rmBgBlue = Regex.Replace(recvMsg, @"[\u001b\u009b]\[33m[\u001b\u009b]\[44m", "");
            select = Regex.Match(rmBgBlue, @"(?<=\[37m[\u001b\u009b]\[44m)[^\u001b\u009b<>]+(?=[\u001b\u009b])");
            testResult = testResult && (select.ToString().Trim().Contains("OK"));

            return CommonAPI.AddTestItemResult(testItem, testResult);
        }

    }

    //if (SendByte(new byte[] { 0xa }))
    //{
    //    for (int i = 0; i <= timeoutSec; i++)
    //    {
    //        recvMsg += Receive();

    //        recvLog = Regex.Replace(recvMsg, @Pattern, "");

    //        if (recvMsg.Contains(checkMsg[0]))
    //        {
    //            AddMessage(MessageTag.LOG, recvLog);
    //            break;
    //        }

    //        Thread.Sleep(1000);
    //    }
}
