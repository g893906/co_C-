﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using CL.API;
using TestPattern;


namespace Common
{
    public class WebCameraManagement
    {
        public enum Mode
        {
            MANUAL = 0,
            AUTO = 1,
        }

        private ICommonAPI CommonAPI = null;
        private WebCamera webCamera = null;
        private WebCamera.ConfigureData configureData = new WebCamera.ConfigureData();

        public Mode ScanMode = Mode.MANUAL;

        public WebCameraManagement(ICommonAPI commonAPI)
        {
            CommonAPI = commonAPI;
            webCamera = new WebCamera(new WebCamera.AddMessageHandler(CommonAPI.AddLog));
            Initialize();
        }

        private void Initialize()
        {
            if (CommonAPI.ReadINI("Setting", "WebCamera", "UseWebCamera", "DISABLE").ToUpper() == "ENABLE")
            {
                ScanMode = Mode.AUTO;
            }
        }

        public string ReadLabel(string readType)
        {
            configureData.FilePath = CommonAPI.ReadINI("Setting", "WebCamera", readType, @"NONE");
            configureData.SectionName = "";
            int readRetry = Convert.ToInt32(CommonAPI.ReadINI("Setting", "WebCamera", "CameraRetry", "3"));

            try
            {
                if (webCamera.Connection(configureData))
                {
                    List<string> symbols = webCamera.Scan(100, readRetry);
                    webCamera.DisConnection();
                    
                    if (symbols != null && symbols.Count > 0)
                    {
                        CommonAPI.AddMessage(MessageTag.INFO, "Get symbol count: " + symbols.Count);
                        CommonAPI.AddMessage(MessageTag.INFO, "Get symbol: " + symbols[0]);
                        return symbols[0];
                    }

                    CommonAPI.AddMessage(MessageTag.INFO, "Get symbol is NULL.");
                    return "";
                }
                else
                {
                    webCamera.DisConnection();
                    CommonAPI.WriteWarning("WebCamera not ready.");
                }
            }
            catch (Exception ex)
            {
                CommonAPI.AddMessage(MessageTag.ERROR, "{ReadLabel} " + ex.Message);
                return "";
            }

            return "";
        }
    }
}
