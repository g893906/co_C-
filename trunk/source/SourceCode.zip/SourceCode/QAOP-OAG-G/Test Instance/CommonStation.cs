﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

using Common;
using CL.Communicate;
using CL.API;
using Image_load;
using ATS_Template.TEServiceClient;


namespace TestPattern
{
    public abstract class CommonStation : BaseStation
    {
        public CommonStation(StatusUI2.StatusUI pStatusUI) : base(pStatusUI) { }

        protected WebCameraManagement webCamera = null;
        //protected IFixture fixture;
        protected ImageChaek _imgCheck = new ImageChaek();
        private TEServiceClient _timeService = new TEServiceClient();

        protected virtual object GetInstances(string name) { return null; }

        /// <summary>
        /// 站別初始化,不用再呼叫BaseInitialize.
        /// </summary>
        public override void Initialize() { }

        /// <summary>
        /// 按鈕按下去時,不用再呼叫BaseStartBefore
        /// </summary>
        /// <returns></returns>
        public override bool StartBefore() { return true; }

        /// <summary>
        /// 用於從DUT內讀取序號、控制治具、進入U-boot、等其他必須在Thread剛開始一定要做的特殊事項.
        /// </summary>
        /// <returns>成功與否</returns>
        public override bool TestInit() { return true; }

        public override void Release() { }

        protected virtual bool TestProcess()
        {
            CXmlTestFlow.ETestFlowResult testResult = _testFlow.Run(GetInstances);

            if (testResult == CXmlTestFlow.ETestFlowResult.PASS)
            {
                return true;
            }
            else
            {
                if (testResult == CXmlTestFlow.ETestFlowResult.Error)
                {
                    WriteWarning("Run test flow warning.");
                }

                return false;
            }
        }
        
        /// <summary>
        /// 測試, 不用再呼叫BaseTestInitialize
        /// </summary>
        public override void Test() { }

        #region Check input
        private bool IsNumericType(Type o)
        {
            switch (Type.GetTypeCode(o))
            {
                case TypeCode.Byte:
                case TypeCode.SByte:
                case TypeCode.UInt16:
                case TypeCode.UInt32:
                case TypeCode.UInt64:
                case TypeCode.Int16:
                case TypeCode.Int32:
                case TypeCode.Int64:
                case TypeCode.Decimal:
                case TypeCode.Double:
                case TypeCode.Single:
                    return true;
                default:
                    return false;
            }
        }

        private T GetMatchSPEC<T>(string section, string key, string def)
        {
            string match = ReadINI("Setting", section, key, def);

            if ((IsNumericType(typeof(T))) && string.IsNullOrEmpty(match))
            {
                return (T)Convert.ChangeType("-1", typeof(T));
            }

            return (T)Convert.ChangeType(match, typeof(T));
        }

        protected bool CheckInputMatch(string inputStr, string key)
        {
            string startWith = GetMatchSPEC<string>("Match", key, "");

            AddMessage(MessageTag.LOG, key + "; StartWith: " + startWith);

            if (string.IsNullOrEmpty(startWith))
            {
                return true;
            }
            else
            {
                if (inputStr.StartsWith(startWith))
                {
                    return true;
                }

                WriteWarning("Input: " + inputStr + " not match(" + startWith + ")");

                return false;
            }
        }

        protected bool CheckInputLength(string inputStr, string key)
        {
            int length = GetMatchSPEC<int>("Match", key, "");
            AddMessage(MessageTag.LOG, key + "; Length: " + length);

            if (length == -1)
            {
                return true;
            }
            else
            {
                if (inputStr.Length == length)
                {
                    return true;
                }

                WriteWarning("Input: " + inputStr + " length not match(" + length + ")");

                return false;
            }
        }
        #endregion

        #region TFTP
        protected bool StartTftpServer()
        {
            string fileName = ReadINI("Setting", "Tool", "TftpServer", @"./TFTPServer/tftpd32.exe");
            string path = System.IO.Path.GetDirectoryName(fileName);
            AddMessage(TestPattern.MessageTag.LOG, "TFTP server: " + fileName);
            KillTftpServer();

            try
            {
                StartProcess(new ProcessStartInfo()
                {
                    WorkingDirectory = path,
                    FileName = fileName
                });

                return true;
            }
            catch (Exception ex)
            {
                AddMessage(TestPattern.MessageTag.ERROR, "{StartTftpServer} " + ex.Message);
                WriteWarning("Start TFTP exe failed.");
                return false;
            }
        }

        protected bool KillTftpServer()
        {
            string fileName = System.IO.Path.GetFileName(ReadINI("Setting", "Tool", "TftpServer", @".\TFTPServer\tftpd32.exe"));
            bool reStart = (ReadINI("Setting", "Tool", "TftpRestart", "Enable") == "Enable");

            if (!reStart)
            {
                return true;
            }

            try
            {
                KillTask(fileName);
                return true;
            }
            catch (Exception ex)
            {
                AddMessage(TestPattern.MessageTag.ERROR, "{KillTftpServer} " + ex.Message);
                return false;
            }
        }
        #endregion

        #region Golden
        private bool CompareGoldenSN(string sn, string checkstr, ref string getGoldenSN)
        {
            getGoldenSN = "";
            string dutSN = checkstr.Split(',')[0].Trim();
            string goldenSN = checkstr.Split(',')[1].Trim();

            AddMessage(TestPattern.MessageTag.INFO, "DUT SN: " + dutSN + "; Golden SN: " + goldenSN);

            if (dutSN == sn)
            {
                if (goldenSN.Length == 15 && goldenSN.Substring(7, 1) == "Z")
                {
                    try
                    {
                        AddMessage(TestPattern.MessageTag.INFO, "Get Golden SN: " + goldenSN);
                        getGoldenSN = goldenSN;
                        return true;
                    }
                    catch (Exception ex)
                    {
                        AddMessage(TestPattern.MessageTag.ERROR, ex.Message);
                    }
                }
                else
                {
                    //AddMessage(TestPattern.MessageTag.ERROR, "Golden SN rule is fail.");
                    AddMessage(TestPattern.MessageTag.INFO, "Get Golden SN: " + goldenSN);
                    getGoldenSN = goldenSN;
                    return true;
                }
            }
            else if (sn == goldenSN)
            {
                if (goldenSN.Length == 15 && goldenSN.Substring(7, 1) == "Z")
                {
                    getGoldenSN = goldenSN;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                AddMessage(TestPattern.MessageTag.LOG, "Input SN not match.");
            }

            return false;
        }

        protected bool CheckGoldenSample(string sn, ref string getGoldenSN)
        {
            string readGolden = ReadINI("Setting", "Golden", "SN", "NONE");

            if (readGolden == "NONE")
            {
                return false;
            }
            else if (readGolden.Contains(","))
            {
                if (readGolden.Contains(";"))
                {
                    string[] snGoldenList = readGolden.Split(';');

                    foreach (string item in snGoldenList)
                    {
                        if (item.Contains(",") && CompareGoldenSN(sn, item, ref getGoldenSN))
                        {
                            return true;
                        }
                    }
                }
                else
                {
                    return CompareGoldenSN(sn, readGolden, ref getGoldenSN);
                }
            }

            return false;
        }
        #endregion

        protected void CommonInitialize()
        {
            webCamera = new WebCameraManagement(this);
            eGetLabelBy = tools.ParseEnum<EGetLabelBy>(ReadINI("Setting", Information.Station, "GetLabelBy", "Barcode"));
        }

        protected bool ReadLabelByWebCamera(string[] labelNames, out List<string> labels)
        {
            labels = new List<string>();

            if (webCamera.ScanMode == WebCameraManagement.Mode.AUTO)
            {
                if (labelNames.Length <= 0)
                {
                    return false;
                }

                foreach (string name in labelNames)
                {
                    string getData = webCamera.ReadLabel(name);

                    if (string.IsNullOrEmpty(getData))
                    {
                        WriteWarning("Read " + name + " is null.");
                        return false;
                    }

                    labels.Add(getData);
                }

                return (labelNames.Length == labels.Count);
            }
            else
            {
                return true;
            }
        }

        #region RCS
        protected override bool CheckFixtureState(string fixtureNumber)
        {
            return true;
        }

        protected override bool GetSn(string fixtureNumber, string sn)
        {
            return true;
        }
        #endregion

        protected bool ShowImageCheck(string testItem, string message, ImageChaek.EMode mode)
        {
            _imgCheck.ShowImage("Image", testItem, message, mode);
            _imgCheck.ShowDialog();

            return AddTestItemResult(testItem, _imgCheck.ClickValue);
        }

        /// <summary>
        /// Get Now Time(TPE:+8) From SFCS
        /// </summary>
        public bool GetSfcsUtcTime(ReqCode reqCode, ref DateTime sfcsTime)
        {
            try
            {
                CTBaseReqResult getSFCSTime = _timeService.TxHelloWorldInq(new CTBaseReqInParm()
                {
                    ReqCode = reqCode,
                });

                if (getSFCSTime.RetCode.ReturnCode != "00000")
                {
                    AddMessage(MessageTag.ERROR, "{GetSFCSTime} " + getSFCSTime.RetCode.ReturnCode);
                    AddMessage(MessageTag.ERROR, "{GetSFCSTime} " + getSFCSTime.RetCode.MessageText);
                    return false;
                }
                else
                {
                    DateTime serviceTime = getSFCSTime.RetCode.EndSysDate;
                    sfcsTime = TimeZoneInfo.ConvertTimeToUtc(serviceTime);

                    AddMessage(MessageTag.SFCS, "SFCSTime: " + serviceTime.ToString("yyyy-MM-dd HH:mm:ss"));
                    AddMessage(MessageTag.SFCS, "UTCTime: " + sfcsTime.ToString("yyyy-MM-dd HH:mm:ss"));
                   return true;                   
                }
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{GetSFCSTime} " + ex.ToString());
                return false;
            }
        }
    }
}
