﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using System.Net;
using System.Text.RegularExpressions;
using System.Collections.Generic;

using ATS;

namespace TestPattern
{
    public class CBurnIn : BaseStation
    {
        static private System.Reflection.Assembly _assembly = System.Reflection.Assembly.GetExecutingAssembly();
        private static AssemblyDescriptionAttribute _adAttr = (AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(typeof(FrmBurnIn).Assembly, typeof(AssemblyDescriptionAttribute));
        private string _dateRelease = _adAttr.Description.ToString();
        private Thread _thread = null;

        public CBurnIn(StatusUI2.StatusUI pStatusUI) : base(pStatusUI)
        {

        }

        public object GetInstances(string name)
        {
            Dictionary<string, object> ins = new Dictionary<string, object>()
            {
                { "this",  this }
            };

            try
            {
                return ins[name];
            }
            catch
            {
                return null;
            }
        }

        public override void Initialize()
        {
            ConfigureStatusUI();
        }

        public override bool StartBefore()
        {
            return BaseStartBefore();
        }

        public override bool TestInit()
        {
            return false;
        }

        public override void Test()
        {
            AddTestItemResult("PingDUT", true);
            Thread.Sleep(5000);
        }

        public override void Release()
        {
            BaseRelease();
        }

        private StatusUI2.StatusUI.SFCSDataFormat GetSFCSDataFormat()
        {
            switch (WNC.API.Func.ReadINI("Setting", "Setting", "OutPathMode", "0"))
            {
                case "0":
                    return StatusUI2.StatusUI.SFCSDataFormat.NetWork_PSN;
                case "1":
                    return StatusUI2.StatusUI.SFCSDataFormat.NetWork;
                case "2":
                    return StatusUI2.StatusUI.SFCSDataFormat.Generally;
                default:
                    return StatusUI2.StatusUI.SFCSDataFormat.Generally;
            }
        }

        private void ConfigureStatusUI()
        {
            StatusUI.SetVersion(Information.Station, Information.BU, Information.Product, Information.ProjectName, Information.ProgramVersion, Information.ReleaseDate);
            StatusUI.SetUIMode(StatusUI2.StatusUI.UIMode.OnlyResult_Mode);
            StatusUI.ChkStageFunc = StatusUI2.StatusUI.ChkStage.EnableByAts;
            StatusUI.SetSFCS_Data_Format(GetSFCSDataFormat());
            StatusUI.ResetData();
            StatusUI.Setting.CheckInput = true;
            StatusUI.Setting_Log.Display = false;
            StatusUI.Setting.Encryption = false;
            StatusUI.Setting.WS_Config = StatusUI2.StatusUI.webservices.WPH;
            StatusUI.SFCS_Data.Fixture = "NONE";
            StatusUI.txtFix.Visible = false;
        }

        public void TestStart()
        {
            _thread = new Thread(() => Test());
            _thread.Start();
        }
    }
}
