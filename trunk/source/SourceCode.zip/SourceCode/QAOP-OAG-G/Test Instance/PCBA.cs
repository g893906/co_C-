﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;


using Common;
using CL.Communicate;
using ATS_Template.TEServiceClient;


namespace TestPattern
{
    public class PCBA : CommonStation
    {
        enum EBootResult
        {
            Failed = -1,
            UBoot = 0,
            WNC = 1,
        }

        private GSI_Console console = null;
        private TestItem testItems = null;
        private EBootResult _bootResult = EBootResult.Failed;
        private TEServiceClient _timeService = new TEServiceClient();
        private ReqCode _reqCode = new ReqCode();

        public PCBA(StatusUI2.StatusUI pStatusUI) : base(pStatusUI) 
        {
            console = new GSI_Console(this);
        }

        protected override object GetInstances(string name)
        {
            Dictionary<string, object> ins = new Dictionary<string, object>()
            {
                { "this",  this }, { "console", console }, { "testItem", testItems },
            };

            try
            {
                return ins[name];
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 站別初始化,不用再呼叫BaseInitialize.
        /// </summary>
        public override void Initialize()
        {         
            CommonInitialize();

            _reqCode.AppName = "QAOP-OAG-G_PCBA";
            _reqCode.UserID = "TE";
            _reqCode.UserPwd = "zHheIRhxPwFR9TAxgw7kYA==";
            _reqCode.LangType = LangType.zh_Hant;



        }

        /// <summary>
        /// 按鈕按下去時,不用再呼叫BaseStartBefore
        /// </summary>
        /// <returns></returns>
        public override bool StartBefore()
        {
            //bool init = console.InitCOMPort();

            return true;
        }

        /// <summary>
        /// 用於從DUT內讀取序號、控制治具、進入U-boot、等其他必須在Thread剛開始一定要做的特殊事項.
        /// </summary>
        /// <returns>成功與否</returns>
        public override bool TestInit()
        {         
            bool initResult = false;

            // Jerry Added on 2021.01.24
            console.AddInputData("BOARDTYPE", "LEDA-E");
            console.AddInputData("LabelSN", StatusUI.txtPSN.Text);
            console.AddInputData("DUTSN", "GSI-RnD-lab-ID-"+StatusUI.txtPSN.Text);
            //console.AddInputData("MAC", StatusUI.txtSP.Text);
            console.AddInputData("MAC", StatusUI.txtSP.Text.Contains(":")? StatusUI.txtSP.Text : tools.GetMACFormat(StatusUI.txtSP.Text));

            if (eGetLabelBy == EGetLabelBy.WebCamera)
            {
                initResult = ReadLable();
                initResult = initResult && CheckInputMatch(StatusUI.txtPSN.Text, "PSN");
                initResult = initResult && CheckInputLength(StatusUI.txtPSN.Text, "PSN");
                initResult = initResult && CheckInputMatch(StatusUI.txtSP.Text, "SP");
                initResult = initResult && CheckInputLength(StatusUI.txtSP.Text, "SP");
            }

            initResult = ReadTestFlow();

            return initResult;
        }

        /// <summary>
        /// 測試, 不用再呼叫BaseTestInitialize
        /// </summary>
        public override void Test()
        {
            //CheckChangeFixture();
            //ReadTestFlow();

            TestProcess();

            //CheckChangeFixture();
            //BaseTestInitialize();
            //ReadTestFlow();
            //_testFlow.Run(GetInstances);
            //Release();
          
            Release();
        }

        public override void Release()
        {
            console.FreeComPort();
            BaseRelease();
        }       

        private bool ReadLable()
        {
            List<string> readLabel = new List<string>();
            bool result = ReadLabelByWebCamera(new string[] { "CameraSN", "CameraSMT" }, out readLabel);

            if (result)
            {
                SetLabelInfoToUI(readLabel.ToArray());
                return true;
            }

            WriteWarning("Read label failed.");
            return false;
        }

        protected override void SetFirstSFCSLine()
        {
            //CheckMACFormat();
            string mac = "";
            string strFirstLine = string.Join(",", StatusUI.txtPSN.Text);

            if (StatusUI.txtSP != null)
            {
                if (StatusUI.txtSP.Text.Contains(":"))
                {
                    mac = Regex.Replace(StatusUI.txtSP.Text, @":", "");
                    strFirstLine = string.Join(",", strFirstLine, mac);
                }
                else
                {
                    strFirstLine = string.Join(",", strFirstLine, StatusUI.txtSP.Text);
                }
            }

            if (StatusUI.txtSP1 != null)
            {
                strFirstLine = string.Join(",", strFirstLine, StatusUI.txtSP1.Text);
            }

            AddMessage(MessageTag.INFO, "Write first line: " + strFirstLine);
            StatusUI.SFCS_Data.First_Line = strFirstLine;
        }

        public bool RTCTest(string testItem)
        {
            bool testResult = true;
            DateTime utcTime = DateTime.MinValue;

            testResult = testResult && console.CheckTargetTestMenu(testItem, GSI_Console.ETargetTestMenu.Manual);
            testResult = testResult && console._serial.SendAndCheckMultiple("20", new string[] { "display new CLK" }, 20);
            testResult = testResult && console._serial.SendAndCheckMultiple("1", new string[] { "year between 2000 - 3000" }, 20);
            testResult = testResult && GetSfcsUtcTime(_reqCode, ref utcTime);
            testResult = testResult && console.RTCTest(testItem, utcTime);

            return AddTestItemResult(testItem, testResult);
        }

        #region RCS
        protected override bool CheckFixtureState(string fixtureNumber)
        {
            return true;
        }

        protected override bool GetSn(string fixtureNumber, string sn)
        {
            BaseStartBefore();
            StatusUI.ResetData();
            string[] labelArray = sn.Split(',');

            SetLabelInfoToUI(labelArray);

            return true;
        }
        #endregion
    }
}

