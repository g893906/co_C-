﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ATS
{
    public partial class MerakiLED : Form
    {
        public string TestItem = "";

        public MerakiLED()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TestItem = "AllPass";
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TestItem = "White";
            this.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TestItem = "Red";
            this.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            TestItem = "Green";
            this.Dispose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TestItem = "Blue";
            this.Dispose();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TestItem = "Orange";
            this.Dispose();
        }
    }
}
