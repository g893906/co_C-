﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using System.Net;
using System.Text.RegularExpressions;
using System.Collections.Generic;


using TestPattern;


namespace ATS
{
    public partial class FrmBurnIn : Form
    {
        public class CObjectGroup
        {
            public CBurnIn BurnIn = null;
            public Panel panGroup = null;
            public TextBox InputTextBox = null;
            public Button[] buttons = new Button[3];
        }

        private List<CObjectGroup> _objectGroups = new List<CObjectGroup>();

        public FrmBurnIn()
        {
            InitializeComponent();
        }

        private void FrmBurnIn_Load(object sender, EventArgs e)
        {
            LoadUI();
        }

        private void LoadUI()
        {
            for (int i = 0; i < 3; ++i)
            {
                CObjectGroup group = new CObjectGroup();

                group.BurnIn = new CBurnIn(new StatusUI2.StatusUI());
                group.BurnIn.Initialize();

                #region New panel
                group.panGroup = new Panel() { Name = i.ToString(), Size = new Size(350, 35) };
                #endregion

                Control c = new Control()
                {
                    Name = "Input_" + i.ToString(),
                    Size = new Size(100, 25),
                    Location = new Point(4, 4),
                };


                #region New TextBox
                group.InputTextBox = new TextBox()
                {
                    Name = "Input_" + i.ToString(),
                    Size = new Size(100, 25),
                    Location = new Point(4, 4),
                };
                #endregion

                #region New Button
                group.buttons = new Button[3] {
                    new Button() { Name = ("Btn_START_" + i), Size = new Size(75, 25), Location = new Point(110, 4), Text = "START", BackColor = Color.Gray },
                    new Button() { Name = ("Btn_PASS_" + i), Size = new Size(75, 25), Location = new Point(190, 4), Text = "PASS", BackColor = Color.Green, Enabled = false },
                    new Button() { Name = ("Btn_NG_" + i), Size = new Size(75, 25), Location = new Point(270, 4), Text = "NG", BackColor = Color.Red, Enabled = false }
                };

                group.buttons[0].Click += new EventHandler(Click_START);
                group.buttons[1].Click += new EventHandler(Click_PASS);
                group.buttons[2].Click += new EventHandler(Click_NG);
                #endregion

                group.panGroup.Controls.Add(group.InputTextBox);
                group.panGroup.Controls.Add(group.buttons[0]);
                group.panGroup.Controls.Add(group.buttons[1]);
                group.panGroup.Controls.Add(group.buttons[2]);
                _objectGroups.Add(group);

                _objectGroups[i].panGroup.Location = new Point( 10, (10 + ((30)) * i) );
                _objectGroups[i].panGroup.Visible = true;

                this.Controls.Add(_objectGroups[i].panGroup);
            }
        }

        private void Click_START(object sender, EventArgs e)
        {
            //  取得被按下去的按鈕所在的List Index
            int listIdx = Convert.ToInt32(((Button)sender).Parent.Name.ToString());

            Console.WriteLine("Click Group: " + listIdx);
            _objectGroups[listIdx].InputTextBox.Enabled = false;
            _objectGroups[listIdx].buttons[0].Enabled = false;
            _objectGroups[listIdx].buttons[1].Enabled = true;
            _objectGroups[listIdx].buttons[2].Enabled = true;

            _objectGroups[listIdx].BurnIn.StatusUI.ResetData();
            _objectGroups[listIdx].BurnIn.StartBefore();

            _objectGroups[listIdx].BurnIn.StatusUI.txtPSN.Text = _objectGroups[listIdx].InputTextBox.Text.Trim();
            _objectGroups[listIdx].BurnIn.StatusUI.SFCS_Data.PSN = _objectGroups[listIdx].InputTextBox.Text.Trim();
            _objectGroups[listIdx].BurnIn.StatusUI.SFCS_Data.Fixture = _objectGroups[listIdx].BurnIn.Information.Fixture;
            _objectGroups[listIdx].BurnIn.StatusUI.CheckInput();
            _objectGroups[listIdx].BurnIn.StatusUI.Test_Start();
            _objectGroups[listIdx].BurnIn.TestStart();

        }

        private void Click_PASS(object sender, EventArgs e)
        {
            //  取得被按下去的按鈕所在的List Index
            //
            int listIdx = Convert.ToInt32(((Button)sender).Parent.Name.ToString());
            Console.WriteLine("Click Group: " + listIdx);

            _objectGroups[listIdx].InputTextBox.Enabled = true;
            _objectGroups[listIdx].buttons[0].Enabled = true;
            _objectGroups[listIdx].buttons[1].Enabled = false;
            _objectGroups[listIdx].buttons[2].Enabled = false;

            _objectGroups[listIdx].BurnIn.Release();
        }

        private void Click_NG(object sender, EventArgs e)
        {
            int listIdx = Convert.ToInt32(((Button)sender).Parent.Name.ToString());
            Console.WriteLine("Click Group: " + listIdx);

            _objectGroups[listIdx].BurnIn.Release();
        }
    }
}
