﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

namespace CL.API
{
    public class Function
    {
        private enum ShowWindowEnum
        {
            Hide = 0,
            ShowNormal = 1, ShowMinimized = 2, ShowMaximized = 3,
            Maximize = 3, ShowNormalNoActivate = 4, Show = 5,
            Minimize = 6, ShowMinNoActivate = 7, ShowNoActivate = 8,
            Restore = 9, ShowDefault = 10, ForceMinimized = 11
        };

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
        public static IntPtr _ptrHandle = IntPtr.Zero;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        private static extern bool ShowWindow(IntPtr hWnd, ShowWindowEnum flags);

        public enum WriteToFileMode
        {
            ReNew = 0,
            WriteToLast = 1,
        }

        private Dictionary<string, Process> _process = new Dictionary<string, Process>();
        public delegate void AddLogEventHandler(string log);
        public event AddLogEventHandler AddLogCallback;


        private void DisplayMsg(string message)
        {
            if (AddLogCallback != null)
            {
                AddLogCallback("[Function]" + message);
            }
        }

        public bool Strncmp(string str1, string str2, int num)
        {
            bool canCompare = ((str1.Length >= num) && (str2.Length >= num)) ? true : false;

            if (canCompare)
            {
                for (int i = 0; i < num; ++i)
                {
                    if (str1[i] != str2[i])
                    {
                        return false;
                    }
                }

                return true;
            }

            return false;
        }

        public void KillATS()
        {
            Process[] localAll = Process.GetProcesses();
            Process current = Process.GetCurrentProcess();
            string strProcessName = current.ProcessName;

            foreach (Process i in localAll)
            {
                Regex r;
                Match m;

                // 存放輸入的字串
                string strEscape;

                // 將輸入字串中中繼字字元用逸出字元代替的 function
                strEscape = Regex.Escape(strProcessName);

                // 把輸入的字串填入
                r = new Regex(@strEscape,
                    RegexOptions.IgnoreCase | RegexOptions.Compiled);

                // 檢查目前這一個字串是否符合輸入的字串，將結果傳回 Match 物件
                // 並以 Match.Success 來判斷是否符合
                m = r.Match(i.ProcessName.ToString());

                if (m.Success)
                {
                    //MessageBox.Show(" Found Process :" + i.ProcessName.ToString() + " killed.");
                    Process[] killProcess = Process.GetProcessesByName(i.ProcessName.ToString());
                    killProcess[0].Kill();
                    m.NextMatch();
                }
            }
        }

        public bool KillProcess(string processName)
        {
            try
            {
                string correctEXE = processName.Replace(".exe", "");
                System.Diagnostics.Process[] myProcesses = System.Diagnostics.Process.GetProcesses();

                foreach (System.Diagnostics.Process myProcess in myProcesses)
                {
                    if (myProcess.ProcessName.ToUpper() == correctEXE.ToUpper())
                    {
                        myProcess.Kill();
                        break;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[KillProcess][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool StartProcess(string name, string filename, string arguments = "")
        {
            try
            {
                Process ps = null;

                if (!_process.ContainsKey(name))
                {
                    ps = new Process();
                    _process.Add(name, ps);
                }
                else
                {
                    _process[name] = new Process();
                    ps = _process[name];
                }

                if (filename != "arp")
                {
                    DisplayMsg("[StartProcess] --> filename: " + filename + "; arguments: " + arguments);
                }

                ps.StartInfo.FileName = @filename;
                ps.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                ps.StartInfo.UseShellExecute = false;
                ps.StartInfo.Arguments = @arguments;
                ps.StartInfo.CreateNoWindow = true;
                ps.Start();
                Thread.Sleep(300);
                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[StartProcess][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool StartProcess(string name, ProcessStartInfo info)
        {
            try
            {
                Process ps = null;

                if (!_process.ContainsKey(name))
                {
                    ps = new Process();
                    _process.Add(name, ps);
                }
                else
                {
                    _process[name] = new Process();
                    ps = _process[name];
                }

                ps.StartInfo = info;
                ps.Start();
                Thread.Sleep(300);

                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[StartProcess][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool CloseProcess(string name)
        {
            try
            {
                DisplayMsg("[CloseProcess] --> " + name);

                if (!_process.ContainsKey(name))
                {
                    DisplayMsg("[CloseProcess] --> The " + name + " is not start.");
                    return true;
                }

                KillProcess(_process[name].ProcessName);
                Thread.Sleep(300);
                _process[name].Close();
                _process[name].Dispose();
                _process.Remove(name);
                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[CloseProcess][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool WriteToFile(string path, string line, WriteToFileMode mode)
        {
            try
            {
                string currentPath = @path;
                string directory = @Path.GetDirectoryName(path);
                FileMode filemode = ((mode == WriteToFileMode.ReNew) ? FileMode.OpenOrCreate : FileMode.Append);

                if (mode == WriteToFileMode.ReNew && File.Exists(currentPath))
                {
                    File.Delete(currentPath);
                }

                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                DisplayMsg("[WriteToFile] --> " + path);

                FileStream f = new FileStream(currentPath, filemode, FileAccess.Write);
                StreamWriter Writer = new StreamWriter(f);
                Writer.WriteLine(line);
                Writer.Close();
                f.Close();

                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[WriteToFile][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool PingA(string ip, int timeout)
        {
            try
            {
                PingOptions m_options = new PingOptions();
                Ping m_pingSender = new Ping();

                StartProcess("PingA", "arp", "-d");
                m_options.DontFragment = true;

                string sData = "abcdefghijklmnopqrstuvwabcdefghi";
                byte[] buffer = Encoding.ASCII.GetBytes(sData);
                PingReply m_reply = m_pingSender.Send(ip, timeout, buffer, m_options);

                DisplayMsg("[PingA] --> Ping: " + ip + "; Timeout: " + timeout.ToString() + "; Result: " + m_reply.Status.ToString());

                return (m_reply.Status == IPStatus.Success);
            }
            catch (Exception ex)
            {
                DisplayMsg("[PingA][Exception] --> " + ex.Message);
                return false;
            }
        }

        public string GetIP(string interfaceName)
        {
            string ip = "";
            //  取得所有網路介面類別(封裝本機網路資料)
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();

            foreach (NetworkInterface adapter in nics)
            {
                if (adapter.Name.ToLower().IndexOf(interfaceName) >= 0)  // interfaceName = "sfcs"
                {
                    //取得IPInterfaceProperties(可提供網路介面相關資訊)
                    IPInterfaceProperties ipProperties = adapter.GetIPProperties();

                    if (ipProperties.UnicastAddresses.Count > 0)
                    {
                        //取得Mac Address
                        PhysicalAddress mac = adapter.GetPhysicalAddress();
                        //網路介面名稱
                        string name = adapter.Name;
                        //網路介面描述
                        string description = adapter.Description;
                        //取得IP
                        ip = ipProperties.UnicastAddresses[0].Address.ToString();
                        //取得遮罩
                        string netmask = ipProperties.UnicastAddresses[0].IPv4Mask.ToString();
                    }
                }
            }

            return ip;
        }

        public string getFormatMAC(string sMAC, string sInsertStr)
        {
            string sMACTemp = sMAC;

            if (sMACTemp.Length == 12)
            {
                for (int i = 2; i < 15; i += 3)
                {
                    sMACTemp = sMACTemp.Insert(i, sInsertStr);
                }
            }
            return sMACTemp;
        }

        public string getFormatMAC(string mac)
        {
            var regex = "(.{2})(.{2})(.{2})(.{2})(.{2})(.{2})";
            var replace = "$1:$2:$3:$4:$5:$6";

            var newformat = Regex.Replace(mac, regex, replace);

            return newformat.ToString();
        }

        public bool PingTest(string ip, int timeout, int count = 1)
        {
            int pingCount = 0;
            int timeCount = timeout * 2;

            for (int time = 0; time < timeCount; ++time)
            {
                if (PingA(ip, 1000))
                {
                    if (++pingCount >= count)
                    {
                        return true;
                    }

                    DisplayMsg("[PingTest] --> PingCount: " + pingCount.ToString());
                }

                Thread.Sleep(700);
            }

            return false;
        }
        
        public bool FocusTheProgram(string name)
        {
            DisplayMsg("[FocusTheProgram] --> Begin find " + name);

            try
            {
                Process[] ps = Process.GetProcessesByName(name);

                if (ps.Length > 0)
                {
                    if (ps[0].MainWindowHandle == IntPtr.Zero)
                    {
                        ShowWindow(ps[0].Handle, ShowWindowEnum.Restore);
                        Thread.Sleep(600);
                    }

                    Thread.Sleep(700);
                    SetForegroundWindow(ps[0].MainWindowHandle);

                    DisplayMsg("[FocusTheProgram] --> " + name + " is focus");
                }
                else
                {
                    DisplayMsg("[FocusTheProgram] --> Not find " + name);
                }

                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[FocusTheProgram][Exception] --> " + ex.Message);
                return false;
            }
        }

        public string BackupFile(string originalFile, string destPath, string destFile, bool deleteOriginalFileAfterBackUp)
        {
            FileInfo fi = new FileInfo(originalFile);

            #region check originalFile existence
            if (!fi.Exists)
            {
                DisplayMsg("[backupFile] --> Not found file: " + originalFile);
                return null;
            }
            #endregion

            #region check destination folder
            DirectoryInfo di = new DirectoryInfo(destPath);

            if (!di.Exists)
            {
                di.Create();
            }
            #endregion

            #region copy action
            FileInfo dest = fi.CopyTo(destPath + destFile);

            if (dest.Exists && dest.Length == fi.Length)
            {
                if (deleteOriginalFileAfterBackUp)
                {
                    fi.Delete();
                }

                return dest.FullName;
            }
            else
            {
                DisplayMsg("[backupFile] --> copy fail or source file has changed! \n" + "dest file: " + destPath + destFile);
            }
            #endregion

            return null;
        }

        public bool NetworkInterfaceCtrl(string interfacename, bool enable, int delay, bool show)
        {
            try
            {
                string enableStr = (enable) ? "enable" : "disable";
                string command = "interface set interface \"" + interfacename + "\" " + enableStr;
                DisplayMsg("[NetworkInterfaceCtrl] --> " + command);

                System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo("netsh", command);
                System.Diagnostics.Process p = new System.Diagnostics.Process();
                p.StartInfo = psi;
                p.StartInfo.WindowStyle = (show) ? ProcessWindowStyle.Normal : ProcessWindowStyle.Hidden;
                p.Start();
                Thread.Sleep(delay);
                p.Close();

                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[NetworkInterfaceCtrl][Exception] --> " + ex.Message);
                return false;
            }
        }

        public static void SetFocus()
        {
            if (_ptrHandle != IntPtr.Zero)
            {
                SetForegroundWindow(_ptrHandle);
            }
        }

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);

            foreach (byte b in ba)
            {
                hex.Append('0');
                hex.Append('x');
                hex.AppendFormat("{0:x2}".ToUpper(), b);
                hex.Append(',');
            }

            return hex.ToString().TrimEnd(',');
        }
    }
}