﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO.Ports;

using WNC.API;

namespace CL.API
{
    public class NQJControlBoard
    {
        private SerialPort _ShieldingBox = null;
        public delegate void AddLogEventHandler(string log);
        public event AddLogEventHandler AddLogCallback;

        private void DisplayMsg(string message)
        {
            if (AddLogCallback != null)
            {
                AddLogCallback("[NQJControlBoard]" + message);
            }
        }

        public bool Init(string Comport, string BaudRate = "9600")
        {
            DisplayMsg("[NQJControlBoard][Init] --> Init");

            if (_ShieldingBox != null && _ShieldingBox.IsOpen)
            {
                DisplayMsg("[NQJControlBoard][Init] --> " + Comport + " is already Init.");
                return true;
            }

            _ShieldingBox = new SerialPort()
            {
                PortName = Comport,
                BaudRate = Convert.ToInt32(BaudRate),
                Parity = Parity.None,
                DataBits = 8,
                StopBits = StopBits.One,
                ReadTimeout = 500,
                WriteTimeout = 200
            };

            try
            {
                _ShieldingBox.Open();
                return _ShieldingBox.IsOpen;
            }
            catch (Exception ex)
            {
                DisplayMsg("[NQJControlBoard][Init][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool Close()
        {
            try
            {
                if (_ShieldingBox.IsOpen)
                {
                    _ShieldingBox.Close();
                    _ShieldingBox.Dispose();
                    _ShieldingBox = null;
                    DisplayMsg("[NQJControlBoard][Close] --> ");
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ControllFixtureIndividual(string command, string keyword, int timeout = 2000, string characterreturn = "\r", int delay = 500, int retry = 3)
        {
            DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] Begin.");

            try
            {
                if (!_ShieldingBox.IsOpen)
                {
                    _ShieldingBox.Open();
                }

                _ShieldingBox.DiscardInBuffer();
                _ShieldingBox.DiscardOutBuffer();

                bool closeCom = true;
                int retryCount = 0;
                string rtn = string.Empty;
                string currentRtn = string.Empty;

                DateTime dt = DateTime.Now;

                while (true)
                {
                    TimeSpan ts = new TimeSpan(DateTime.Now.Ticks - dt.Ticks);

                    if (ts.TotalMilliseconds >= timeout)
                    {
                        DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Timeout");
                        return false;
                    }

                    for (int i = 0; i < retry; ++i)
                    {
                        rtn = string.Empty;
                        _ShieldingBox.DiscardInBuffer();
                        _ShieldingBox.DiscardOutBuffer();

                        DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Command: " + command);

                        if (characterreturn != "")
                        {
                            _ShieldingBox.WriteLine(command + characterreturn);
                        }
                        else
                        {
                            _ShieldingBox.Write(command);
                        }

                        Thread.Sleep(delay);

                        if (keyword == "NONE")
                        {
                            DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Don't check keyword");
                            _ShieldingBox.Close();
                            return true;
                        }

                        DateTime dt2 = DateTime.Now;

                        while (true)
                        {
                            TimeSpan ts2 = new TimeSpan(DateTime.Now.Ticks - dt2.Ticks);

                            if (ts2.TotalMilliseconds >= timeout)
                            {
                                DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Timeout");

                                if (retryCount++ < retry)
                                {
                                    DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Controll Fixture Individual Retry: " + retryCount.ToString());
                                    break;
                                }

                                if (closeCom)
                                {
                                    DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Controll Fixture Individual Com Close");
                                    _ShieldingBox.Close();
                                }

                                return false;
                            }

                            currentRtn = _ShieldingBox.ReadExisting();
                            rtn += currentRtn;
                            DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Receive:" + currentRtn);

                            if (rtn.ToUpper().Contains(keyword))
                            {
                                DisplayMsg("[NQJControlBoard][ControllFixtureIndividual] --> Controll Fixture Individual Successfully: " + keyword);
                                _ShieldingBox.Close();
                                return true;
                            }

                            Thread.Sleep(1000);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string method = System.Reflection.MethodBase.GetCurrentMethod().ToString();
                string errMsg = string.Format("[{0}] Exception: {1}", method, ex.Message);
                throw new Exception(errMsg);
            }
        }

        public bool GetStatusShieldingBox(int delay = 500)
        {
            DisplayMsg("[NQJControlBoard][GetStatusShieldingBox] Begin.");

            try
            {
                if (!_ShieldingBox.IsOpen)
                {
                    _ShieldingBox.Open();
                }

                _ShieldingBox.DiscardInBuffer();
                _ShieldingBox.DiscardOutBuffer();

                int rtnByte = 0;

                _ShieldingBox.DiscardInBuffer();
                _ShieldingBox.DiscardOutBuffer();

                _ShieldingBox.WriteLine("status\r");
                Thread.Sleep(delay);

                int bRead = _ShieldingBox.BytesToRead;
                DisplayMsg("[NQJControlBoard][GetStatusShieldingBox] --> Shielding Box BytesToRead: " + bRead.ToString());

                if (bRead < 3)
                {
                    DisplayMsg("[NQJControlBoard][GetStatusShieldingBox] --> Shielding Box Status cnt is less than 3");
                    return false;
                }
                for (int i = 0; i < 3; i++)
                {
                    rtnByte += _ShieldingBox.ReadByte();
                }

                DisplayMsg("[NQJControlBoard][GetStatusShieldingBox] --> Shielding Box Status: " + rtnByte);
            }
            catch (Exception ex)
            {
                string method = System.Reflection.MethodBase.GetCurrentMethod().ToString();
                string errMsg = string.Format("[{0}] Exception: {1}", method, ex.Message);
                throw new Exception(errMsg);
            }
            return true;
        }
    }
}
