﻿using System;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Text.RegularExpressions;

namespace CL.API
{
    class TelnetClient
    {
        public TcpClient client;
        public NetworkStream TelnetStream;
        public delegate void AddLogEventHandler(string log);
        public event AddLogEventHandler AddLogCallback;

        enum Verbs
        {
            WILL = 251,
            WONT = 252,
            DO = 253,
            DONT = 254,
            IAC = 255
        }

        enum Options
        {
            SGA = 3
        }


        private void DisplayMsg(string message)
        {
            if (AddLogCallback != null)
            {
                AddLogCallback("[T.C]" + message);
            }
        }

        private void CreateTcpClient(string lanIP, string lanPort)
        {
            client = new TcpClient();
            client.SendTimeout = 3;
            client.Connect(lanIP, Convert.ToInt16(lanPort));
            TelnetStream = client.GetStream();
        }

        private bool CheckSeveralData(string message, string[] str)
        {
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i].Contains("||"))
                {
                    short result = 0;

                    foreach (var substr in str[i].Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        if (message.Contains(substr))
                        {
                            result++;
                        }
                        else
                        {
                            DisplayMsg("[CheckSeveralData] --> (or)Not found keyword: " + substr);
                        }
                    }

                    if (result == 0)
                    {
                        return false;
                    }
                }
                else if (!message.Contains(str[i]))
                {
                    return false;
                }
            }

            return true;
        }

        public bool LoginTelnet(string lanIP, string lanPort, string login, string passWord, string prompt, string timeout)
        {
            try
            {
                DisplayMsg("[LoginTelnet] --> Begin.");
                string sReceive = "";
                CreateTcpClient(lanIP, lanPort);

                if (login != "")
                {
                    if (!ReceiveDataFromTelnet(1, "login", ref sReceive) && !ReceiveDataFromTelnet(5, "login", ref sReceive))
                    {
                        DisplayMsg("[LoginTelnet] --> Not found login.");
                        return false;
                    }

                    SendCommandToTelnet(login);
                }

                if (passWord != "")
                {
                    if (!ReceiveDataFromTelnet(1, "Password", ref sReceive) && !ReceiveDataFromTelnet(5, "Password", ref sReceive))
                    {
                        DisplayMsg("[LoginTelnet] --> Not found password.");
                        return false;
                    }

                    SendCommandToTelnet((passWord == "{ENTER}") ? "" : passWord);
                }

                if (prompt != "")
                {
                    if (!ReceiveDataFromTelnet(Convert.ToInt32(timeout), prompt, ref sReceive))
                    {
                        SendCommandToTelnet("");

                        if (!ReceiveDataFromTelnet(Convert.ToInt32(timeout), prompt, ref sReceive))
                        {
                            DisplayMsg("[LoginTelnet] --> Not found prompt.");
                            return false;
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[LoginTelnet][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool LogoutTelnet()
        {
            try
            {
                DisplayMsg("[LogoutTelnet] --> Begin.");
                TelnetStream.Close();
                client.Close();
                TelnetStream.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[LogoutTelnet][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool SendCommandToTelnet(string sCommand)
        {
            try
            {
                DisplayMsg("[SCTT] --> Command: " + sCommand);

                byte[] byteCommand = Encoding.ASCII.GetBytes(sCommand + "\n");
                TelnetStream.Write(byteCommand, 0, byteCommand.Length);
                TelnetStream.Flush();
                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[SendCommandToTelnet][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool SendByteCommandToTelnet(byte[] bCommand)
        {
            try
            {
                string cmdStr = "";//Function.ByteArrayToString(bCommand);
                DisplayMsg("[SendByteCommandToTelnet] --> Command: " + cmdStr);
                TelnetStream.Write(bCommand, 0, bCommand.Length);
                TelnetStream.Flush();
                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[SendCommandToTelnet][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool ReceiveDataFromTelnet(int nTimeOut, string sPrompt, ref string sReceive)
        {
            sReceive = "";

            if (!client.Connected) return false;

            StringBuilder sb = new StringBuilder();
            nTimeOut = nTimeOut * 2;

            for (int i = 0; i < nTimeOut; i++)
            {
                Thread.Sleep(500);
                ParseTelnet(sb);
                sReceive = sb.ToString();

                if ((sPrompt == "") || (sReceive.ToUpper().Contains(sPrompt.ToUpper())))
                {
                    DisplayMsg("[ReceiveDataFromTelnet] --> \r\n" + sReceive);
                    return true;
                }
            }

            DisplayMsg("[ReceiveDataFromTelnet] --> \r\n" + sReceive);
            return false;
        }

        public bool ReceiveSeveralDataFromTelnet(int nTimeOut, string[] sCheckMessage, ref string sReceive)
        {
            sReceive = "";

            if (!client.Connected) return false;

            try
            {
                StringBuilder sb = new StringBuilder();
                nTimeOut = nTimeOut * 10;

                for (int i = 0; i < nTimeOut; i++)
                {
                    Thread.Sleep(100);
                    ParseTelnet(sb);
                    sReceive = sb.ToString();

                    if (CheckSeveralData(sReceive, sCheckMessage))
                    {
                        DisplayMsg("[RSDFT] --> Receive over:\r\n" + sReceive);
                        return true;
                    }
                }

                DisplayMsg("[ReceiveSeveralDataFromTelnet] --> Receive timeout:\r\n" + sReceive);
                return false;
            }
            catch (Exception ex)
            {
                DisplayMsg("[ReceiveSeveralDataFromTelnet][Exception] --> " + ex.Message);
                return false;
            }
        }

        public void ParseTelnet(StringBuilder sb)
        {
            while (client.Available > 0)
            {
                int input = client.GetStream().ReadByte();

                switch (input)
                {
                    case -1:
                        break;
                    case (int)Verbs.IAC:
                        // interpret as command
                        int inputverb = client.GetStream().ReadByte();
                        if (inputverb == -1) break;
                        switch (inputverb)
                        {
                            case (int)Verbs.IAC:
                                //literal IAC = 255 escaped, so append char 255 to string
                                sb.Append(inputverb);
                                break;
                            case (int)Verbs.DO:
                            case (int)Verbs.DONT:
                            case (int)Verbs.WILL:
                            case (int)Verbs.WONT:
                                // reply to all commands with "WONT", unless it is SGA (suppres go ahead)
                                int inputoption = client.GetStream().ReadByte();
                                if (inputoption == -1) break;
                                client.GetStream().WriteByte((byte)Verbs.IAC);
                                if (inputoption == (int)Options.SGA)
                                    client.GetStream().WriteByte(inputverb == (int)Verbs.DO ? (byte)Verbs.WILL : (byte)Verbs.DO);
                                else
                                    client.GetStream().WriteByte(inputverb == (int)Verbs.DO ? (byte)Verbs.WONT : (byte)Verbs.DONT);
                                client.GetStream().WriteByte((byte)inputoption);
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        sb.Append((char)input);
                        break;
                }
            }
        }

        public bool SendCmdAndCheckMultiple(string command, string[] message, int timeout)
        {
            string recv = "";

            if (SendCommandToTelnet(command))
            {
                return ReceiveSeveralDataFromTelnet(timeout, message, ref recv);
            }

            return false;
        }

        public bool SendCmdAndReceiveCheck(string command, string[] message, ref string recv, int timeout)
        {
            if (SendCommandToTelnet(command))
            {
                return ReceiveSeveralDataFromTelnet(timeout, message, ref recv);
            }

            return false;
        }

        public bool SendCmdAndReceiveCheckStr(string command, string[] checkmessage, string[] pass, string[] ng, int timeout)
        {
            string recv = "";

            bool testResult = SendCmdAndReceiveCheck(command, checkmessage, ref recv, timeout);

            //  先檢查NG
            foreach (string item in ng)
            {
                if (recv.Contains(item))
                {
                    testResult = false;
                }
            }

            if (testResult)
            {
                foreach (string item in pass)
                {
                    testResult = testResult && recv.Contains(item);
                }
            }

            return testResult;
        }

        public bool SendCmdAndCheckCount(string command, string[] message, string keyword, int checkcount, int timeout)
        {
            string recv = "";

            bool result = SendCommandToTelnet(command);
            result = result && ReceiveSeveralDataFromTelnet(timeout, message, ref recv);
            result = result && (Regex.Matches(recv, keyword).Count == checkcount);

            return result;
        }
    }
}
