﻿using System;
using System.Threading;
using System.Collections.Generic;
using WebCameraLib;
using System.IO;


namespace CL.API
{
    public class WebCamera
    {
        public enum MessageTag
        {
            INFO = 0,
            LOG = 2,
            ERROR = 3,
        }

        public struct ConfigureData
        {
            public string FilePath;
            public string SectionName;
        }

        private Controller _webCameraController = null;
        private Dictionary<string, ConfigureData> _configureDataMap = new Dictionary<string, ConfigureData>();

        public delegate void AddMessageHandler(string Message);
        private event AddMessageHandler AddMessageEvent;
        public bool Enable { get; set; }

        public WebCamera(AddMessageHandler addMessageHandler)
        {
            AddMessageEvent += addMessageHandler;
        }

        private void AddMessage(MessageTag tag, string Message)
        {
            if (AddMessageEvent != null)
            {
                int tagLength = (tag.ToString().Length) + 2;
                int pad = tagLength + (8 - tagLength);
                AddMessageEvent(("[" + tag.ToString() + "]").PadRight(pad) + Message);
            }
        }

        private bool Initialize(ConfigureData configureData)
        {
            if (!File.Exists(configureData.FilePath))
            {
                AddMessage(MessageTag.ERROR, "Can't find camera configure file(" + configureData.FilePath + ")");
                return false;
            }

            try
            {
                if (configureData.SectionName == "")
                {
                    _webCameraController = new WebCameraLib.Controller(configureData.FilePath);
                }
                else
                {
                    _webCameraController = new WebCameraLib.Controller(configureData.FilePath, configureData.SectionName);
                }

                if (!_webCameraController.StartCamera())
                {
                    AddMessage(MessageTag.ERROR, "Execute Warning: Initial Camera: Can't Start Camera.");
                    DisConnection();
                    return false;
                }

                _webCameraController.SwitchAutoScan(true);
                AddMessage(MessageTag.INFO, "Setting: " + configureData.FilePath + " Camera init success.");
                return true;
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, ex.Message);
                return false;
            }
        }

        private List<string> CameraScan(int delay)
        {
            if (_webCameraController == null)
            {
                return null;
            }

            try
            {
                AddMessage(MessageTag.LOG, "Scan delay: " + delay);
                return _webCameraController.Scan(delay);
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, ex.Message);
                return null;
            }
        }

        public void AddConfigure(string name, ConfigureData configureData)
        {
            _configureDataMap.Add(name, configureData);
        }

        public bool Connection(ConfigureData configureData)
        {
            return Initialize(configureData);
        }

        public bool Connection(string name)
        {
            if (!_configureDataMap.ContainsKey(name))
            {
                AddMessage(MessageTag.ERROR, "Not find " + name + " camera configure.");
                return false;
            }
            else
            {
                return Initialize(_configureDataMap[name]);
            }
        }

        public bool DisConnection()
        {
            try
            {
                _webCameraController.SwitchAutoScan(false);
                Thread.Sleep(50);
                _webCameraController.StopCamera();
                _webCameraController.Dispose();
                AddMessage(MessageTag.INFO, "Camera dispose success.");
                return true;
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, ex.Message);
                return false;
            }
        }

        public List<string> Scan(int delay, int retryCount)
        {
            List<string> data;

            try
            {
                for (int retry = 0; retry < retryCount; ++retry)
                {
                    data = CameraScan(delay);

                    if (data == null)
                    {
                        AddMessage(MessageTag.LOG, "Retry scan.(" + retry + ")");
                    }
                    else
                    {
                        return data;
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Scan} " + ex.Message);
            }

            return null;
        }
    }
}
