﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading;

//  Need to add reference Renci.SshNet.dll
using Renci.SshNet;

namespace CL.API
{
    public struct SSHLoginData
    {
        public string IP;
        public int  Port;
        public string UserName;
        public string Password;
        public string Prompt;
        public int Timeout;
    }

    public class SSHCtrl
    {
        private SshClient _sshClient;
        private ShellStream _shellStream;

        public delegate void AddLogEventHandler(string log);
        public event AddLogEventHandler AddLogCallback;

        private void DisplayMsg(string message)
        {
            if (AddLogCallback != null)
            {
                AddLogCallback("[SSHCtrl]" + message);
            }
        }

        public bool Login(SSHLoginData data)
        {
            try
            {
                _sshClient = new SshClient(data.IP, Convert.ToInt32(data.Port), data.UserName, data.Password);
                _sshClient.Connect();
                _shellStream = _sshClient.CreateShellStream("SSH_Terminal", 80, 24, 800, 600, 10244);

                if (_sshClient.IsConnected)
                {
                    if (data.Prompt != "" && data.Prompt != null)
                    {
                        string recv = _shellStream.Expect(data.Prompt, new TimeSpan(0, 0, data.Timeout));

                        if (!recv.Contains(data.Prompt))
                        {
                            DisplayMsg("[Login] --> Login SSH check prompt(" + data.Prompt + ") failed." );
                            return false;
                        }
                    }

                    DisplayMsg("[Login] --> Login SSH success.");
                    return true;
                }
                else
                {
                    DisplayMsg("[Login] --> SSH connection failed.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                DisplayMsg("[Login][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool Logout()
        {
            try
            {
                if (_shellStream != null)
                {
                    _shellStream.Close();
                }
                
                if (_sshClient != null)
                {
                    _sshClient.Disconnect();
                }
                
                DisplayMsg("[Logout] --> SSH logout.");
                return true;
            }
            catch (Exception ex)
            {
                DisplayMsg("[Logout][Exception] --> " + ex.Message);
                return false;
            }
        }

        public bool SendStrCmdToSSH(string cmd)
        {
            DisplayMsg("[SSTS] --> Command: " + cmd);

            if (!_sshClient.IsConnected)
            {
                DisplayMsg("[SSTS] --> Cannot connected.");
                return false;
            }
            else
            {
                try
                {
                    _shellStream.WriteLine(cmd);
                    _shellStream.Flush();
                    return true;
                }
                catch (Exception ex)
                {
                    DisplayMsg("[SSTS][EX] --> " + ex.Message);
                    return false;
                }
            }
        }

        public bool SendByteCmdToSSH(byte[] cmd)
        {
            DisplayMsg("[SBCTS] --> Command: " + cmd.ToString());

            if (!_sshClient.IsConnected)
            {
                DisplayMsg("[SBCTS] --> Cannot connected.");
                return false;
            }
            else
            {
                try
                {
                    _shellStream.Write(cmd, 0, cmd.Length);
                    _shellStream.Flush();
                    return true;
                }
                catch (Exception ex)
                {
                    DisplayMsg("[SBCTS][EX] --> " + ex.Message);
                    return false;
                }
            }
        }

        public bool ReceiveFromSSH(string prompt, int timeout, ref string receive)
        {
            receive = null;

            if (!_sshClient.IsConnected)
            {
                DisplayMsg("[RFS] --> Cannot connected.");
                return false;
            }
            else
            {
                try
                {
                    receive = _shellStream.Expect(prompt, new TimeSpan(0, 0, timeout));
                }
                catch (Exception ex)
                {
                    DisplayMsg("[RFS][EX] --> " + ex.Message);
                }

                if (receive == null)
                {
                    receive = "";
                    DisplayMsg("[RFS] --> Not found prompt(receive = null).");
                    return false;
                }
                else
                {
                    DisplayMsg("[RFS] --> Receive:\r\n" + receive);
                    return receive.Contains(prompt);
                }
            }
        }

        public bool RetryCheckSshBeforeTimeout(string prompt, int timeout, int beforeread, ref string receive)
        {
            receive = "";

            if (!_sshClient.IsConnected)
            {
                DisplayMsg("[RCSBT] --> Cannot connected.");
                return false;
            }
            else
            {
                try
                {
                    Stopwatch testStopWatch = new System.Diagnostics.Stopwatch();
                    testStopWatch.Reset();
                    testStopWatch.Start();

                    do
                    {
                        Thread.Sleep(beforeread * 1000);
                        string output = _shellStream.Read();
                        receive += output;
                        DisplayMsg("[RCSBT] --> Receive:\r\n" + output);

                        if (receive.Contains(prompt))
                        {
                            return true;
                        }

                    } while ((testStopWatch.ElapsedMilliseconds / 1000) < timeout);

                    DisplayMsg("[RCSBT] --> Not found: " + prompt);
                    return false;
                }
                catch (Exception ex)
                {
                    DisplayMsg("[RCSBT][EX] --> " + ex.Message);
                    return false;
                }
            }
        }

        public bool ReceiveSshMessageDuringPeriod(int timeout, int beforeeead, ref string receive)
        {
            receive = "";

            if (!_sshClient.IsConnected)
            {
                DisplayMsg("[RSMDP] --> Cannot connected.");
                return false;
            }
            else
            {
                try
                {
                    Stopwatch testStopWatch = new System.Diagnostics.Stopwatch();
                    testStopWatch.Reset();
                    testStopWatch.Start();

                    do
                    {
                        Thread.Sleep(beforeeead * 1000);
                        string output = _shellStream.Read();
                        receive += output;
                        DisplayMsg("[RSMDP] --> Receive:\r\n" + output);

                    } while ((testStopWatch.ElapsedMilliseconds / 1000) < timeout);

                    return true;
                }
                catch (Exception ex)
                {
                    DisplayMsg("[RSMDP][EX] --> " + ex.Message);
                    return false;
                }
            }
        }

        public bool SendCmdAndCheckMultiple(string command, string[] message, int timeout)
        {
            string recv = "";

            if (SendStrCmdToSSH(command))
            {
                if (ReceiveFromSSH(message[0], timeout, ref recv))
                {
                    for (int i = 0; i < message.Length; ++i)
                    {
                        if (!recv.Contains(message[i]))
                        {
                            return false;
                        }
                    }

                    return true;
                }
            }

            return false;
        }
    }
}
