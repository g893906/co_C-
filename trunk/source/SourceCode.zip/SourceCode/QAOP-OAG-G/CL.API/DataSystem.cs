﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Data;
using System.Text.RegularExpressions;
using System.Net;

using MySql.Data.MySqlClient;

using CL.API;

namespace DataSystemCtrl
{
    public enum ATS_Result
    {
        NONE = 0,
        PASS = 1,
        NG = 2,
        WARNING = 3,
        RETEST = 4,
    }

    public enum MessageTag
    {
        INFO = 0,
        LOG = 2,
        ERROR = 3,
    }

    public struct ConfigureData
    {
        public string ATSLogMode;
        public string DataBase;
        public string FTP_Username;
        public string FTP_Password;
        public string FTP_IP;
        public string Station;
        public string SFCSIP;
    }

    public class UploadFTPData
    {
        public string FTP_IP = "";
        public string FTP_Username = "";
        public string FTP_Password = "";
        public string ATSLogPath = "";
        public string PN = "";
        public string MO = "";
        public string Station = "";
        public bool TestPass = false;
    }

    public class WriteSQLData
    {
        public bool FirstTest = true;
        public bool InSFCS = true;
        public bool GoldenSample = false;
        public string PN = "";
        public string MO = "";
        public string SFCSIP = "";
        public string Fixture = "";
        public string SN = "";
        public string Result = "";
        public string FTPLog = "";
        public string NGItem = "";
        public string ErrorCode = "";
        public string Station = "";
        public string Warning = "";
        public string DataBase = "";
        public double TestTime = 0;
        public string StatusUiVersion = "";
        public string Version = "";
        public string Path = "";
        public int ChkCount = -1;
        public StatusUI2.StatusUI.setting StatusUI_Setting;
        public ArrayList ListDataSFCS = new ArrayList();
    }

    public class DataSystemData
    {
        private UploadFTPData _uploadFTPData = null;
        private WriteSQLData _writeSQLData = null;

        public UploadFTPData GetUploadFTPData
        {
            get { return _uploadFTPData; }
        }

        public WriteSQLData GetWriteSQLData
        {
            get { return _writeSQLData; }
        }

        public void SetLogPath(string path)
        {
            if (_uploadFTPData != null)
            {
                _uploadFTPData.ATSLogPath = path;
            }
        }

        public void SetTestTime(double t)
        {
            if (_writeSQLData != null)
            {
                _writeSQLData.TestTime = t;
            }
        }

        public void SetChkCount(int cnt)
        {
            if (_writeSQLData != null)
            {
                _writeSQLData.ChkCount = cnt;
            }
        }

        public void Set(UploadFTPData ftp, WriteSQLData dt)
        {
            _uploadFTPData = new UploadFTPData
            {
                FTP_IP = ftp.FTP_IP,
                FTP_Username = ftp.FTP_Username,
                FTP_Password = ftp.FTP_Password,
                ATSLogPath = ftp.ATSLogPath,
                PN = ftp.PN,
                MO = ftp.MO,
                Station = ftp.Station,
                TestPass = ftp.TestPass
            };

            _writeSQLData = new WriteSQLData
            {
                FirstTest = dt.FirstTest,
                InSFCS = dt.InSFCS,
                GoldenSample = dt.GoldenSample,
                PN = dt.PN,
                MO = dt.MO,
                SFCSIP = dt.SFCSIP,
                Fixture = dt.Fixture,
                SN = dt.SN,
                Result = dt.Result,
                FTPLog = dt.FTPLog,
                NGItem = dt.NGItem,
                ErrorCode = dt.ErrorCode,
                Station = dt.Station,
                DataBase = dt.DataBase,
                Warning = dt.Warning,
                TestTime = dt.TestTime,
                StatusUI_Setting = dt.StatusUI_Setting,
                StatusUiVersion = dt.StatusUiVersion,
                Version = dt.Version,
                Path = dt.Path
            };

            for (int i = 0; i < dt.ListDataSFCS.Count; ++i)
            {
                _writeSQLData.ListDataSFCS.Add(dt.ListDataSFCS[i]);
            }
        }
    }

    public class FtpWeb
    {
        public delegate void AddMessageHandler(string Message);
        public event AddMessageHandler AddMessageEvent;

        private void AddMessage(MessageTag tag, string Message)
        {
            if (AddMessageEvent != null)
            {
                int tagLength = (tag.ToString().Length) + 2;
                int pad = tagLength + (8 - tagLength);
                AddMessageEvent(("[" + tag.ToString() + "]").PadRight(pad) + Message);
            }
        }

        public string ftpServerIP;
        string ftpRemotePath;
        string ftpUserID;
        string ftpPassword;
        public string ftpURI;

        /// <summary> 連接FTP </summary> 
        /// <param name="FtpServerIP">FTP Server IP</param> 
        /// <param name="FtpRemotePath">指定FTP連接成功後的當前目錄, 如果不指定預設為根目錄</param> 
        /// <param name="FtpUserID">帳號</param> 
        /// <param name="FtpPassword">密碼</param> 
        public FtpWeb(string FtpServerIP, string FtpRemotePath, string FtpUserID, string FtpPassword)
        {
            ftpServerIP = FtpServerIP;
            ftpRemotePath = FtpRemotePath;
            ftpUserID = FtpUserID;
            ftpPassword = FtpPassword;
            ftpURI = "ftp://" + ftpServerIP + "/" + ftpRemotePath + "";
        }

        /// <summary> 上傳 </summary> 
        /// <param name="filename"></param> 
        public void Upload(string filename)
        {
            FileInfo fileInf = new FileInfo(filename);
            string uri = ftpURI + fileInf.Name;
            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(uri));
            reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
            reqFTP.KeepAlive = false;
            reqFTP.Method = WebRequestMethods.Ftp.UploadFile;
            reqFTP.UseBinary = true;
            reqFTP.ContentLength = fileInf.Length;
            int buffLength = 2048;
            byte[] buff = new byte[buffLength];
            int contentLen;
            FileStream fs = fileInf.OpenRead();

            try
            {
                Stream strm = reqFTP.GetRequestStream();
                contentLen = fs.Read(buff, 0, buffLength);

                while (contentLen != 0)
                {
                    strm.Write(buff, 0, contentLen);
                    contentLen = fs.Read(buff, 0, buffLength);
                }

                strm.Close();
                fs.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Upload} " + ex.Message);
            }
        }

        public void Upload(string dec_fp, string scr_fp)
        {

            FileInfo fileInf = new FileInfo(scr_fp);
            FtpWebRequest reqFTP;

            reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(dec_fp));
            reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
            reqFTP.KeepAlive = false;
            reqFTP.Method = WebRequestMethods.Ftp.UploadFile;
            reqFTP.UseBinary = true;
            reqFTP.ContentLength = fileInf.Length;
            int buffLength = 2048;
            byte[] buff = new byte[buffLength];
            int contentLen;
            FileStream fs = File.Open(scr_fp, FileMode.Open);

            try
            {
                Stream strm = reqFTP.GetRequestStream();
                contentLen = fs.Read(buff, 0, buffLength);

                while (contentLen != 0)
                {
                    strm.Write(buff, 0, contentLen);
                    contentLen = fs.Read(buff, 0, buffLength);
                }

                strm.Close();
                fs.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Upload} " + ex.Message);
            }
        }

        public bool Upload2(string dec_fp, string scr_fp)
        {
            try
            {
                //string uri = ftpURI + dec_fp;
                FileInfo fileInf = new FileInfo(scr_fp);
                FtpWebRequest reqFTP;

                reqFTP = (FtpWebRequest)WebRequest.Create(new Uri(dec_fp));
                reqFTP.Proxy = null;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                reqFTP.KeepAlive = false;
                reqFTP.Method = WebRequestMethods.Ftp.UploadFile;
                reqFTP.UseBinary = true;

                byte[] b = File.ReadAllBytes(scr_fp);
                reqFTP.ContentLength = b.Length;

                using (Stream s = reqFTP.GetRequestStream())
                {
                    s.Write(b, 0, b.Length);
                }

                FtpWebResponse ftpResp = (FtpWebResponse)reqFTP.GetResponse();

                if (ftpResp != null)
                {
                    if (ftpResp.StatusDescription.StartsWith("226"))
                    {
                        AddMessage(MessageTag.LOG, "Success to upload: " + scr_fp);
                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Upload2} " + ex.Message);
                return false;
            }
        }

        /// <summary> 下載 </summary> 
        /// <param name="filePath"></param> 
        /// <param name="fileName"></param> 
        public void Download(string filePath, string fileName)
        {
            FtpWebRequest reqFTP;
            try
            {
                FileStream outputStream = new FileStream(filePath + "\\" + fileName, FileMode.Create);

                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(ftpURI + fileName));
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();
                long cl = response.ContentLength;
                int bufferSize = 2048;
                int readCount;
                byte[] buffer = new byte[bufferSize];

                readCount = ftpStream.Read(buffer, 0, bufferSize);

                while (readCount > 0)
                {
                    outputStream.Write(buffer, 0, readCount);
                    readCount = ftpStream.Read(buffer, 0, bufferSize);
                }

                ftpStream.Close();
                outputStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Download} " + ex.Message);
            }
        }

        public void Download(string ftpFileFullName, string filePath, string fileName)
        {
            FtpWebRequest reqFTP;

            try
            {
                FileStream outputStream = new FileStream(filePath + "\\" + fileName, FileMode.Create);

                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(ftpFileFullName));
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();
                long cl = response.ContentLength;
                int bufferSize = 2048;
                int readCount;
                byte[] buffer = new byte[bufferSize];

                readCount = ftpStream.Read(buffer, 0, bufferSize);

                while (readCount > 0)
                {
                    outputStream.Write(buffer, 0, readCount);
                    readCount = ftpStream.Read(buffer, 0, bufferSize);
                }

                ftpStream.Close();
                outputStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Download} " + ex.Message);
            }
        }


        /// <summary> 刪除檔案 </summary> 
        /// <param name="fileName"></param> 
        public void Delete(string fileName)
        {
            try
            {
                //string uri = ftpURI + fileName;
                FtpWebRequest reqFTP;
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(fileName));

                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                reqFTP.KeepAlive = false;
                reqFTP.Method = WebRequestMethods.Ftp.DeleteFile;

                string result = String.Empty;
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                long size = response.ContentLength;
                Stream datastream = response.GetResponseStream();
                StreamReader sr = new StreamReader(datastream);
                result = sr.ReadToEnd();
                sr.Close();
                datastream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Delete} 文件名:" + fileName + " EX:" + ex.Message);
            }
        }

        /// <summary> 刪除資料夾 </summary> 
        /// <param name="folderName"></param> 
        public void RemoveDirectory(string folderName)
        {
            try
            {
                //string uri = ftpURI + folderName;
                FtpWebRequest reqFTP;
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(folderName));

                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                reqFTP.KeepAlive = false;
                reqFTP.Method = WebRequestMethods.Ftp.RemoveDirectory;

                string result = String.Empty;
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                long size = response.ContentLength;
                Stream datastream = response.GetResponseStream();
                StreamReader sr = new StreamReader(datastream);
                result = sr.ReadToEnd();
                sr.Close();
                datastream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{Delete} 文件名:" + folderName + " EX:" + ex.Message);
            }
        }

        /// <summary> 取得當前目錄明細(包含檔案和資料夾) </summary> 
        /// <returns></returns> 
        public string[] GetFilesDetailList()
        {
            string[] downloadFiles;
            try
            {
                StringBuilder result = new StringBuilder();
                FtpWebRequest ftp;
                ftp = (FtpWebRequest)FtpWebRequest.Create(new Uri(ftpURI));
                ftp.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                ftp.Method = WebRequestMethods.Ftp.ListDirectoryDetails;
                WebResponse response = ftp.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.Default);

                string line = reader.ReadLine();

                while (line != null)
                {
                    result.Append(line);
                    result.Append("\n");
                    line = reader.ReadLine();
                }

                reader.Close();
                response.Close();

                if (result.Length != 0)
                    result.Remove(result.ToString().LastIndexOf("\n"), 1);
                else
                    return null;

                return result.ToString().Split('\n');
            }
            catch (Exception ex)
            {
                downloadFiles = null;
                AddMessage(MessageTag.ERROR, "{GetFilesDetailList} " + ex.Message);
                return downloadFiles;
            }
        }

        /// <summary> 取得當前目錄下檔案列表 </summary> 
        /// <returns></returns> 
        public string[] GetFileList(string mask)
        {
            StringBuilder result = new StringBuilder();
            FtpWebRequest reqFTP;

            try
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(ftpURI));
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                reqFTP.Method = WebRequestMethods.Ftp.ListDirectory;
                WebResponse response = reqFTP.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.Default);

                string line = reader.ReadLine();

                while (line != null)
                {
                    if (mask.Trim() != string.Empty && mask.Trim() != "*.*")
                    {

                        string mask_ = mask.Substring(mask.IndexOf("*") + 1, mask.Length - mask.IndexOf("*") - 1);

                        if (line.ToLower().Contains(mask_.ToLower()))
                        {
                            result.Append(line);
                            result.Append("\n");
                        }
                    }
                    else
                    {
                        result.Append(line);
                        result.Append("\n");
                    }
                    line = reader.ReadLine();
                }
                reader.Close();
                response.Close();

                if (result.Length != 0)
                    result.Remove(result.ToString().LastIndexOf('\n'), 1);
                else
                    return null;

                return result.ToString().Split('\n');
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{GetFileList} " + ex.Message);
                return null;
            }
        }

        /// <summary> 取得當前目錄下所有的資料夾 </summary> 
        /// <returns></returns> 
        public string[] GetDirectoryList()
        {
            string[] drectory = GetFilesDetailList();
            string m = string.Empty;
            if (drectory != null)
            {
                foreach (string str in drectory)
                {
                    int dirPos = str.IndexOf("<DIR>");

                    if (dirPos > 0)
                    {
                        m += str.Substring(dirPos + 5).Trim() + "\n";
                    }
                    else if (str.Trim().Substring(0, 1).ToUpper() == "D")
                    {
                        string[] sSplit = str.Split(' ');
                        string dir = sSplit[sSplit.Length - 1].Trim();

                        if (dir != "." && dir != "..")
                        {
                            m += dir + "\n";
                        }
                    }
                }

                if (m != string.Empty)
                {
                    m = m.Remove(m.ToString().LastIndexOf('\n'), 1);

                    return m.Split('\n');
                }
                else
                    return null;
            }
            else
                return null;
        }

        /// <summary> 遍歷當前目錄所有子目錄、檔案 </summary> 
        /// <returns></returns> 
        public void GetSubDirectoryList(ref ArrayList AllFileList)
        {
            string[] files = GetFileList("*.txt");

            if (files != null)
            {
                foreach (string file in files)
                {
                    AllFileList.Add(file);
                }
            }

            string[] directory = GetDirectoryList();

            if (directory != null)
            {
                foreach (string str in directory)
                {
                    GotoDirectory(str, false);
                    GetSubDirectoryList(ref AllFileList);
                    GotoDirectory(ftpURI.Replace("ftp://" + ftpServerIP + "/", "").Replace(str + "//", ""), true);
                }
            }
        }

        public void GetSubDirectoryList(string mask, ref ArrayList AllFileList, ref ArrayList AllFileFullName)
        {
            string[] files = GetFileList(mask);

            if (files != null)
            {
                foreach (string file in files)
                {
                    AllFileList.Add(file);
                    AllFileFullName.Add(ftpURI + file);
                }
            }

            string[] directory = GetDirectoryList();

            if (directory != null)
            {
                foreach (string str in directory)
                {
                    GotoDirectory(str, false);
                    GetSubDirectoryList(mask, ref AllFileList, ref AllFileFullName);
                    GotoDirectory(ftpURI.Replace("ftp://" + ftpServerIP + "/", "").Replace(str + "/", ""), true);
                }
            }
        }

        /// <summary> 判斷當前目錄下指定的子目錄是否存在 </summary> 
        /// <param name="RemoteDirectoryName">指定的目錄名稱</param> 
        public bool DirectoryExist(string RemoteDirectoryName)
        {
            string[] dirList = GetDirectoryList();

            if (dirList != null)
            {
                foreach (string str in dirList)
                {
                    if (str.Trim() == RemoteDirectoryName.Trim())
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary> 判斷當前目錄下指定的檔案是否存在 </summary> 
        /// <param name="RemoteFileName">遠端檔案名</param> 
        public bool FileExist(string RemoteFileName)
        {
            string[] fileList = GetFileList("*.*");

            if (fileList != null)
            {
                foreach (string str in fileList)
                {
                    if (str.Trim() == RemoteFileName.Trim())
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary> 建立資料夾 </summary> 
        /// <param name="dirName"></param> 
        public void MakeDir(string dirName)
        {
            FtpWebRequest reqFTP;

            try
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(dirName));
                reqFTP.Method = WebRequestMethods.Ftp.MakeDirectory;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();

                ftpStream.Close();
                response.Close();
            }
            catch (Exception)
            {
            }
        }

        /// <summary> 取得指定檔案大小 </summary> 
        /// <param name="filename"></param> 
        /// <returns></returns> 
        public long GetFileSize(string filename)
        {
            FtpWebRequest reqFTP;
            long fileSize = 0;

            try
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(ftpURI + filename));
                reqFTP.Method = WebRequestMethods.Ftp.GetFileSize;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();
                fileSize = response.ContentLength;

                ftpStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{GetFileSize} " + ex.Message);
            }
            return fileSize;
        }

        /// <summary> 取得指定檔案最後修改日期 </summary> 
        /// <param name="filename"></param> 
        /// <returns></returns> 
        public DateTime GetFileLastModified(string filename)
        {
            FtpWebRequest reqFTP;
            DateTime sLastModified = DateTime.Now;

            try
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(filename));
                reqFTP.Method = WebRequestMethods.Ftp.GetDateTimestamp;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();
                sLastModified = response.LastModified;

                ftpStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{GetFileSize} " + ex.Message);
            }
            return sLastModified;
        }

        public string GetFileContent(string filename)
        {
            string content = "";
            FtpWebRequest reqFTP;

            try
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(ftpURI + filename));
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UsePassive = false;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);

                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.GetEncoding("gb2312"));
                content = reader.ReadToEnd();

                reader.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{GetFileContent} " + ex.Message);
            }
            return content;
        }

        /// <summary> 改名 </summary> 
        /// <param name="currentFilename"></param> 
        /// <param name="newFilename"></param> 
        public void ReName(string currentFilename, string newFilename)
        {
            FtpWebRequest reqFTP;

            try
            {
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri(ftpURI + currentFilename));
                reqFTP.Method = WebRequestMethods.Ftp.Rename;
                reqFTP.RenameTo = newFilename;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ftpUserID, ftpPassword);
                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();

                ftpStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{ReName} " + ex.Message);
            }
        }

        /// <summary> 搬移檔案 </summary> 
        /// <param name="currentFilename"></param> 
        /// <param name="newFilename"></param> 
        public void MovieFile(string currentFilename, string newDirectory)
        {
            ReName(currentFilename, newDirectory);
        }

        /// <summary> 切換當前目錄 </summary> 
        /// <param name="DirectoryName"></param> 
        /// <param name="IsRoot">true 絕對路徑   false 相對路徑</param> 
        public void GotoDirectory(string DirectoryName, bool IsRoot)
        {
            if (IsRoot)
            {
                ftpRemotePath = DirectoryName;
            }
            else
            {
                ftpRemotePath += DirectoryName + "/";
            }
            ftpURI = "ftp://" + ftpServerIP + "/" + ftpRemotePath + "";
        }

        /// <summary> 刪除訂單目錄 </summary> 
        /// <param name="ftpServerIP">FTP Server IP</param> 
        /// <param name="folderToDelete">要刪除的目錄</param> 
        /// <param name="ftpUserID">FTP 帳號</param> 
        /// <param name="ftpPassword">FTP 密碼</param> 
        public static void DeleteOrderDirectory(string ftpServerIP, string folderToDelete, string ftpUserID, string ftpPassword)
        {
            try
            {
                if (!string.IsNullOrEmpty(ftpServerIP) && !string.IsNullOrEmpty(folderToDelete) && !string.IsNullOrEmpty(ftpUserID) && !string.IsNullOrEmpty(ftpPassword))
                {
                    FtpWeb fw = new FtpWeb(ftpServerIP, folderToDelete, ftpUserID, ftpPassword);

                    fw.GotoDirectory(folderToDelete, true);

                    string[] folders = fw.GetDirectoryList();

                    foreach (string folder in folders)
                    {
                        if (!string.IsNullOrEmpty(folder) || folder != "")
                        {
                            string subFolder = folderToDelete + "/" + folder;
                            fw.GotoDirectory(subFolder, true);
                            string[] files = fw.GetFileList("*.*");

                            if (files != null)
                            {
                                foreach (string file in files)
                                {
                                    fw.Delete(file);
                                }
                            }

                            fw.GotoDirectory(folderToDelete, true);
                            fw.RemoveDirectory(folder);
                        }
                    }

                    string parentFolder = folderToDelete.Remove(folderToDelete.LastIndexOf('/'));
                    string orderFolder = folderToDelete.Substring(folderToDelete.LastIndexOf('/') + 1);
                    fw.GotoDirectory(parentFolder, true);
                    fw.RemoveDirectory(orderFolder);
                }
                else
                {
                    throw new Exception("FTP 路徑不能為空！");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("删除訂單錯誤：" + ex.Message);
            }
        }
    }


    public class DataSystem
    {
        public delegate void AddMessageHandler(string Message);
        public event AddMessageHandler AddMessageEvent;

        private void AddMessage(MessageTag tag, string Message)
        {
            if (AddMessageEvent != null)
            {
                int tagLength = (tag.ToString().Length) + 2;
                int pad = tagLength + (8 - tagLength);
                AddMessageEvent(("[" + tag.ToString() + "]").PadRight(pad) + Message);
            }
        }

        public class _ConditionStruct
        {
            public string Field = "";
            public string Input = "";
            public string KeyWord = "";

            public _ConditionStruct(string field, string input, string keyword)
            {
                Field = field;
                Input = input;
                KeyWord = keyword;
            }
        }

        private struct GlobalVariable
        {
            public string BU;
            public string ConnectStr;
            public MySqlConnection MySqlConn;

            public GlobalVariable(string bu, string connectstr, MySqlConnection connect)
            {
                BU = bu;
                ConnectStr = connectstr;
                MySqlConn = connect;
            }
        }

        private GlobalVariable _globalVariable;


        private DataSet QueryID(string field, string table, string condition)
        {
            DataSet set = new DataSet();
            CheckConnection();

            if (_globalVariable.MySqlConn.State == ConnectionState.Open)
            {
                string query = string.Format("Select {0} from {1} where", field, table);
                List<_ConditionStruct> cond = new List<_ConditionStruct>();

                foreach (var item in condition.Split(','))
                {
                    string[] fav = item.Split('=');
                    string[] vak = fav[0].Split(' ');
                    cond.Add(new _ConditionStruct((vak.Length > 1 ? vak[1].Trim() : fav[0].Trim()), fav[1].Trim(), (vak.Length > 1 ? vak[0] : "")));
                }

                foreach (var item in cond)
                {
                    query += " " + item.KeyWord + " " + item.Field + "=@" + item.Field;
                }

                MySqlCommand cmd = new MySqlCommand(query, _globalVariable.MySqlConn);

                foreach (var item in cond)
                {
                    cmd.Parameters.Add(new MySqlParameter(item.Field, item.Input));
                }

                MySqlDataReader DataReader = cmd.ExecuteReader();

                set.Load(DataReader, LoadOption.OverwriteChanges, new string[] { table });

                DataReader.Close();
            }

            return set;
        }

        private bool Update(string table, List<MySqlParameter> set, List<MySqlParameter> condition, string[] keyword)
        {
            string sql = string.Format("Update {0} set ", table);

            try
            {
                MySqlCommand cmd = new MySqlCommand(sql, _globalVariable.MySqlConn);

                foreach (var item in set)
                {
                    sql += item.ParameterName.ToString().Substring(1) + "=" + item.ParameterName + ",";
                    cmd.Parameters.Add(item);
                }

                sql = sql.Substring(0, sql.Length - 1);
                sql += " where";

                for (int i = 0; i < condition.Count; ++i)
                {
                    if ((i + 1) == condition.Count)
                    {
                        sql += " " + condition[i].ParameterName.ToString().Substring(1) + "=" + condition[i].ParameterName;
                    }
                    else
                    {
                        sql += " " + condition[i].ParameterName.ToString().Substring(1) + "=" + condition[i].ParameterName + keyword[i];
                    }

                    cmd.Parameters.Add(condition[i]);
                }

                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][Update][Exception] --> " + ex.Message);
            }
        }

        private bool Insert(string table, List<MySqlParameter> value)
        {
            try
            {
                string sql = string.Format("Insert into {0} (", table);
                MySqlCommand cmd = new MySqlCommand(sql, _globalVariable.MySqlConn);

                foreach (var field in value)
                {
                    sql += field.ParameterName.Substring(1) + ",";
                    cmd.Parameters.Add(field);
                }

                sql = sql.Substring(0, sql.Length - 1) + ")Value(";

                foreach (var val in value)
                {
                    sql += val.ParameterName + ",";
                }

                sql = sql.Substring(0, sql.Length - 1) + ")";

                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][Insert][Exception] --> " + ex.Message);
            }

        }

        private bool CheckColumnExists(string tablename, string column)
        {
            int getCount = 0;

            string sql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS " +
                "WHERE TABLE_SCHEMA = '" + _globalVariable.BU + "' " +
                "AND TABLE_NAME = '" + tablename + "' " +
                "AND COLUMN_NAME = '" + column + "'";

            using (MySqlCommand cmd = new MySqlCommand(sql, _globalVariable.MySqlConn))
            {
                getCount = (int)(long)cmd.ExecuteScalar();
            }

            return (getCount > 0);
        }

        private string CreateTestTable(string pn, int year, int month)
        {
            try
            {
                string TestTableName = pn.Replace('.', '_') + "_Test_YearMonth" + year + month;

                string sql = "CREATE TABLE IF NOT EXISTS " + TestTableName + " (" +
                                "`ID`  int(200) NOT NULL AUTO_INCREMENT ," +
                                "`STATION`  varchar(50) NULL ," +
                                "`GOLDENSIMPLE`  int(10) NULL ," +
                                "`RESULT`  varchar(10) NULL ," +
                                "`INSFCS`  int(10) NULL ," +
                                "`SN`  varchar(200) NULL ," +
                                "WARNING varchar(2000) NULL ," +
                                "`PN`  varchar(50) NULL ," +
                                "`IP`  varchar(50) NULL ," +
                                "`FIXTURE`  varchar(100) NULL ," +
                                "`TESTTIME`  double(50,0) NULL ," +
                                "`CreateTime`  timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ," +
                                "`NGITEM`  varchar(300) NULL ," +
                                "`ERRORCODE`  varchar(100) NULL ," +
                                "`FTPLOG`  varchar(200) NULL ," +
                                "`FIRSTLOAD`  varchar(200) NULL ," +
                                "PRIMARY KEY (`ID`))DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci";

                MySqlCommand cmd = new MySqlCommand(sql, _globalVariable.MySqlConn);
                cmd.ExecuteNonQuery();

                AlterTestTable(TestTableName);

                return TestTableName;
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][CreateTestTable][Exception] --> " + ex.Message);
            }
        }

        public void AlterTestTable(string tablename)
        {
            string sql = "";

            #region Add column
            if (!CheckColumnExists(tablename, "ATS_VERSION"))
            {
                sql = "ALTER TABLE " + tablename + " " +
                    "ADD ATS_VERSION varchar(20) NOT NULL default 'NONE', " +
                    "ADD MO varchar(40) NOT NULL default 'NONE', " +
                    "ADD CHKCOUNT int(8) NOT NULL default '-1', " +
                    "ADD STATUSUI_VER varchar(20) NOT NULL default 'NONE', " +
                    "ADD APP_PATH varchar(150) NOT NULL default 'NONE', " +
                    "ADD MD5 varchar(50) NOT NULL default 'NONE', " +
                    "ADD ENCRPYTION int(10) NOT NULL default '-1', " +
                    "ADD TIMESTAMP int(10) NOT NULL default '-1', " +
                    "ADD CHECKSUM int(10) NOT NULL default '-1', " +
                    "ADD CHK_SFCS_STAGE int(10) NOT NULL default '-1', " +
                    "ADD WS_CONFIG varchar(20) NOT NULL default 'NONE'";

                using (MySqlCommand cmd = new MySqlCommand(sql, _globalVariable.MySqlConn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
            #endregion
        }

        private string CreateDataTable(string testtablename, string pn, string station, int year, int month)
        {
            try
            {
                string DataTableName = pn.Replace('.', '_') + "_TestData_YearMonth" + year + month + "_" + station.Replace(' ', '_');

                string sql = "CREATE TABLE IF NOT EXISTS  " + DataTableName + " (`ID`  int(100) NOT NULL AUTO_INCREMENT ,`TestID`  int(100) NOT NULL,PRIMARY KEY (`ID`),CONSTRAINT `" + DataTableName + "F` FOREIGN KEY (`TestID`) REFERENCES `" + testtablename + "` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT)";

                MySqlCommand cmd = new MySqlCommand(sql, _globalVariable.MySqlConn);
                cmd.ExecuteNonQuery();

                return DataTableName;
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][CreateDataTable][Exception] --> " + ex.Message);
            }
        }

        private string QueryPNID(string pn, int itemp)
        {
            string PNID = "0";
            DataSet pnDataSet = QueryID("ID", "PN", "PN=" + pn);

            if (pnDataSet.Tables[0].Rows.Count > 0)
            {
                PNID = pnDataSet.Tables[0].Rows[0].ItemArray[0].ToString();
                Update("PN", new List<MySqlParameter>() { new MySqlParameter("@Temp", itemp.ToString()) }, new List<MySqlParameter>() { new MySqlParameter("@ID", PNID) }, new string[] { "" });
            }
            else
            {
                Insert("PN", new List<MySqlParameter>() { new MySqlParameter("@PN", pn) });
                pnDataSet.Clear();
                pnDataSet = QueryID("ID", "PN", "PN=" + pn);
            }

            PNID = pnDataSet.Tables[0].Rows[0].ItemArray[0].ToString();

            return PNID;
        }

        private string QueryItemID(string itemname, string tablename, string condition, string conditionfield, int itemp)
        {
            string ID = "0";
            DataSet ds = QueryID("ID", tablename, (tablename + "=" + itemname + ",and " + conditionfield + "= " + condition));

            if (ds.Tables[0].Rows.Count > 0)
            {
                ID = ds.Tables[0].Rows[0].ItemArray[0].ToString();
                Update(tablename, new List<MySqlParameter>() { new MySqlParameter("@Temp", itemp.ToString()) }, new List<MySqlParameter>() { new MySqlParameter("@ID", ID) }, new string[] { "" });
            }
            else
            {
                Insert(tablename, new List<MySqlParameter>() { new MySqlParameter("@" + tablename, itemname), new MySqlParameter("@" + conditionfield, condition) });
                ds.Clear();
                ds = QueryID("ID", tablename, (tablename + "=" + itemname + ",and " + conditionfield + "= " + condition));
            }

            ID = ds.Tables[0].Rows[0].ItemArray[0].ToString();

            return ID;
        }

        private void CheckConnection()
        {
            try
            {
                if (_globalVariable.MySqlConn == null)
                {
                    _globalVariable.MySqlConn = new MySqlConnection(_globalVariable.ConnectStr);
                    _globalVariable.MySqlConn.Open();
                }
                else if (_globalVariable.MySqlConn.State == ConnectionState.Closed)
                {
                    _globalVariable.MySqlConn.Open();
                }
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{CheckConnection} " + ex.Message);
            }
        }

        /// <summary> 連接DB </summary> 
        /// <param name="server">DB IP</param> 
        /// <param name="user">登錄帳號</param> 
        /// <param name="pwd">登錄密碼</param> 
        /// <param name="database">使用的DB</param> 
        public bool Connection(string server, string user, string pwd, string database)
        {
            try
            {
                string connectStr = string.Format(@"server = {0};uid = {1};pwd = {2};DataBase = {3};Allow User Variables=true;Charset=utf8", server, user, pwd, database);

                _globalVariable.BU = database;
                _globalVariable.ConnectStr = connectStr;

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][Connection][Exception] --> " + ex.Message);
            }
        }

        /// <summary> 關閉DB連接 </summary> 
        public bool Disconnection()
        {
            try
            {
                if (_globalVariable.MySqlConn.State == ConnectionState.Open)
                {
                    _globalVariable.MySqlConn.Close();
                }

                if (_globalVariable.MySqlConn != null)
                {
                    _globalVariable.MySqlConn.Dispose();
                }

                _globalVariable.MySqlConn = null;
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][Disconnection][Exception] --> " + ex.Message);
            }
        }

        /// <summary> 上拋資料到FTP </summary> 
        /// <param name = "data" > 上拋FTP所需要的資料 </ param >
        public string UploadLogToFTP(UploadFTPData data)
        {
            string outFTPPath = "";

            try
            {
                FtpWeb mftp = null;

                if (!data.FTP_Username.Contains("NW"))
                {
                    mftp = new FtpWeb(data.FTP_IP, "Harman", data.FTP_Username, data.FTP_Password);
                    data.FTP_IP = data.FTP_IP + "/Harman";
                }
                else
                {
                    mftp = new FtpWeb(data.FTP_IP, "", data.FTP_Username, data.FTP_Password);
                }

                mftp.AddMessageEvent += new FtpWeb.AddMessageHandler(AddMessageEvent);

                // create ftp folder
                string[] ftpFolderArray = { data.FTP_IP, _globalVariable.BU, data.PN, data.MO, data.Station, ((data.TestPass) ? "Pass" : "NG") };
                outFTPPath += "ftp://";

                foreach (string folder in ftpFolderArray)
                {
                    string currectFolder = (folder == "") ? "Verification" : folder;

                    outFTPPath += currectFolder + "/";
                    mftp.MakeDir(outFTPPath);
                }

                outFTPPath += Path.GetFileName(data.ATSLogPath);
                AddMessage(MessageTag.INFO, "Rermote log path: " + outFTPPath);
                AddMessage(MessageTag.INFO, "Local log path: " + data.ATSLogPath);
                bool upload = mftp.Upload2(outFTPPath, data.ATSLogPath);
                AddMessage(MessageTag.INFO, "Upload ATS log res: " + upload.ToString());
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][UploadLogToFTP][Exception] --> " + ex.Message);
            }

            return outFTPPath;
        }

        /// <summary> 寫資料進DataSystem </summary> 
        /// <param name = "datat" > 寫SQL需要的資料 </ param >
        //public void WriteSQLData(WriteSQLData data)
        public void WriteSQLData(DataSystemData data)
        {
            try
            {
                Connection("10.69.98.70", "ATS", "000000", data.GetWriteSQLData.DataBase);
                string ftpLogPath = UploadLogToFTP(data.GetUploadFTPData);

                using (_globalVariable.MySqlConn = new MySqlConnection(_globalVariable.ConnectStr))
                {
                    _globalVariable.MySqlConn.Open();

                    int goldSample = (data.GetWriteSQLData.GoldenSample) ? 1 : 0;
                    int inSFCS = (data.GetWriteSQLData.InSFCS) ? 1 : 0;
                    int Year = DateTime.Now.Year;
                    int Month = DateTime.Now.Month;
                    Random ran = new Random();
                    int iTemp = ran.Next(10);

                    string currectStation = Regex.Replace(data.GetWriteSQLData.Station, @"[\W_]+", "_");
                    string PNID = QueryPNID(data.GetWriteSQLData.PN, iTemp);
                    string StationID = QueryItemID(currectStation, "Station", PNID, "PNID", iTemp);
                    string FixtureID = QueryItemID(data.GetWriteSQLData.Fixture, "Fixture", StationID, "StationID", iTemp);
                    string NGItemID = QueryItemID(data.GetWriteSQLData.NGItem, "NGItem", StationID, "StationID", iTemp);
                    string WarningID = QueryItemID(data.GetWriteSQLData.Warning, "WARNING", StationID, "StationID", iTemp);
                    string TestTableName = CreateTestTable(data.GetWriteSQLData.PN, Year, Month);
                    string DataTableName = CreateDataTable(TestTableName, data.GetWriteSQLData.PN, currectStation, Year, Month);

                    AddMessage(MessageTag.INFO, "TestTableName: " + TestTableName);
                    AddMessage(MessageTag.INFO, "DataTableName: " + DataTableName);

                    List<string> mylist = new List<string>();

                    Insert(TestTableName, new List<MySqlParameter>() {
                         new MySqlParameter("@PN", data.GetWriteSQLData.PN),
                         new MySqlParameter("@IP", data.GetWriteSQLData.SFCSIP),
                         new MySqlParameter("@FIXTURE", data.GetWriteSQLData.Fixture),
                         new MySqlParameter("@SN", data.GetWriteSQLData.SN),
                         new MySqlParameter("@RESULT", data.GetWriteSQLData.Result),
                         new MySqlParameter("@TESTTIME", data.GetWriteSQLData.TestTime),
                         new MySqlParameter("@GOLDENSIMPLE", goldSample),
                         new MySqlParameter("@FTPLOG", ftpLogPath),
                         new MySqlParameter("@NGITEM", data.GetWriteSQLData.NGItem),
                         new MySqlParameter("@ERRORCODE", data.GetWriteSQLData.ErrorCode),
                         new MySqlParameter("@STATION", currectStation),
                         new MySqlParameter("@INSFCS", inSFCS),
                         new MySqlParameter("@WARNING", data.GetWriteSQLData.Warning),
                         new MySqlParameter("@FIRSTLOAD", (data.GetWriteSQLData.FirstTest ? 1 : 0)),
                         new MySqlParameter("@ATS_VERSION", (data.GetWriteSQLData.Version)),
                         new MySqlParameter("@MO", (data.GetWriteSQLData.MO)),
                         new MySqlParameter("@CHKCOUNT", (data.GetWriteSQLData.ChkCount)),
                         new MySqlParameter("@STATUSUI_VER", (data.GetWriteSQLData.StatusUiVersion)),
                         new MySqlParameter("@APP_PATH", (data.GetWriteSQLData.Path)),
                         new MySqlParameter("@MD5", (data.GetWriteSQLData.StatusUI_Setting.MD5 ? 1 : 0)),
                         new MySqlParameter("@ENCRPYTION", (data.GetWriteSQLData.StatusUI_Setting.Encryption ? 1 : 0)),
                         new MySqlParameter("@TIMESTAMP", (data.GetWriteSQLData.StatusUI_Setting.TimeStamp ? 1 : 0)),
                         new MySqlParameter("@CHECKSUM", (data.GetWriteSQLData.StatusUI_Setting.Checksum ? 1 : 0)),
                         new MySqlParameter("@CHK_SFCS_STAGE", 1),
                         new MySqlParameter("@WS_CONFIG", (data.GetWriteSQLData.StatusUI_Setting.WS_Config.ToString())),
                    });

                    DataSet ds = QueryID("max(id)", TestTableName, ("Fixture=" + data.GetWriteSQLData.Fixture + ",and SN=" + data.GetWriteSQLData.SN));
                    string GetInsertID = ds.Tables[0].Rows[0].ItemArray[0].ToString();
                    int TestID = Convert.ToInt32(GetInsertID);

                    DataSet columnDS = QueryID("column_name", "information_schema.`COLUMNS`", "table_name=" + DataTableName);

                    for (int i = 0; i < columnDS.Tables[0].Rows.Count; i++)
                    {
                        object[] aa = columnDS.Tables[0].Rows[i].ItemArray;

                        foreach (object a in aa)
                        {
                            mylist.Add(a.ToString().ToUpper());
                        }
                    }

                    string sSql = "alter table " + DataTableName;
                    string ValidData = "";
                    string ValidDataRaw = "";
                    string ValidData_DataLog = "";

                    #region 增加欄位(欄位名用測試項目)
                    foreach (StatusUI2.Data sfcs_data in data.GetWriteSQLData.ListDataSFCS)
                    {
                        ValidData = Regex.Replace(sfcs_data.TestItem, @"[\W_]+", "_");
                        ValidData_DataLog = Regex.Replace(sfcs_data.TestItem, @"[\W_]+", "_") + "_DataLog";
                        ValidDataRaw = Regex.Replace(sfcs_data.TestItem, @"[\W_]+", "_").ToUpper() + "_Raw";

                        if (sfcs_data.DataType == StatusUI2.Data.data_type.Raw)
                        {
                            if (!mylist.Contains(ValidDataRaw.ToUpper()))
                            {
                                sSql += " add " + ValidDataRaw + " varchar(100),";
                            }
                        }
                        else if (sfcs_data.DataType == StatusUI2.Data.data_type.Number)
                        {
                            if (!mylist.Contains(ValidData.ToUpper()))
                            {
                                sSql += " add " + ValidData + " varchar(100),";
                            }
                        }
                        else if (sfcs_data.DataType == StatusUI2.Data.data_type.Log)
                        {
                            if (!mylist.Contains(ValidData_DataLog.ToUpper()))
                            {
                                sSql += " add " + ValidData_DataLog + " varchar(100),";
                            }
                        }
                    }
                    #endregion

                    sSql = sSql.TrimEnd(',');
                    MySqlCommand sMYSqlCmd = new MySqlCommand(sSql, _globalVariable.MySqlConn);
                    sMYSqlCmd.ExecuteNonQuery();

                    Insert(DataTableName, new List<MySqlParameter>() {
                         new MySqlParameter("@TESTID", TestID)
                    });

                    #region 將測試資料update到剛剛增加的欄位裡
                    if (data.GetWriteSQLData.ListDataSFCS.Count > 0)
                    {
                        sSql = "UPDATE " + DataTableName + " SET ";

                        foreach (StatusUI2.Data sfcs_data in data.GetWriteSQLData.ListDataSFCS)
                        {
                            ValidData = Regex.Replace(sfcs_data.TestItem, @"[\W_]+", "_");
                            ValidData_DataLog = Regex.Replace(sfcs_data.TestItem, @"[\W_]+", "_") + "_DataLog";
                            ValidDataRaw = Regex.Replace(sfcs_data.TestItem, @"[\W_]+", "_").ToUpper() + "_Raw";

                            if (sfcs_data.DataType == StatusUI2.Data.data_type.Number)
                            {
                                sSql += ValidData + "='" + sfcs_data.Val + "',";
                            }
                            else if (sfcs_data.DataType == StatusUI2.Data.data_type.Log)
                            {
                                if (sfcs_data.Status == 0)
                                {
                                    sSql += ValidData_DataLog + "='PASS',";
                                }
                                else
                                {
                                    sSql += ValidData_DataLog + "='NG',";
                                }
                            }
                            else if (sfcs_data.DataType == StatusUI2.Data.data_type.Raw)
                            {
                                sSql += ValidDataRaw + "='" + sfcs_data.Unit + "',";
                            }
                        }

                        sSql = sSql.TrimEnd(',');
                        sSql += " WHERE TESTID=" + TestID;
                        sMYSqlCmd = new MySqlCommand(sSql, _globalVariable.MySqlConn);
                        sMYSqlCmd.ExecuteNonQuery();
                    }
                    #endregion

                    AddMessage(MessageTag.INFO, "Upload data to DataSystem done.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("[DataSystem][WriteSQLData][Exception] --> " + ex.Message);
            }
        }
    }
}
