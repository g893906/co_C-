﻿namespace ATS
{
    partial class FrmMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該公開 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.button1 = new System.Windows.Forms.Button();
            this.StartBtnMask = new System.Windows.Forms.Label();
            this.Checked_RCS_Connect = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.sbp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp5)).BeginInit();
            this.SuspendLayout();
            // 
            // sb_ATS
            // 
            this.sb_ATS.Location = new System.Drawing.Point(0, 431);
            this.sb_ATS.Size = new System.Drawing.Size(365, 26);
            // 
            // status_ATS
            // 
            this.status_ATS.Size = new System.Drawing.Size(365, 431);
            this.status_ATS.Start_Before += new StatusUI2.StatusUI._Start_Before(this.status_ATS_Start_Before);
            this.status_ATS.Click += new System.EventHandler(this.status_ATS_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(132, 210);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // StartBtnMask
            // 
            this.StartBtnMask.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.StartBtnMask.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.StartBtnMask.Font = new System.Drawing.Font("Consolas", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StartBtnMask.Location = new System.Drawing.Point(0, 57);
            this.StartBtnMask.Name = "StartBtnMask";
            this.StartBtnMask.Size = new System.Drawing.Size(365, 50);
            this.StartBtnMask.TabIndex = 4;
            this.StartBtnMask.Text = "Auto";
            this.StartBtnMask.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Checked_RCS_Connect
            // 
            this.Checked_RCS_Connect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Checked_RCS_Connect.AutoSize = true;
            this.Checked_RCS_Connect.Location = new System.Drawing.Point(265, 437);
            this.Checked_RCS_Connect.Name = "Checked_RCS_Connect";
            this.Checked_RCS_Connect.Size = new System.Drawing.Size(88, 16);
            this.Checked_RCS_Connect.TabIndex = 5;
            this.Checked_RCS_Connect.Text = "RCS Connect";
            this.Checked_RCS_Connect.UseVisualStyleBackColor = true;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 457);
            this.Controls.Add(this.Checked_RCS_Connect);
            this.Controls.Add(this.StartBtnMask);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.Text = "ATS Template";
            this.Activated += new System.EventHandler(this.frmMain_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.Shown += new System.EventHandler(this.frmMain_Shown);
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.sb_ATS, 0);
            this.Controls.SetChildIndex(this.status_ATS, 0);
            this.Controls.SetChildIndex(this.StartBtnMask, 0);
            this.Controls.SetChildIndex(this.Checked_RCS_Connect, 0);
            ((System.ComponentModel.ISupportInitialize)(this.sbp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sbp5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label StartBtnMask;
        private System.Windows.Forms.CheckBox Checked_RCS_Connect;
    }
}

