﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestPattern
{
    public enum EGetLabelBy
    {
        Barcode = 0,
        WebCamera = 1,
        Robot = 2,
        RobotAndWebCamera = 3,
    }

    public interface ICommonAPI : IBaseInformation
    {
        EGetLabelBy eGetLabelBy { get; set; }

        bool IsGoldenSample { get; }

        string ReadINI(string filename, string option, string key, string defaultVal);

        void AddLog(string msg);

        void AddMessage(MessageTag tag, string msg);

        void WriteWarning(string msg);

        bool PingDUT(string ip, int timeOutSec, int count);

        bool CheckFailTest();

        bool AddTestItemByValue(string testItem, double value);

        bool AddTestItemResult(string testItem, bool result);

        bool AddValueData(string testItem, string unit, double lsl, double usl, double Val, string errorCode);

        bool WriteSFCSLine(string line, string item, string spec, string data, string errorCode);

        bool WriteSFCSLine(string line, string item, string data);

        bool ShowCheckMessageBox(string testItem, string caption, string content);

        bool Strncmp(string str1, string str2, int num);

        bool StartProcess(System.Diagnostics.ProcessStartInfo info);

        bool KillTask(string taskName);

        Ctrl GetCtrl(string ctrl);

        string GetToolResponse(string fileName, string arguments, int timeOutSec, string keyword = "");
    }
}
