﻿using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using DataSystemCtrl;
using CL.API;
using System.Drawing;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;

using LogService;
using System.Text.RegularExpressions;
using System.Security.Cryptography;



#pragma warning disable CS1690

namespace TestPattern
{
    public enum MessageTag
    {
        INFO = 0,
        LOG = 1,
        ERROR = 2,
        SFCS = 3,
        RETRY = 4,
        DELAY = 5,
        RCS = 6,
    }

    public enum Ctrl
    {
        Disable = 0,
        Enable = 1
    }

    public class OutsideSettingStruct
    {
        public string TotalTestItemCountStr = "";
    }

    public class CControlUIEvent
    {
        public delegate void dSetTexBoxTextCallback(TextBox tb, string text);
        public dSetTexBoxTextCallback SetTexBoxTextCallback;
        public delegate void dSetBtnEnableCallback(Button btn, bool enable);
        public dSetBtnEnableCallback SetBtnEnableCallback;
        public delegate void dStartBtnPerformClick(Button btn);
        public dStartBtnPerformClick StartBtnPerformClickCallback;
        public delegate bool dStatsUICheckInput();
        public dStatsUICheckInput StatsUICheckInputCallback;
        public delegate void dStartBtnMaskVisible(bool visible);
        public dStartBtnMaskVisible StartBtnMaskVisibleCallback;
        public delegate void dRCSConnectChecked(bool isChecked);
        public dRCSConnectChecked RCSConnectCheckedCallback;
        public delegate void dRCSConnectEnable(bool enable);
        public dRCSConnectEnable RCSConnectEnableCallback;
        public delegate void dChangeStatus(Control ctl, string message, System.Drawing.Color color_status);
        public dChangeStatus ChangeStatusCallback;
        public delegate void dControlEnable(Object control, bool enable);
        public dControlEnable ControlEnableCallback;

        public void SetTextBox(TextBox tb, string text)
        {
            if (SetTexBoxTextCallback != null)
            {
                SetTexBoxTextCallback(tb, text);
            }
        }

        public void SetBtnEnable(Button btn, bool enable)
        {
            if (SetBtnEnableCallback != null)
            {
                SetBtnEnableCallback(btn, enable);
            }
        }

        public void StartBtnPerformClick(Button btn)
        {
            if (StartBtnPerformClickCallback != null)
            {
                StartBtnPerformClickCallback(btn);
            }
        }

        public bool StatsUICheckInput()
        {
            if (StatsUICheckInputCallback != null)
            {
                return StatsUICheckInputCallback();
            }

            return false;
        }

        public void StartBtnMaskVisible(bool visible)
        {
            if (StartBtnMaskVisibleCallback != null)
            {
                StartBtnMaskVisibleCallback(visible);
            }
        }

        public void SetRCSConnectChecked(bool isChecked)
        {
            if (RCSConnectCheckedCallback != null)
            {
                RCSConnectCheckedCallback(isChecked);
            }
        }

        public void SetRCSConnectEnable(bool enable)
        {
            if (RCSConnectEnableCallback != null)
            {
                RCSConnectEnableCallback(enable);
            }
        }

        public void ChangeStatusColor(Control ctl, string message, System.Drawing.Color color_status)
        {
            if (ChangeStatusCallback != null)
            {
                ChangeStatusCallback(ctl, message, color_status);
            }
        }

        public void ControlEnable(Control control, bool enable)
        {
            if (ControlEnableCallback != null)
            {
                ControlEnableCallback(control, enable);
            }
        }
    }

    public struct RetestData
    {
        public bool RetestAgain;
        public string Message;

        public RetestData(bool retestAgain = false, string message = "")
        {
            RetestAgain = retestAgain;
            Message = message;
        }
    }

    public struct SCheckFixData
    {
        public bool IsOpen;
        public string ErrorMessage;

        public SCheckFixData(bool isOpen, string errorMessage)
        {
            this.IsOpen = isOpen;
            this.ErrorMessage = errorMessage;
        }
    }

    public abstract class BaseStation : IBaseInstances, ICommonAPI
    {
        #region Object
        private System.Threading.Thread _test = null;
        protected SFCSWebServiceAccess _sfcsWS = new SFCSWebServiceAccess();

        protected CXmlTestFlow _testFlow = null;
        protected RCS Robot = null;

        public ATS_Template.SFCS_ATS.ATS _SFCSWebService = new ATS_Template.SFCS_ATS.ATS();
        protected ATS_Template.TEServiceClient.TEServiceClient teServiceClient = new ATS_Template.TEServiceClient.TEServiceClient();
        protected ATS_Template.TEServiceClient.ReqCode _reqCode = null;
        public StatusUI2.StatusUI StatusUI = null;
        public Tools tools = new Tools();
        #endregion

        #region Data struct
        private static System.Reflection.Assembly _assembly = System.Reflection.Assembly.GetExecutingAssembly();
        private System.Diagnostics.FileVersionInfo _fileVersion = System.Diagnostics.FileVersionInfo.GetVersionInfo(_assembly.Location);
        private ConfigureData _configureData;
        protected Dictionary<string, string> LogExtension = new Dictionary<string, string>();
        protected SFCSWebServiceAccess.CheckChangeFixtureResult _checkChangeFixture = new SFCSWebServiceAccess.CheckChangeFixtureResult();
        private CInformation _information { get; set; }
        private CControlUIEvent _uiControl = new CControlUIEvent();
        public OutsideSettingStruct OutsideSetting = new OutsideSettingStruct();
        #endregion

        #region Variabe
        protected Ctrl AutomaticTest = Ctrl.Disable;
        private Ctrl FormShow = Ctrl.Disable;
        public EGetLabelBy eGetLabelBy { get; set; }
        #endregion


        public BaseStation(StatusUI2.StatusUI pStatusUI)
        {
            StatusUI = pStatusUI;
        }

        #region Implementation Base station interface
        public CInformation Information
        {
            get { return _information; }
        }

        public CControlUIEvent ControlUIEvent
        {
            get { return _uiControl; }
            set { _uiControl = value; }
        }

        public abstract void Initialize();

        public abstract bool StartBefore();

        public abstract bool TestInit();

        public abstract void Test();

        public abstract void Release();

        public virtual void OnCreate() { }

        public virtual void FormShown()
        {
            AutomaticTest = GetCtrl(ReadINI("Setting", "RcsConfig", "AutomaticControl", "Disable"));
            ControlUIEvent.StartBtnMaskVisible((AutomaticTest == Ctrl.Enable));

            if (AutomaticTest == Ctrl.Enable)
            {
                /*
                 * 各專案RCS流程
                 * 1. new RCS
                 * 2. 5個API委派
                 * 3. 註冊
                 * 4. 讓Start Btn不能按
                */

                try
                {
                    Robot = new RCS(Information.Fixture, new RobotControlServicesLib.RobotControlServices.RcsEventLogHandler(RcsHandlerEventLog));
                    Robot.CheckFixtureState = this.CheckFixtureState;
                    Robot.CheckSmooth = this.CheckSmooth;
                    Robot.GetSn = this.GetSn;
                    Robot.StartTest = this.StartTest;

                    //RCS1: 註冊失敗即程式離開 
                    if (!Robot.SendRegisterToRcs(Information.Fixture))
                    {
                        FormExit("註冊RCS Server失敗!!\r\nRegister RCS server failed.");
                    }

                    //ControlUIEvent.SetBtnEnable(StatusUI.buStart, false);
                    ControlUIEvent.SetRCSConnectChecked(true);
                    AddMessage(MessageTag.RCS, "Register Success!!");
                    FormShow = Ctrl.Enable;
                }
                catch (Exception ex)
                {
                    FormExit("註冊RCS Server失敗!!\r\nRegister RCS server failed.(" + ex.Message + ")");
                }
            }
            else
            {
                ControlUIEvent.SetRCSConnectChecked(false);
                ControlUIEvent.SetRCSConnectEnable(false);
            }
        }

        public virtual void FormClosing()
        {
            if (AutomaticTest == Ctrl.Enable)
            {
                Robot.SendRevokeToRcs(Information.Fixture);
            }
        }

        public void RCSConnectChanged(object sender, EventArgs e)
        {
            if (AutomaticTest == Ctrl.Enable && FormShow == Ctrl.Enable)
            {
                _uiControl.SetRCSConnectEnable(false);
                CheckBox checkbox = sender as CheckBox;
                int delaySec = GetINI<int>("Setting", "RcsConfig", "RcsRegisterDelaySec", "1");

                if (!checkbox.Checked)
                {
                    Robot.SendRevokeToRcs(Robot.FixtureNumber);
                }
                else
                {
                    if (!CheckFixtureState(Robot.FixtureNumber))
                    {
                        FormExit("Open shielding box failed, please check!!");
                    }

                    bool reRegister = Robot.SendReRegisterToRcs(Robot.FixtureNumber);
                    AddMessage(MessageTag.LOG, "RCS Connect: " + reRegister.ToString());
                    AddMessage(MessageTag.DELAY, "Wait " + delaySec + " RCS move finish.");
                    System.Threading.Thread.Sleep(delaySec * 1000);
                }

                _uiControl.SetRCSConnectEnable(true);
            }
        }

        public void OnInitialize()
        {
            if (BaseInitialize())
            {
                Initialize();
            }
            else
            {
                throw new System.ArgumentException("Base initialize fails, please check about a station parameter in setting file.");
            }
        }

        public bool OnStartBefore()
        {
            bool result = BaseStartBefore();
            result = result && StartBefore();

            return result;
        }

        public void OnTest()
        {
            bool testInit = TestInit();
            testInit = testInit && BaseTestInitialize();

            if (testInit)
            {
                Test();
            }
            else
            {
                Release();
            }
        }
        #endregion

        #region Private function
        private void PrintOutSetting()
        {
            foreach (System.Reflection.FieldInfo info in OutsideSetting.GetType().GetFields())
            {
                object getV = info.GetValue(OutsideSetting);
                string getVStr = Convert.ToString(getV);
                AddMessage(MessageTag.INFO, (info.Name + ": " + getVStr));
            }
        }

        private void PrintInformation()
        {
            AddMessage(MessageTag.INFO, "Partnumber: " + Information.PartNumber + "; SFCS IP: " + Information.SFCSIP);
            AddMessage(MessageTag.INFO, "ProjectName: " + Information.ProjectName + "; Product: " + Information.Product + "; Station: " + Information.Station);
            AddMessage(MessageTag.INFO, "ProgramVersion: " + Information.ProgramVersion + "; AppVersion: " + Information.AppVersion + "; ReleaseData: " + Information.ReleaseDate);
            AddMessage(MessageTag.INFO, "SN: " + Information.SN);
        }

        private void StatusUIConfigure()
        {
            //  If want to use check stage of self API, need to use under line code.
            StatusUI.ChkStageFunc = StatusUI2.StatusUI.ChkStage.EnableByAts;
        }

        private void LogServerResponse(LogService.LogServer.Response response)
        {
            AddMessage(MessageTag.LOG, "Result: " + response.Result + "; Message: " + response.Message);
        }

        private void GetChangeFixData(ref string errorMsg)
        {
            AddMessage(MessageTag.LOG, "SFCS IP: " + Information.SFCSIP);
            _checkChangeFixture = _sfcsWS.CheckChangeFixture(Information.SFCSIP, StatusUI.txtPSN.Text, ref errorMsg);
            Information.Warning = (Information.Warning == "") ? errorMsg : Information.Warning;
        }

        private void DumpFailTestItem()
        {
            if (StatusUI.CheckListData().Count > 0)
            {
                ArrayList FailTestItem = StatusUI.CheckListData();

                for (int i = 0; i < FailTestItem.Count; i++)
                {
                    StatusUI2.Data dt = (StatusUI2.Data)FailTestItem[i];
                    AddMessage(MessageTag.ERROR, "Fail TestItem : " + dt.TestItem);
                }
            }
        }

        private void SetUITextBox(TextBox textBox, ref string sfcsData, string val)
        {
            ControlUIEvent.SetTextBox(textBox, val);
            sfcsData = val;
        }

        private SCheckFixData CheckStationFixtureState()
        {
            SCheckFixData sCheckFixData = new SCheckFixData(false, "");

            if (AutomaticTest == Ctrl.Enable)
            {
                sCheckFixData.IsOpen = CheckFixtureState(Robot.FixtureNumber);

                if (!sCheckFixData.IsOpen)
                {
                    sCheckFixData.ErrorMessage = "EmergencyStop";
                }
            }
            else
            {
                sCheckFixData.IsOpen = true;
            }

            return sCheckFixData;
        }

        private RobotControlServicesLib.Fixture.FixtureStatus GetFixtureStatus()
        {
            AddMessage(MessageTag.INFO, "ATS Result Status: " + Information.ResultStatus.ToString());

            switch (Information.ResultStatus)
            {
                case ATS_ResultStatus.WARNING:
                case ATS_ResultStatus.SFCSERROR:
                case ATS_ResultStatus.NG:
                    return RobotControlServicesLib.Fixture.FixtureStatus.NgWaitMove;
                case ATS_ResultStatus.RETEST:
                    return RobotControlServicesLib.Fixture.FixtureStatus.ReTestWaitMove;
                case ATS_ResultStatus.PASS:
                    return RobotControlServicesLib.Fixture.FixtureStatus.PassWaitMove;
                default:
                    return RobotControlServicesLib.Fixture.FixtureStatus.NgWaitMove;
            }
        }

        private RobotControlServicesLib.Fixture.FixtureStatus ThrowTestResult()
        {
            DataSystemData dataSystemData = null;

            if (Information.ResultStatus == ATS_ResultStatus.WARNING)
            {
                dataSystemData = SetDataSystemData();
                StatusUI.Write_Warning(Information.Warning, StatusUI2.StatusUI.StatusProc.Warning);
            }
            else
            {
                int chkCount = CheckItemCount();
                bool allTestPass = (StatusUI.CheckListData().Count == 0);
                AddMessage(MessageTag.INFO, "Alltestitem: " + ((allTestPass) ? "[PASS]" : "[NG]"));

                RetestData retestData = RetestAgain(allTestPass);

                //  Change fixture test or retest again.
                if (retestData.RetestAgain)
                {
                    Information.ResultStatus = ATS_ResultStatus.RETEST;
                    AddMessage(MessageTag.INFO, Information.Warning);
                    StatusUI.Write_Retest_Data();
                    dataSystemData = SetDataSystemData();
                    StatusUI.Write_Warning(Information.Warning, StatusUI2.StatusUI.StatusProc.Warning);
                }
                else
                {
                    Information.ResultStatus = ((allTestPass) ? ATS_ResultStatus.PASS : ATS_ResultStatus.NG);
                    dataSystemData = SetDataSystemData(chkCount);
                    StatusUI.WriteToSFCS();
                }
            }

            RobotControlServicesLib.Fixture.FixtureStatus robotStatus = GetFixtureStatus();
            CreateDSUploadTask(dataSystemData);
            UploadDataToLogClient();
            Information.FirstTest = false;

            return robotStatus;
        }

        private RobotControlServicesLib.Fixture.FixtureStatus GatSFCSResult(RobotControlServicesLib.Fixture.FixtureStatus fixtureStatus)
        {
            Ctrl SFCSreturn = GetCtrl(ReadINI("Setting", "RcsConfig", "WaitSFCSreturn", "Disable"));

            if (SFCSreturn == Ctrl.Enable && Information.ResultStatus != ATS_ResultStatus.WARNING)
            {
                //if warning
                if (StatusUI.SFCS_UI.SFCS_Status != StatusUI2.StatusUI.SFCS_status.OK)
                {
                    AddMessage(MessageTag.SFCS, "SFCS Throw Test Result Fail, program shut down!!");
                    Information.ResultStatus = ATS_ResultStatus.SFCSERROR;
                }
                else
                {
                    AddMessage(MessageTag.SFCS, "SFCS status: OK");
                }
            }
            else
            {
                AddMessage(MessageTag.LOG, "Ignore check SFCS return status");
            }

            RobotControlServicesLib.Fixture.FixtureStatus SFCSStatus = GetFixtureStatus();

            return SFCSStatus;
        }

        private void RobotTestResult(RobotControlServicesLib.Fixture.FixtureStatus fixtureStatus)
        {
            if (AutomaticTest == Ctrl.Enable)
            {
                string revokeMessage = "";
                Robot.FixtureStatus = fixtureStatus;
                AddMessage(MessageTag.RCS, "FixtureStatus: " + Robot.FixtureStatus.ToString());

                //RCS5:測試結束，Robert取走DUT前，檢查治具Open狀態，如果否發送EmergencyStop給Robert並解除註冊
                //If not automatic mode, IsOpen always return true.
                if (CheckFixtureState(Robot.FixtureNumber))
                {
                    //RCS6:通知RCS測試結果&連續NG，自動解除註冊
                    Robot.SendTestResultToRcs(Robot.FixtureStatus, Robot.FixtureNumber);
                    AddMessage(MessageTag.RCS, "NGDisableCounter: " + Robot.GetNGDisableCounter + "; NGDisableNum: " + Robot.GetNGDisableNum);

                    if (Robot.NGDisable)
                    {
                        AddMessage(MessageTag.RCS, "NG... RCS Revoke...");
                        revokeMessage = ("NG count over " + Robot.GetNGDisableNum + " times");
                    }
                    else if (Information.ResultStatus == ATS_ResultStatus.SFCSERROR) // 鎖站
                    {
                        AddMessage(MessageTag.RCS, "SFCS Error... RCS Revoke...");
                        revokeMessage = "SFCS status: Error";
                    }
                    else if (Information.ResultStatus == ATS_ResultStatus.WARNING)
                    {
                        AddMessage(MessageTag.RCS, ".");
                        revokeMessage = "SFCS status: Error";
                    }
                }
                else
                {
                    Robot.SendEmergencyStop(Robot.FixtureNumber);
                    System.Threading.Thread.Sleep(200);
                    revokeMessage = "EmergencyStop";
                }

                if (revokeMessage != "")
                {
                    Robot.SendRevokeToRcs(Robot.FixtureNumber);
                    FormExit(revokeMessage);
                }

                ControlUIEvent.SetRCSConnectEnable(true);
            }
        }
        #endregion

        #region Base API
        private bool BaseInitialize()
        {
            try
            {
                _sfcsWS.AddMessageEvent += new SFCSWebServiceAccess.AddMessageHandler(AddLog);
                tools.AddMessageEvent += new Tools.AddMessageHandler(AddLog);

                #region Read information data from setting.ini
                string sfcsIP = "";

                try
                {
                    sfcsIP = tools.GetIP("sfcs");
                }
                catch (Exception ex)
                {
                    AddMessage(MessageTag.ERROR, ex.Message);
                }

                _information = new CInformation
                {
                    Station = ReadINI("Setting", "Setting", "TestStation", "Base"),
                    Product = ReadINI("Setting", "Setting", "Production", "Base"),
                    BU = ReadINI("Setting", "Setting", "BU", "Base"),
                    ProjectName = ReadINI("Setting", "Setting", "ProjectName", "Base"),
                    ModelName = ReadINI("Setting", "Setting", "ModelName", "Base"),
                    Instances = ReadINI("Setting", "Setting", "Instances", "Base"),
                    Fixture = ReadINI("Setting", "UI", "Fix_Number", "NONE"),
                    SFCSIP = ((sfcsIP == "") ? "VerificationIP" : sfcsIP),
                    PartNumber = ReadINI("Setting", "Setting", "PartNumber", "Verify"),
                    SN = "",
                    Warning = "",
                    ProgramVersion = "V" + _fileVersion.FileVersion.Substring(0, _fileVersion.FileVersion.LastIndexOf('.')),
                    AppVersion = _fileVersion.FileVersion,
                    ReleaseDate = (new FileInfo(_assembly.Location)).LastWriteTime.ToString("yyyy/MM/dd"),
                    FirstTest = true
                };
                #endregion

                #region Read DataSystem configure from setting.ini
                _configureData = new ConfigureData()
                {
                    DataBase = ReadINI("Setting", "DataSystem", "DB", "NW"),
                    FTP_Username = ReadINI("Setting", "DataSystem", "FTPUsername", "telog"),
                    FTP_Password = ReadINI("Setting", "DataSystem", "FTPPassword", "ftp@6667799"),
                    FTP_IP = ReadINI("Setting", "DataSystem", "FTPIP", "10.69.98.68"),
                    Station = ReadINI("Setting", "Setting", "TestStation", "NONE"),
                    SFCSIP = sfcsIP,
                    ATSLogMode = ReadINI("Setting", "Setting", "ATSLogMode", "ByResult")
                };
                #endregion

                string factoryMode = ReadINI("Setting", "Setting", "GetLabelBy", "WebCamera");
                eGetLabelBy = tools.ParseEnum<EGetLabelBy>(factoryMode);

                StatusUIConfigure();

                _reqCode = new ATS_Template.TEServiceClient.ReqCode()
                {
                    AppName = (Information.ProjectName + "_" + Information.Station),
                    UserID = "TE",
                    UserPwd = "zHheIRhxPwFR9TAxgw7kYA==",
                    LangType = ATS_Template.TEServiceClient.LangType.zh_Hant,
                };

                GetCurrentPartNumber();
                return true;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Base init failed." + ex.Message);
                return false;
            }
        }

        protected bool BaseStartBefore()
        {
            Information.StatusUI_SP.Clear();
            Information.ExtensionDict.Clear();
            ControlUIEvent.SetRCSConnectEnable(false);
            Information.IsGoldenSample = false;
            Information.ResultStatus = ATS_ResultStatus.IDLE;
            Information.Warning = "";
            return true;
        }

        private bool BaseTestInitialize()
        {
            LogExtension.Clear();
            Information.SN = StatusUI.txtPSN.Text;
            Information.Fixture = StatusUI.SFCS_Data.Fixture;
            Information.SFCSIP = StatusUI.SFCS_Conn.SfcsIp;

            string errorMsg = "";
            string getPN = "";
            bool res = true;

            if (!Information.IsGoldenSample)
            {
                try
                {
                    getPN = _sfcsWS.GetPartNumberBySN(Information.SN, ref errorMsg);
                    res = ComparePartNumber(getPN);
                    AddMessage(MessageTag.INFO, "P/N(IP): " + Information.PartNumber + "; P/N(SN): " + getPN + "; Result: " + res.ToString());
                }
                catch (Exception ex)
                {
                    AddMessage(MessageTag.ERROR, ex.Message);
                    res = false;
                }
            }

            bool outputPN = (ReadINI("Setting", "Setting", "OutputPN", "Disable").ToUpper() == "ENABLE");

            if (outputPN)
            {
                tools.WriteToFile(@"C:\ATS\PN\PN.ini", "[PN]", Tools.WriteToFileMode.ReNew);
                tools.WriteToFile(@"C:\ATS\PN\PN.ini", "PN=" + Information.PartNumber, Tools.WriteToFileMode.WriteToLast);
            }

            AddMessage(MessageTag.LOG, "OutputPN: " + outputPN.ToString());
            AddMessage(MessageTag.LOG, "Change fixture: " + _checkChangeFixture.ToString());

            ReadOutSetting();
            PrintInformation();
            PrintOutSetting();

            Information.ResultStatus = ATS_ResultStatus.TESTING;
            Information.Warning = "";

            if (Information.IsGoldenSample)
            {
                Information.ChangeGoldenMode();
            }

            return res && CheckStage(StatusUI.txtPSN.Text, Information.SFCSIP);
        }
        #endregion

        #region Base virtual API
        /// <summary> 底層結束。 </summary>
        /// Note: 作者Clarence.Lai, 我承認這段我真的寫的很醜
        protected virtual void BaseRelease()
        {
            DumpFailTestItem();
            SetFirstSFCSLine();
            _testFlow = null;

            RobotControlServicesLib.Fixture.FixtureStatus fixtureStatus = ThrowTestResult();
            fixtureStatus = GatSFCSResult(fixtureStatus);
            RobotTestResult(fixtureStatus);
            EndReleaseStatus();
        }
        #endregion

        #region protect virtual API
        protected virtual bool CheckStage(string sn, string sfcs_ip)
        {
            AddMessage(MessageTag.LOG, "SN: " + sn + ";SFCSIP:" + sfcs_ip);

            if (ReadINI("Setting", "Setting", "Check_SFCS_Stage", "disable").ToUpper() == "DISABLE")
            {
                AddMessage(MessageTag.ERROR, "Check SFCS stage disable");
                return true;
            }

            string err_Msg = "";
            //bool res = _sfcsWS.Check_SFCS_Stage(sn, sfcs_ip, ref err_Msg);
            bool res = _SFCSWebService.check_SFCS_Stage_new(sn, sfcs_ip, ref err_Msg);

            if (!res || err_Msg != "")
            {
                WriteWarning(err_Msg);
                ControlUIEvent.ChangeStatusColor(StatusUI.lbStatus, "SN: " + sn + "\r\n" + Information.Warning, System.Drawing.Color.Yellow);
                res = false;
            }

            AddMessage(MessageTag.SFCS, "Check SFCS stage: " + res.ToString());
            return res;
        }

        protected virtual bool ComparePartNumber(string inputPN)
        {
            Ctrl checkStage = ((ReadINI("Setting", "Setting", "Check_SFCS_Stage", "disable").ToUpper() == "DISABLE") ? Ctrl.Disable : Ctrl.Enable);
            GetCurrentPartNumber();

            if (checkStage == Ctrl.Enable && Information.PartNumber != inputPN)
            {
                WriteWarning("Station P/N not match with S/N P/N.");
                return false;
            }

            return true;
        }

        /// <summary> 設定SFCS輸出檔案內容中的第一行，此函式會在WriteToSFCS之前被呼叫，使用者可自行覆寫。 </summary>
        protected virtual void SetFirstSFCSLine()
        {
            if (!Information.IsGoldenSample)
            {
                return;
            }

            StatusUI.CombineLabel();

            if (Information.GoldenSN != "")
            {
                AddMessage(MessageTag.INFO, "Golden SN: " + Information.GoldenSN);
                StatusUI.SFCS_Data.First_Line.Replace(Information.SN, Information.GoldenSN);
            }
            else
            {
                AddMessage(MessageTag.LOG, "Golden SN is empty.");
            }
        }

        protected virtual void EndReleaseStatus()
        {
            Information.ResultStatus = ATS_ResultStatus.IDLE;
        }

        protected virtual void ReadOutSetting()
        {
            foreach (System.Reflection.FieldInfo info in OutsideSetting.GetType().GetFields())
            {
                object getV = ReadINI("Setting", "OutSetting", info.Name, "Default#9");
                string getVStr = Convert.ToString(getV);

                if (getVStr == "Default#9")
                {
                    continue;
                }

                info.SetValue(OutsideSetting, Convert.ChangeType(getV, info.FieldType));
            }
        }

        protected virtual bool ReadTestFlow(string userFlow = "")
        {
            string testInstances = ReadINI("Setting", "Setting", "Instances", "NONE");
            string xmlFlow = ReadINI("Setting", "Setting", "XmlFlowName", "NONE");
            Ctrl flowPathAddModel = GetCtrl(ReadINI("Setting", "Setting", "FlowPathAddModel", "Disable"));
            string testXML = "";

            if (xmlFlow == "NONE")
            {
                testXML = testInstances + ".xml";
            }
            else
            {
                testXML = xmlFlow + ".xml";
            }

            try
            {
                string testFlowPath = Path.Combine(Application.StartupPath, "TestFlow");

                if (flowPathAddModel == Ctrl.Enable)
                {
                    testFlowPath = Path.Combine(testFlowPath, Information.ModelName);
                }

                if (!string.IsNullOrEmpty(userFlow))
                {
                    testFlowPath = Path.Combine(testFlowPath, userFlow);
                }
                else
                {
                    testFlowPath = Path.Combine(testFlowPath, testXML);
                }

                if (File.Exists(testFlowPath))
                {
                    AddMessage(MessageTag.INFO, "Read test flow: " + testFlowPath);

                    if (CheckFlowMD5(testFlowPath))
                    {
                        _testFlow = null;
                        _testFlow = new CXmlTestFlow(testFlowPath);
                        _testFlow.AddMessageEvent += new CXmlTestFlow.AddMessageHandler(AddLog);
                        _testFlow.WriteRetestDataEvent += new CXmlTestFlow.dWriteRetestData(StatusUI.Write_Retest_Data);
                        _testFlow.DoRetestEvent += new CXmlTestFlow.dDoRetest(CheckRetestWithSFCS);
                        return true;
                    }
                    else
                    {
                        WriteWarning("TestFlow file is incorrect");
                        AddMessage(MessageTag.ERROR, "TestFlow file is incorrect");
                        return false;
                    }
                }
                else
                {
                    AddMessage(MessageTag.ERROR, "File not found(" + @testFlowPath + ")");
                    Information.ResultStatus = ATS_ResultStatus.ERROR;
                    return false;
                }
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, ex.Message);
                return false;
            }
        }

        public bool CheckFlowMD5(string FileFullPath)
        {
            string md5Str = "";
            string alltext = File.ReadAllText(FileFullPath);
            string flowText = Regex.Replace(alltext, @"<CkSum>(.)+</CkSum>", "<CkSum></CkSum>");
            Match match = Regex.Match(alltext, @"(?<=<CkSum>)(.*)(?=<\/CkSum>)");
            string flowMD5 = match.ToString().ToUpper();

            using (var md5 = MD5.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(flowText);
                var hash = md5.ComputeHash(bytes);
                md5Str = BitConverter.ToString(hash).Replace("-", "").ToUpper();
            }

            AddMessage(MessageTag.LOG, "Flow CkSum: " + flowMD5 + "; Cal CkSum: " + md5Str);

            return (md5Str == flowMD5);
        }

        //modify for GSI project
        protected virtual int CheckItemCount()
        {
            string xmlFlow = ReadINI("Setting", "Setting", "XmlFlowName", "NONE");
            int itemCount = StatusUI.ListDataSFCS.Count;
            int normalSpecCount = Convert.ToInt32(ReadINI("Setting", "ChkCount", (xmlFlow.Contains("Long")) ? "ItemCount_LongTest" : "ItemCount", "-1"));
            int goldenSpecCount = Convert.ToInt32(ReadINI("Setting", "ChkCount", "ItemCount_Golden", "-1"));
            int currentSpecCount = ((Information.IsGoldenSample) ? goldenSpecCount : normalSpecCount);
            string chkCountName = (OutsideSetting.TotalTestItemCountStr != null && OutsideSetting.TotalTestItemCountStr != "") ? OutsideSetting.TotalTestItemCountStr : "ChkCount";
            string chkCountError = ReadINI("SPEC", "Error_Code", chkCountName, "DRP00299");

            AddMessage(MessageTag.LOG, "Test item count SPEC: " + currentSpecCount.ToString() + "; Test: " + itemCount.ToString());

            StatusUI.AddDataMark(chkCountName, currentSpecCount.ToString(), itemCount.ToString(), chkCountError);

            return itemCount;
        }

        #endregion

        #region Implementation Common API interface
        public bool IsGoldenSample { get { return Information.IsGoldenSample; } }

        public string ReadINI(string filename, string option, string key, string defaultval)
        {
            return WNC.API.Func.ReadINI(Application.StartupPath, filename, option, key, defaultval);
        }

        public T GetINI<T>(string filename, string option, string key, string defaultval)
        {
            string readIni = ReadINI(filename, option, key, defaultval);

            return (T)Convert.ChangeType(readIni, typeof(T));
        }

        public bool AddTestItemByValue(string testItem, double value)
        {
            StatusUI2.StatusUI.Result result = StatusUI.AddData(testItem, value);
            return (result == StatusUI2.StatusUI.Result.Pass);
        }

        public bool AddTestItemResult(string testItem, bool result)
        {
            string errorCode = ReadINI("SPEC", "Error_Code", testItem, "NONE");
            string unit = (result ? "Pass" : "NG");
            double val = ((result) ? 0 : -2);
            StatusUI.AddData(testItem, unit, -1, 1, val, errorCode);

            return result;
        }

        public bool AddValueData(string testItem, string unit, double lsl, double usl, double Val, string errorCode)
        {
            StatusUI2.StatusUI.Result result = StatusUI.AddData(testItem, unit, lsl, usl, Val, errorCode);
            return (result == StatusUI2.StatusUI.Result.Pass);
        }

        public bool WriteSFCSLine(string line, string item, string spec, string data, string errorCode)
        {
            AddMessage(MessageTag.INFO, "Line: " + line + "; Item: " + item + "; SPEC: " + spec + "; Data: " + data);

            switch (line)
            {
                case "13":
                    return (StatusUI.AddDataMark(item, spec, data, errorCode) == StatusUI2.StatusUI.Result.Pass);
                case "15":
                    return (StatusUI.AddDataRaw(item, spec, data, errorCode) == StatusUI2.StatusUI.Result.Pass);
            }

            return false;
        }

        public bool WriteSFCSLine(string line, string item, string data)
        {
            return WriteSFCSLine(line, item, data, data, "DA0001");
        }

        public void WriteWarning(string msg)
        {
            Information.Warning = msg;
        }

        public bool PingDUT(string ip, int timeOutSec, int count)
        {
            return tools.PingCount(ip, timeOutSec, count);
        }

        public bool PingTest(string testItem, string ip, int timeOutSec, int count)
        {
            bool testResult = tools.PingCount(ip, timeOutSec, count);

            return AddTestItemResult(testItem, testResult);
        }

        public bool PingTestBindIP(string testItem, string srcIP, string dstIP, int timeOutSec, int count)
        {
            bool testResult = tools.Ping(new Tools.ParamPing()
            {
                SrcIP = srcIP,
                DstIP = dstIP,
                TimeoutSec = timeOutSec,
                SuccessCnt = count,
                Interval = 600,
            });

            return AddTestItemResult(testItem, testResult);
        }

        public void AddLog(string msg)
        {
            StatusUI.AddLog(msg);
        }

        public bool ShowCheckMessageBox(string testItem, string caption, string content)
        {
            string msg = content.Replace("\\r\\n", "").Replace("\r\n", "");
            AddMessage(MessageTag.LOG, msg);

            string Content = content.Replace("\\r\\n", "\r\n");

            return AddTestItemResult(
                testItem,
                (System.Windows.Forms.MessageBox.Show(
                    Content,
                    caption,
                    System.Windows.Forms.MessageBoxButtons.YesNo, MessageBoxIcon.None,
                    MessageBoxDefaultButton.Button1,
                    MessageBoxOptions.ServiceNotification,
                    false) == System.Windows.Forms.DialogResult.Yes)
                    );
        }

        public bool Strncmp(string str1, string str2, int num)
        {
            return tools.Strncmp(str1, str2, num);
        }

        public void AddMessage(MessageTag tag, string msg)
        {
            int tagLength = tag.ToString().Length + 2;
            int pad = tagLength + (8 - tagLength);
            AddLog(("[" + tag.ToString() + "]").PadRight(pad) + msg);
        }

        public bool StartProcess(System.Diagnostics.ProcessStartInfo info)
        {
            return tools.StartProcess(info);
        }

        public bool KillTask(string taskName)
        {
            return tools.KillTask(taskName);
        }

        public virtual Ctrl GetCtrl(string ctrl)
        {
            return tools.ParseEnum<Ctrl>(ctrl);
        }

        public string GetToolResponse(string fileName, string arguments, int timeOutSec, string keyword = "")
        {
            return tools.GetToolResponse(fileName, arguments, timeOutSec, keyword);
        }

        public virtual int GetRetestCount()
        {
            try
            {

                ATS_Template.TEServiceClient.CTChkRetestReqResult response = teServiceClient.TxChkRetestInq(new ATS_Template.TEServiceClient.CTChkRetestReqInParm()
                {
                    ReqCode = _reqCode,
                    Sn = StatusUI.SFCS_Data.PSN,
                });

                if (response.RetCode.ReturnCode != "00000")
                {
                    int rtc = 0;
                    AddMessage(MessageTag.ERROR, response.RetCode.MessageText);
                    WriteWarning(response.RetCode.MessageText);
                    return -1;
                }

                AddMessage(MessageTag.INFO, "Get retest count: " + response.Retest);
                return response.Retest;
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, "{GetRetestCount} " + ex.Message);
            }

            return -1;
        }
        #endregion

        #region protect COMMON API
        protected string GetCurrentPartNumber()
        {
            string currentPN = _sfcsWS.GetPartNumberBySFCSIP(Information.SFCSIP);
            AddMessage(MessageTag.INFO, "URL: " + teServiceClient.Endpoint.Address.Uri);

            if (Information.PartNumber != currentPN)
            {
                Information.PartNumber = currentPN;

                var getUrl = teServiceClient.TxGetWebServiceURLInq(new ATS_Template.TEServiceClient.CTGetWebServiceURLReqInParm()
                {
                    ReqCode = _reqCode,
                    ReqURL = teServiceClient.Endpoint.Address.Uri.AbsoluteUri,
                    Pn = Information.PartNumber
                });

                teServiceClient.Close();
                teServiceClient = new ATS_Template.TEServiceClient.TEServiceClient();
                teServiceClient.Endpoint.Address = new System.ServiceModel.EndpointAddress(getUrl.WebServerURL);
                AddMessage(MessageTag.INFO, "WCF URL: " + getUrl.WebServerURL);
            }

            return currentPN;
        }

        protected void WriteINI(string path, string filename, string section, string key, string value)
        {
            WNC.API.Func.WriteINI(path, filename, section, key, value);
        }

        /// <summary> 確認是否要交換治具(取得測試次數)。 </summary>
        protected bool CheckChangeFixture()
        {
            bool result = false;
            string getError = "";
            Ctrl changeFix = GetCtrl(ReadINI("Setting", "Setting", "CheckRetest", "Disable"));
            AddMessage(MessageTag.INFO, "Change fixture: " + changeFix.ToString());

            if (changeFix == Ctrl.Enable)
            {
                GetChangeFixData(ref getError);
                result = ((getError == "") && _checkChangeFixture.ChangeFixture);
                AddMessage(MessageTag.INFO, "Change fixture result: " + _checkChangeFixture.ToString());
            }
            else
            {
                _checkChangeFixture.ChangeFixture = false;
                _checkChangeFixture.NGCount = 0;
                _checkChangeFixture.RetestCount = 0;
                _checkChangeFixture.PassCount = 0;
                result = true;
            }

            return result;
        }

        protected bool CheckRetestWithSFCS()
        {
            Ctrl retest = GetCtrl(ReadINI("Setting", "Retest", "Ctrl", "Disable"));
            AddMessage(MessageTag.INFO, "Retest Ctrl: " + retest.ToString());

            if (retest == Ctrl.Enable)
            {
                int retestLimit = GetINI<int>("Setting", "Retest", "Limit", "-1");
                int retestCount = GetRetestCount();
                bool result = (retestCount != -1 && retestLimit != -1);
                result = result && (retestCount < retestLimit);
                AddMessage(MessageTag.INFO, "Check retest Count: " + retestCount + "; Limit: " + retestLimit + "; Res: " + result.ToString());
                return result;
            }

            return false;
        }

        protected bool CheckRetestCount()
        {
            string getError = "";
            bool result = false;
            Ctrl retest = GetCtrl(ReadINI("Setting", "Retest", "Ctrl", "Disable"));
            AddMessage(MessageTag.INFO, "Retest Ctrl: " + retest.ToString());

            if (retest == Ctrl.Enable)
            {
                GetChangeFixData(ref getError);
                result = (getError == "");

                if (result)
                {
                    int retestLimit = Convert.ToInt32(ReadINI("Setting", "Retest", "Limit", "-1"));
                    result = retestLimit > _checkChangeFixture.RetestCount;
                    AddMessage(MessageTag.INFO, "Check Retest (Limit: " + retestLimit + "; Count: " + _checkChangeFixture.RetestCount + "; Res: " + result + ")");
                }

                return result;
            }
            else
            {
                return false;
            }
        }

        // Jerry added on 2021.01.23
        public bool CheckFailTest()
        {
            if (StatusUI.CheckListData().Count > 0)
            {
                return false;
            }
            return true;
        }

        /// <summary> 顯示提示用的MessageBox(Only OK button)。 </summary>
        /// <param name="caption">標頭</param>
        /// <param name="content">提示內文</param>
        /// <returns></returns>
        protected bool ShowNoticeMessageBox(string caption, string content)
        {
            string msg = content.Replace("\\r\\n", "").Replace("\r\n", "");
            AddMessage(MessageTag.LOG, msg);

            string Content = content.Replace("\\r\\n", "\r\n");
            System.Windows.Forms.MessageBox.Show(
                Content,
                caption,
                System.Windows.Forms.MessageBoxButtons.OK,
                MessageBoxIcon.None,
                MessageBoxDefaultButton.Button1,
                MessageBoxOptions.ServiceNotification,
                false
                );

            return true;
        }

        protected void SetLabelInfoToUI(string[] labelArray)
        {
            if (labelArray.Length == 1)
            {
                SetUITextBox(StatusUI.txtPSN, ref StatusUI.SFCS_Data.PSN, labelArray[0]);
            }
            else if (labelArray.Length == 2)
            {
                SetUITextBox(StatusUI.txtPSN, ref StatusUI.SFCS_Data.PSN, labelArray[0]);
                SetUITextBox(StatusUI.txtSP, ref StatusUI.SFCS_Data.SP, labelArray[1]);
            }
            else if (labelArray.Length == 3)
            {
                SetUITextBox(StatusUI.txtPSN, ref StatusUI.SFCS_Data.PSN, labelArray[0]);
                SetUITextBox(StatusUI.txtSP, ref StatusUI.SFCS_Data.SP, labelArray[1]);
                SetUITextBox(StatusUI.txtSP1, ref StatusUI.SFCS_Data.SP1, labelArray[2]);
            }
            else if (labelArray.Length == 4)
            {
                SetUITextBox(StatusUI.txtPSN, ref StatusUI.SFCS_Data.PSN, labelArray[0]);
                SetUITextBox(StatusUI.txtSP, ref StatusUI.SFCS_Data.SP, labelArray[1]);
                SetUITextBox(StatusUI.txtSP1, ref StatusUI.SFCS_Data.SP1, labelArray[2]);
                SetUITextBox(StatusUI.txtSP2, ref StatusUI.SFCS_Data.SP2, labelArray[3]);
            }
            else if (labelArray.Length == 5)
            {
                SetUITextBox(StatusUI.txtPSN, ref StatusUI.SFCS_Data.PSN, labelArray[0]);
                SetUITextBox(StatusUI.txtSP, ref StatusUI.SFCS_Data.SP, labelArray[1]);
                SetUITextBox(StatusUI.txtSP1, ref StatusUI.SFCS_Data.SP1, labelArray[2]);
                SetUITextBox(StatusUI.txtSP2, ref StatusUI.SFCS_Data.SP2, labelArray[3]);
                SetUITextBox(StatusUI.txtSP3, ref StatusUI.SFCS_Data.SP3, labelArray[4]);
            }
            else if (labelArray.Length == 6)
            {
                SetUITextBox(StatusUI.txtPSN, ref StatusUI.SFCS_Data.PSN, labelArray[0]);
                SetUITextBox(StatusUI.txtSP, ref StatusUI.SFCS_Data.SP, labelArray[1]);
                SetUITextBox(StatusUI.txtSP1, ref StatusUI.SFCS_Data.SP1, labelArray[2]);
                SetUITextBox(StatusUI.txtSP2, ref StatusUI.SFCS_Data.SP2, labelArray[3]);
                SetUITextBox(StatusUI.txtSP3, ref StatusUI.SFCS_Data.SP3, labelArray[4]);
                SetUITextBox(StatusUI.txtSP4, ref StatusUI.SFCS_Data.SP4, labelArray[5]);
            }
        }

        protected void FormExit(string message)
        {
            MessageBox.Show(message, "Warnning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            Environment.Exit(0);
        }
        #endregion

        #region Public API
        public RetestData RetestAgain(bool testResult)
        {
            RetestData retestData = new RetestData();
            Ctrl changeFix = GetCtrl(ReadINI("Setting", "Setting", "CheckRetest", "Disable"));

            //  All test item pass or test device is golden sample.
            if (testResult || Information.IsGoldenSample)
            {
                return retestData;
            }
            else if (_checkChangeFixture.ChangeFixture && (changeFix == Ctrl.Enable))
            {
                retestData.RetestAgain = true;
                Information.Warning = "更換治具測試(Change fixture retest.)";
            }
            else
            {
                if (CheckRetestWithSFCS())
                {
                    retestData.RetestAgain = true;
                    Information.Warning = "請重新測試(Please retest again.)";
                }
            }

            return retestData;
        }

        public void StartTestThread()
        {
            _test = new System.Threading.Thread(new System.Threading.ThreadStart(OnTest));
            _test.Start();
        }

        public bool checkFixture(string Fixture)
        {
            string fixture = ReadINI("Setting", "UI", "Fix_Number", "0");
            string enFixture = Convert.ToBase64String(Encoding.UTF8.GetBytes(fixture));

            if (enFixture != Fixture)
            {
                WriteWarning("This flow cannot be usedon this fixture");
            }

            return (enFixture == Fixture);
        } //Encoding.UTF8.GetString(Convert.FromBase64String(ABase64))
        #endregion

        #region DataSystem相關
        private string GetNGItem(ArrayList sfcsdata)
        {
            if (sfcsdata.Count <= 0)
            {
                return "";
            }

            if (sfcsdata[0].GetType() == typeof(StatusUI2.Data))
            {
                return ((StatusUI2.Data)(sfcsdata[0])).TestItem;
            }
            else if (sfcsdata[0].GetType() == typeof(string))
            {
                return sfcsdata[0].ToString();
            }
            else
            {
                return "TYPE_ERROR";
            }
        }

        private string GetATSLogPath()
        {
            bool logByResult = (_configureData.ATSLogMode.ToUpper() == "BYRESULT");

            string resPath = "";
            string statusuiPath = Path.Combine(Application.StartupPath, "StatusUI2.dll");
            Ctrl sfcs = GetCtrl(ReadINI("Setting", "UI", "SFCS", "Disable"));
            System.Diagnostics.FileVersionInfo info = System.Diagnostics.FileVersionInfo.GetVersionInfo(statusuiPath);

            if (Convert.ToInt32(info.FileVersion.Split('.')[2]) > 100 && sfcs == Ctrl.Disable)
            {
                string logPath = (string.IsNullOrEmpty(StatusUI.Log_S.File_Name.LogPre)) ? StatusUI.Log_S.File_Name.Log : StatusUI.Log_S.File_Name.LogPre;
                return logPath;
            }
            else
            {
                resPath = StatusUI.Log_S.File_Name.ResultPath;

                if (string.IsNullOrEmpty(resPath))
                {
                    string logPath = StatusUI.Log_S.File_Name.LogPath;
                    string logFileName = StatusUI.Log_S.File_Name.LogFile;

                    if (logFileName == null)
                    {
                        logFileName = StatusUI.Log_S.File_Name.Log.Split('\\').Last();
                    }

                    if (logByResult && (Information.ResultStatus == ATS_ResultStatus.PASS || Information.ResultStatus == ATS_ResultStatus.NG))
                    {
                        string resultFolder = (StatusUI.CheckListData().Count != 0) ? "NG" : "Pass";
                        resPath = @System.IO.Path.Combine(logPath, resultFolder, logFileName).Replace("\\\\", "\\");
                    }
                    else
                    {
                        resPath = @System.IO.Path.Combine(logPath, logFileName).Replace("\\\\", "\\");
                    }
                }

                return resPath;
            }
        }

        private DataSystemData SetDataSystemData(int chkcount = -1)
        {
            if (!(ReadINI("Setting", "DataSystem", "UseDataSystem", "0") == "1"))
            {
                return null;
            }

            DataSystemData dataSystemData = new DataSystemData();

            try
            {
                string error = "";
                string getSN = StatusUI.SFCS_Data.PSN;
                string PN = _SFCSWebService.GetPN_BySN(getSN, ref error);
                string MO = _SFCSWebService.GetWO_BySN(getSN, ref error);

                if (PN == "")
                {
                    PN = "ATS_Verify";
                }

                if (MO == "")
                {
                    MO = "ATS_Verify";
                }

                dataSystemData.Set(
                    new UploadFTPData()
                    {
                        FTP_IP = _configureData.FTP_IP,
                        FTP_Username = _configureData.FTP_Username,
                        FTP_Password = _configureData.FTP_Password,
                        PN = PN,
                        MO = MO,
                        Station = _configureData.Station,
                        TestPass = (StatusUI.CheckListData().Count == 0)
                    },
                    new WriteSQLData()
                    {
                        FirstTest = Information.FirstTest,
                        InSFCS = true,
                        GoldenSample = Information.IsGoldenSample,
                        PN = PN,
                        SFCSIP = Information.SFCSIP,
                        Fixture = StatusUI.SFCS_Data.Fixture,
                        SN = getSN,
                        DataBase = _configureData.DataBase,
                        Result = Information.ResultStatus.ToString(),
                        NGItem = GetNGItem(StatusUI.CheckListData()),
                        ErrorCode = ((Information.ResultStatus == ATS_ResultStatus.NG) ? StatusUI.SFCS_Data.ErrorCode : ""),
                        Station = _configureData.Station,
                        Warning = Information.Warning,
                        TestTime = Convert.ToDouble(StatusUI.SFCS_Data.TestTimeSec),
                        MO = MO,
                        ListDataSFCS = StatusUI.ListDataSFCS,
                        StatusUI_Setting = StatusUI.Setting,
                        StatusUiVersion = StatusUI.ATSInfo.StatusUiVersion,
                        Version = StatusUI.ATSInfo.Version,
                        Path = StatusUI.ATSInfo.Path
                    });

                dataSystemData.SetChkCount(chkcount);

                return dataSystemData;
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, ex.Message);
                return null;
            }
        }

        private void UploadDataToDataSystem(DataSystemData datasystemdata)
        {
            DataSystem dataSystem = new DataSystem();
            dataSystem.AddMessageEvent += new DataSystem.AddMessageHandler(AddLog);


            try
            {
                dataSystem.WriteSQLData(datasystemdata);
            }
            catch (Exception ex)
            {
                AddMessage(MessageTag.ERROR, ex.Message);
            }
        }

        private void CreateDSUploadTask(DataSystemData datasystemdata)
        {
            if ((!(ReadINI("Setting", "DataSystem", "UseDataSystem", "0") == "1")) || datasystemdata == null)
            {
                return;
            }

            datasystemdata.SetLogPath(GetATSLogPath());
            datasystemdata.SetTestTime(Convert.ToDouble(StatusUI.SFCS_Data.TestTimeSec));

            AddMessage(MessageTag.INFO, "Get PN from SFCS: " + datasystemdata.GetUploadFTPData.PN);
            AddMessage(MessageTag.INFO, "Get MO from SFCS: " + datasystemdata.GetUploadFTPData.MO);

            //  等一下，怕log還沒搬完
            System.Threading.Thread.Sleep(500);

            System.Threading.Thread dsThread = new System.Threading.Thread(() => UploadDataToDataSystem(datasystemdata));
            dsThread.Start();
        }
        #endregion

        #region Log Client
        private void UploadDataToLogClient()
        {
            Ctrl logClientCtrl = GetCtrl(ReadINI("Setting", "LogClient", "Upload", "Enable"));

            if (logClientCtrl == Ctrl.Enable)
            {
                try
                {
                    LogClient.BU bu = LogClient.GetBU(ReadINI("Setting", "DataSystem", "DB", "NW"));
                    LogClient logClient = new LogClient(Information.ModelName, bu, LogClient.Method.UploadDataToServer);
                    logClient.AddMessageEvent += new LogClient.AddMessageHandler(AddLog);
                    logClient.ResponseEvent += new LogClient.ResponseHanler(LogServerResponse);
                    logClient.GetPN_BySNEvent += new LogClient.GetPN_BySNEventHandler(_SFCSWebService.GetPN_BySN);
                    logClient.GetWO_BySNEvent += new LogClient.GetWO_BySNEventHandler(_SFCSWebService.GetWO_BySN);
                    logClient.SetProductionInfo(Information.SN, Information.Station, Information.ResultStatus.ToString());

                    LogClient.UploadInfo uploadInfo = new LogClient.UploadInfo()
                    {
                        FirstTest = Information.FirstTest,
                        SFCSIP = Information.SFCSIP,
                        Fixture = Information.Fixture,
                        NGItem = GetNGItem(StatusUI.CheckListData()),
                        ErrorCode = ((Information.ResultStatus == ATS_ResultStatus.NG) ? StatusUI.SFCS_Data.ErrorCode : ""),
                        Warning = Information.Warning,
                        TestTime = Convert.ToDouble(StatusUI.SFCS_Data.TestTimeSec),
                        ChkCount = CheckItemCount(),
                    };

                    LogClient.UploadDataToServerData uploadDataToServerData = new LogClient.UploadDataToServerData()
                    {
                        RequestTimeoutSec = 20,
                        Json_UploadInfo = JsonConvert.SerializeObject(uploadInfo),
                        Json_ATSInfo = JsonConvert.SerializeObject(StatusUI.ATSInfo),
                        Json_ATSSetting = JsonConvert.SerializeObject(StatusUI.Setting),
                        Json_SFCS_Data = JsonConvert.SerializeObject(StatusUI.SFCS_Data),
                        Json_ListSPCData = JsonConvert.SerializeObject(StatusUI.ListDataSFCS),
                        ATSLog = GetATSLogPath(),
                        LogExtension = LogExtension
                    };

                    logClient.UploadDataToServer(uploadDataToServerData);
                }
                catch (Exception ex)
                {
                    AddMessage(MessageTag.ERROR, "{UploadDataToLogClient} " + ex.Message);
                }
            }
        }
        #endregion

        #region RCS virtual function.
        private void RcsHandlerEventLog(object o, string fixtureNumber, string Log)
        {
            AddMessage(MessageTag.RCS, Log);
        }

        //RCS2: Robert取放前檢查治具Open狀態
        protected virtual bool CheckFixtureState(string fixtureNumber)
        {
            return false;
        }

        protected virtual bool GetSn(string fixtureNumber, string sn)
        {
            return false;
        }

        protected virtual bool CheckSmooth(string fixtureNumber)
        {
            AddMessage(MessageTag.RCS, "Check Smooth PASS");
            return true;
        }

        protected virtual bool StartTest(string fixtureNumber)
        {
            AddMessage(MessageTag.RCS, "Call Start Test");
            ControlUIEvent.StartBtnPerformClick(StatusUI.buStart);
            return true;
        }
        #endregion
    }
}
