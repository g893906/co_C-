﻿using System;
using System.Reflection;
using System.Collections.Generic;
using StatusUI2;

namespace TestPattern
{
    class TestFactory
    {
        public static IBaseInstances station = null;
        private static readonly string namespaceName = "TestPattern.";

        private static bool CreateInstances(string pClassName, StatusUI pStatusUI)
        {
            try
            {
                station = (BaseStation)Activator.CreateInstance(Type.GetType(namespaceName + pClassName), pStatusUI);
                return true;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Create test instanes(" + pClassName + ") failed\r\nException: " + ex.Message);
                return false;
            }
        }

        private static bool StationInit()
        {
            try
            {
                station.OnInitialize();
                return true;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Station Init failed. " + ex.Message);
                return false;
            }
        }

        public static IBaseInstances Create(string pClassName, StatusUI pStatusUI)
        {
            bool testRes = CreateInstances(pClassName, pStatusUI);
            testRes = testRes && StationInit();

            return station;
        }
    }
}
