﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestPattern
{
    public enum ATS_ResultStatus
    {
        IDLE = 0,
        TESTING = 1,
        PASS = 2,
        NG = 3,
        WARNING = 4,
        RETEST = 5,
        ERROR = 6,
        SFCSERROR = 7,
    }

    public struct InformationBaseStruct
    {
        public string Station;
        public string Product;
        public string ProjectName;
        public string ModelName;
        public string Instances;
        public string Warning;
        public string BU;
        public string PartNumber;
        public string SFCSIP;
        public string Fixture;
        public string SN;
        public string GoldenSN;
        public string ProgramVersion;
        public string AppVersion;
        public string ReleaseDate;
        public bool FirstTest;
        public bool IsGoldenSample;
        public Dictionary<string, string> StatuUI_SP;
        public Dictionary<string, string> ExtensionDict;
        public ATS_ResultStatus ResultStatus;
    }

    public class CInformation
    {
        public delegate void TestStatusHandler(ATS_ResultStatus status);
        public event TestStatusHandler TestStatusCallback;

        public delegate void ChangeGoldeModeHandler(bool isgolden);
        public event ChangeGoldeModeHandler ChangeGoldeModeCallback;

        private InformationBaseStruct _informationBaseStruct;

        public CInformation()
        {
            _informationBaseStruct.StatuUI_SP = new Dictionary<string, string>();
            _informationBaseStruct.ExtensionDict = new Dictionary<string, string>();
        }

        public string Station
        {
            get { return _informationBaseStruct.Station; }
            set { _informationBaseStruct.Station = value; }
        }

        public string Product
        {
            get { return _informationBaseStruct.Product; }
            set { _informationBaseStruct.Product = value; }
        }

        public string ProjectName
        {
            get { return _informationBaseStruct.ProjectName; }
            set { _informationBaseStruct.ProjectName = value; }
        }

        public string ModelName
        {
            get { return _informationBaseStruct.ModelName; }
            set { _informationBaseStruct.ModelName = value; }
        }

        public string Instances
        {
            get { return _informationBaseStruct.Instances; }
            set { _informationBaseStruct.Instances = value; }
        }

        public string Warning
        {
            get { return _informationBaseStruct.Warning; }
            set
            {
                if (value != "")
                {
                    _informationBaseStruct.ResultStatus = ATS_ResultStatus.WARNING;
                }

                _informationBaseStruct.Warning = value;
            }
        }

        public string BU
        {
            get { return _informationBaseStruct.BU; }
            set { _informationBaseStruct.BU = value; }
        }

        public string PartNumber
        {
            get { return _informationBaseStruct.PartNumber; }
            set { _informationBaseStruct.PartNumber = value; }
        }

        public string SFCSIP
        {
            get { return _informationBaseStruct.SFCSIP; }
            set { _informationBaseStruct.SFCSIP = value; }
        }

        public string Fixture
        {
            get { return _informationBaseStruct.Fixture; }
            set { _informationBaseStruct.Fixture = value; }
        }

        public string SN
        {
            get { return _informationBaseStruct.SN; }
            set
            {
                _informationBaseStruct.IsGoldenSample = false;
                _informationBaseStruct.SN = value;

                if (value != null && value.Length >= 15)
                {
                    _informationBaseStruct.IsGoldenSample = (value.Substring(7, 1).ToUpper() == "Z");

                    if (_informationBaseStruct.IsGoldenSample)
                    {
                        _informationBaseStruct.GoldenSN = value;
                    }
                }
            }
        }

        public string GoldenSN
        {
            get { return _informationBaseStruct.GoldenSN; }
            set { _informationBaseStruct.GoldenSN = value; }
        }

        public string ProgramVersion
        {
            get { return _informationBaseStruct.ProgramVersion; }
            set { _informationBaseStruct.ProgramVersion = value; }
        }

        public string AppVersion
        {
            get { return _informationBaseStruct.AppVersion; }
            set { _informationBaseStruct.AppVersion = value; }
        }

        public string ReleaseDate
        {
            get { return _informationBaseStruct.ReleaseDate; }
            set { _informationBaseStruct.ReleaseDate = value; }
        }

        public Dictionary<string, string> StatusUI_SP
        {
            get { return _informationBaseStruct.StatuUI_SP; }
            set { _informationBaseStruct.StatuUI_SP = value; }
        }

        public Dictionary<string, string> ExtensionDict
        {
            get { return _informationBaseStruct.ExtensionDict; }
            set { _informationBaseStruct.ExtensionDict = value; }
        }

        public ATS_ResultStatus ResultStatus
        {
            get { return _informationBaseStruct.ResultStatus; }
            set
            {
                if (value == ATS_ResultStatus.WARNING && Warning == "")
                {
                    Warning = "Def WARNING";
                }

                _informationBaseStruct.ResultStatus = value;
                StatusChange(value);
            }
        }

        public bool FirstTest
        {
            get { return _informationBaseStruct.FirstTest; }
            set { _informationBaseStruct.FirstTest = value; }
        }

        public bool IsGoldenSample
        {
            get { return _informationBaseStruct.IsGoldenSample; }
            set { _informationBaseStruct.IsGoldenSample = value; }
        }

        private void StatusChange(ATS_ResultStatus status)
        {
            if (TestStatusCallback != null)
            {
                TestStatusCallback(status);
            }
        }

        public void ChangeGoldenMode()
        {
            if (ChangeGoldeModeCallback != null)
            {
                ChangeGoldeModeCallback(this.IsGoldenSample);
            }
        }
    }

    public interface IBaseInformation
    {
        CInformation Information { get; }
    }

    public interface IBaseInstances : IBaseInformation
    {
        #region Initialize on from load
        void OnInitialize();
        void Initialize();
        void OnCreate();
        #endregion

        #region Start before
        bool OnStartBefore();
        bool StartBefore();
        #endregion

        #region Test
        void OnTest();
        bool TestInit();
        void Test();
        #endregion

        void Release();
        void FormShown();
        void FormClosing();
        void StartTestThread();
        void RCSConnectChanged(object sender, EventArgs e);
        CControlUIEvent ControlUIEvent { get; set; }
    }
}
