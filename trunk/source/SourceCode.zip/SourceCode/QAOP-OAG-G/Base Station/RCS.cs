﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using RobotControlServicesLib;

#pragma warning disable CS1690

namespace TestPattern
{
    public class RCS
    {
        private RobotControlServices _rcs = null;

        public delegate bool SendRevokeToRcsDelg(string fixtureNumber);
        public SendRevokeToRcsDelg SendRevokeToRcs = null;

        public delegate bool SendRegisterToRcsDelg(string fixtureNumber);
        public SendRegisterToRcsDelg SendRegisterToRcs = null;

        public delegate bool SendReRegisterToRcsDelg(string fixtureNumber);
        public SendReRegisterToRcsDelg SendReRegisterToRcs = null;

        public delegate bool SendEmergencyStopDelg(string fixtureNumber);
        public SendEmergencyStopDelg SendEmergencyStop = null;

        public delegate bool SendTestResultToRcsDelg(RobotControlServicesLib.Fixture.FixtureStatus fixtureStatus, string fixtureNumber);
        public SendTestResultToRcsDelg SendTestResultToRcs = null;

        public RobotControlServices.CheckFixtureStateDelg CheckFixtureState { set { _rcs.CheckFixtureState = value; } }
        public RobotControlServices.GetSnDelg GetSn { set { _rcs.GetSn = value; } }
        public RobotControlServices.CheckSmoothDelg CheckSmooth { set { _rcs.CheckSmooth = value; } }
        public RobotControlServices.StartTestDelg StartTest { set { _rcs.StartTest = value; } }

        private class SData
        {
            public int NGDisableCounter = 0;
            public int NGDisableNum = 0;
            public int NeedRetestCount = 0;
            public Fixture.FixtureStatus FixtureStatus = Fixture.FixtureStatus.NgDisable;
            public string FixtureNumber = "";
        }

        private SData _rcsData = new SData();
        public string FixtureNumber
        {
            get { return _rcsData.FixtureNumber; }
            set { _rcsData.FixtureNumber = value; }
        }

        public Fixture.FixtureStatus FixtureStatus
        {
            get { return _rcsData.FixtureStatus; }
            set
            {
                _rcsData.FixtureStatus = value;

                if (value == RobotControlServicesLib.Fixture.FixtureStatus.PassWaitMove)
                {
                    _rcsData.NGDisableCounter = 0;
                }
                else
                {
                    _rcsData.NGDisableCounter++;
                }
            }
        }

        public bool NGDisable
        {
            get { return (_rcsData.NGDisableCounter >= _rcsData.NGDisableNum); }
        }

        public int GetNGDisableCounter { get { return _rcsData.NGDisableCounter; } }

        public int GetNGDisableNum { get { return _rcsData.NGDisableNum; } }

        public RCS(string fixture, RobotControlServices.RcsEventLogHandler rcsEventLogHandler, string clientIP = "127.0.0.1")
        {
            try
            {
                FixtureNumber = fixture;
                _rcs = new RobotControlServices(RcsTestParameter(clientIP));
                _rcs.ServiceEvenLogHandle += rcsEventLogHandler;

                this.SendRevokeToRcs = _rcs.SendRevokeToRcs;
                this.SendRegisterToRcs = _rcs.Register;
                this.SendReRegisterToRcs = _rcs.ReRegister;
                this.SendEmergencyStop = _rcs.SendEmergencyStop;
                this.SendTestResultToRcs = _rcs.SendTestResultToRcs;

                InitVariable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Register to RCS failed, please restart the PC and retry it." + ex.Message);
                Environment.Exit(0);
            }
        }

        private string RCSReadINI(string fileName, string appName, string keyName, string defaultValue)
        {
            string parameterStartPath = WNC.API.Func.ReadINI("Setting", "RcsConfig", "ParameterStartPath", Application.StartupPath);
            return WNC.API.Func.ReadINI(parameterStartPath, fileName, appName, keyName, defaultValue);
        }

        private RobotControlServicesLib.RobotControlServiceConfig RcsTestParameter(string clientIP)
        {
            RobotControlServicesLib.RobotControlServiceConfig rcsConfig = new RobotControlServicesLib.RobotControlServiceConfig();

            rcsConfig.ServiceIp = RCSReadINI("Setting", "RcsConfig", "ServerIp", "127.0.0.1");
            rcsConfig.ServicePort = Convert.ToInt32(RCSReadINI("Setting", "RcsConfig", "ServerPort", "60500"));
            rcsConfig.ClientIp = RCSReadINI("Setting", "RcsConfig", "ClientIp", "127.0.0.1");
            rcsConfig.ClientPort = Convert.ToInt32(RCSReadINI("Setting", "RcsConfig", "ClientPort", "60001"));
            rcsConfig.PingPongNum = Convert.ToInt32(RCSReadINI("Setting", "RcsConfig", "PingPongNum", "2"));
            rcsConfig.WaitFixtureNum = Convert.ToInt32(RCSReadINI("Setting", "RcsConfig", "WaitFixtureNum", "0"));
            rcsConfig.Station = Convert.ToInt32(RCSReadINI("Setting", "RcsConfig", "Station", "1"));

            if (clientIP != "127.0.0.1")
            {
                rcsConfig.ClientIp = clientIP;
            }

            return rcsConfig;
        }

        private void InitVariable()
        {
            _rcsData.NGDisableCounter = 0;
            _rcsData.NGDisableNum = Convert.ToInt32(RCSReadINI("Setting", "RcsConfig", "NgDisableNum", "2"));
            _rcsData.NeedRetestCount = Convert.ToInt32(RCSReadINI("Setting", "RcsConfig", "NeedRetestCount", "1"));
        }
    }
}
