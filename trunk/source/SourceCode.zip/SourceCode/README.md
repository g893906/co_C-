## Overview

* **This project shared with QAOP-OAG-G**<br>
* 

## Manufacturing

* <a href="https://mfg.wnc.com.tw/global/TAD/SW/M30310/_layouts/15/DocIdRedir.aspx?ID=SPMFG-1897732160-570&action=default">Test Plan V2.4</a>

<table>
	<tr>
		<td><b>Customer Model</b></td>
		<td align="center">GSI</td>
	</tr>
	<tr>
		<td><b>WNC Model</b></td>
		<td align="center">QAOP-OAG-G</td>
	</tr>
	<tr>
		<td><b>PN</b></td>
		<td>81QAOP01.SG1</td>
	</tr>
</table>


# Test Log
<table>
	<tr>
	    <td><b>QAOP-OAG-G</b></td>
		<td><a href="https://mfg.wnc.com.tw/global/TAD/SW/M30310/_layouts/15/DocIdRedir.aspx?ID=SPMFG-1897732160-575">Function</a></td>
		<td><a href="https://mfg.wnc.com.tw/global/TAD/SW/M30310/_layouts/15/DocIdRedir.aspx?ID=SPMFG-1897732160-573">Final</a></td>
		<td><a href="https://mfg.wnc.com.tw/global/TAD/SW/M30310/_layouts/15/DocIdRedir.aspx?ID=SPMFG-1897732160-574">FQC</a></td>
	</tr>
</table>
